﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using MadTomDev.Data;
using MadTomDev.UIs;

namespace MadTomDev.App
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private ScreenSelectorCore screenSelectorCore;
        private WordHelper wordHelper;
        private WordHelper.Doc workingDoc;
        private OCRTesseractHelper ocrHelper;
        private ZXing.MultiFormatReader mfReader = new ZXing.MultiFormatReader();
        private void FormMain_Load(object sender, EventArgs e)
        {
        }
        private void FormMain_Shown(object sender, EventArgs e)
        {
            ShowStateInfo("Loading...");
            screenSelectorCore = new ScreenSelectorCore();
            screenSelectorCore.HotKeyEnabled = true;
            entryPanel.Init(screenSelectorCore);
            screenSelectorCore.SelectEnd += ScreenSelectorCore_SelectEnd;

            wordHelper = new WordHelper();
            wordHelper.Show_Window();
            button_newDoc_Click(sender, e);

            if (!Directory.Exists(imageCacheDir))
                Directory.CreateDirectory(imageCacheDir);

            this.OCROneDone += FormMain_OCROneDone;

            ocrHelper = new OCRTesseractHelper();

            HideStateProgressBar();
            ShowStateInfo("Ready");
        }


        //private void WorkingDoc_Closed(object sender, EventArgs e)
        //{
        //    screenSelectorCore.Enabled = false;
        //    entryPanel.Enabled = false;
        //    ShowStateInfo("Word document had been closed.");
        //}

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            screenSelectorCore.Dispose();
            //if (workingDoc.needSave)
            //    workingDoc.Save();
            //wordHelper.Dispose();
            Directory.Delete(imageCacheDir, true);
        }



        #region set state info
        public delegate void ShowStateInfoDelegate(string info);
        public delegate void ShowHideStateProgressBar();
        private void ShowStateInfo(string info)
        {
            if (InvokeRequired)
            {
                ShowStateInfoDelegate callBack
                    = new ShowStateInfoDelegate(ShowStateInfo);
                this.Invoke(callBack, info);
            }
            else
            {
                toolStripStatusLabel_info.Text = info;
                Update();
            }
        }
        private void ShowStateProgressBar()
        {
            if (InvokeRequired)
            {
                ShowHideStateProgressBar callBack
                    = new ShowHideStateProgressBar(ShowStateProgressBar);
                this.Invoke(callBack);
            }
            else
            {
                toolStripProgressBar.Visible = true;
                Update();
            }
        }
        private void HideStateProgressBar()
        {
            if (InvokeRequired)
            {
                ShowHideStateProgressBar callBack
                    = new ShowHideStateProgressBar(HideStateProgressBar);
                this.Invoke(callBack);
            }
            else
            {
                toolStripProgressBar.Visible = false;
                Update();
            }
        }
        #endregion



        public class ImageInfoPack
        {
            public Guid taskId;
            public Bitmap image;
            public bool UseOCR;
            public bool UseQR;
            public string OCRText;
            public string CodeText;
            public string CodeName;
        }
        private Queue<ImageInfoPack> taskDataQueue = new Queue<ImageInfoPack>();
        private string imageCacheDir = Path.Combine(Path.GetTempPath(), Application.ProductName);
        private void ScreenSelectorCore_SelectEnd(object sender, bool isCanceled, Bitmap selectedImg)
        {
            if (isCanceled)
                return;

            InputImage(selectedImg);
        }

        private void InputImage(Bitmap newImg)
        {
            ShowStateInfo("Start OCR...");
            Guid newTaskId = Guid.NewGuid();
            taskDataQueue.Enqueue(new ImageInfoPack()
            {
                taskId = newTaskId,
                image = newImg,
                UseOCR = checkBox_useOCR.Checked,
                UseQR = checkBox_recgoQR.Checked,
            });
            string taskIdString = newTaskId.ToString();
            string imageFileFullName = imageCacheDir + "\\" + taskIdString + ".png";
            newImg.Save(imageFileFullName);
            try
            {
                workingDoc.AppendText("\r\n");
                workingDoc.AppendImage(imageFileFullName);
                if (checkBox_useOCR.Checked)
                    workingDoc.AppendText("\r\n[OCR:" + taskIdString + "]");
                if (checkBox_recgoQR.Checked)
                    workingDoc.AppendText("\r\n[Code:" + taskIdString + "]");
            }
            catch (Exception err)
            {
                MessageBox.Show(this, err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                screenSelectorCore.HotKeyEnabled = false;
                entryPanel.Enabled = false;
                ShowStateInfo("Word document may had been closed.");
                return;
            }

            StartOCR();
        }

        public delegate void OCROneDoneDelegate(ImageInfoPack output);
        public event OCROneDoneDelegate OCROneDone;
        private async void StartOCR()
        {
            if (ocrHelper.IsBusy)
                return;
            if (taskDataQueue.Count == 0)
            {
                HideStateProgressBar();
                ShowStateInfo("OCR complete.");
                return;
            }
            ShowStateInfo("OCRing...(" + taskDataQueue.Count.ToString() + " left)");
            ShowStateProgressBar();

            await Task.Factory.StartNew(() =>
            {
                ImageInfoPack iip = taskDataQueue.Dequeue();

                if (iip.UseOCR)
                {
                    while (ocrHelper.IsBusy)
                    {
                        Thread.Sleep(50);
                    }
                    OCRTesseractHelper.OCRResult result = ocrHelper.OCR(iip.image);
                    iip.OCRText = result.FormatedResultString;
                }

                if (iip.UseQR)
                {
                    ZXing.BarcodeReader br = new ZXing.BarcodeReader();
                    ZXing.Result codeResult = br.Decode(iip.image);
                    if (codeResult != null)
                    {
                        iip.CodeName = codeResult.BarcodeFormat.ToString();
                        iip.CodeText = codeResult.Text;
                    }
                }

                OCROneDone?.Invoke(iip);

                StartOCR();
            });
        }


        private void FormMain_OCROneDone(ImageInfoPack output)
        {
            if (this.InvokeRequired)
            {
                OCROneDoneDelegate callback
                    = new OCROneDoneDelegate(FormMain_OCROneDone);
                this.Invoke(callback, output);
            }
            else
            {
                string taskIdString = output.taskId.ToString();
                string replaceText;
                if (output.UseOCR)
                {
                    if (!string.IsNullOrWhiteSpace(output.OCRText))
                    {
                        replaceText = "OCR: " + output.OCRText;
                        FormMain_OCROneDone_removeBlanks(ref replaceText);
                        //workingDoc.ReplaceAll(true, false,
                        //    "[OCR:" + taskIdString + "]", replaceText);
                        workingDoc.FindOneAndSelectText("[OCR:" + taskIdString + "]");
                        workingDoc.InsertText(replaceText);
                    }
                    else
                    {
                        workingDoc.ReplaceAll(true, false,
                            "[OCR:" + taskIdString + "]", "");
                    }
                }
                if (output.UseQR)
                {
                    if (!string.IsNullOrWhiteSpace(output.CodeName))
                    {
                        replaceText = output.CodeName + ": " + output.CodeText;
                        FormMain_OCROneDone_removeBlanks(ref replaceText);
                        //workingDoc.ReplaceAll(true, false,
                        //    "[Code:" + taskIdString + "]", replaceText);
                        workingDoc.FindOneAndSelectText("[Code:" + taskIdString + "]");
                        workingDoc.InsertText(replaceText);
                    }
                    else
                    {
                        workingDoc.ReplaceAll(true, false,
                            "[Code:" + taskIdString + "]", "");
                    }
                }
            }
        }
        private void FormMain_OCROneDone_removeBlanks(ref string textBlock)
        {
            textBlock = textBlock.Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
            while (textBlock.Contains("  ")) textBlock = textBlock.Replace("  ", " ");
        }

        private bool button_newDoc_Click_error = false;
        private void button_newDoc_Click(object sender, EventArgs e)
        {
            try
            {
                workingDoc = wordHelper.Add_WordDoc();
                //workingDoc.Closed += WorkingDoc_Closed;
                workingDoc.AppendText(DateTime.Now.ToString() + " OCR task begins.");

                entryPanel.Enabled = true;
                screenSelectorCore.HotKeyEnabled = true;
                button_newDoc_Click_error = false;
            }
            catch (Exception)
            {
                if (button_newDoc_Click_error)
                {
                    ShowStateInfo("Error, can't create new doc.");
                    return;
                }

                button_newDoc_Click_error = true;
                // user might have close the app...
                wordHelper?.Dispose();
                wordHelper = new WordHelper();
                wordHelper.Show_Window();
                button_newDoc_Click(sender, e);
            }
        }

        private void button_fromClipboard_Click(object sender, EventArgs e)
        {
            Image img = Clipboard.GetImage();
            if (img == null)
            {
                SystemSounds.Beep.Play();
                return;
            }

            InputImage((Bitmap)img.Clone());
        }
    }
}
