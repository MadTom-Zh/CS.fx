﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MadTomDev.App.Workers
{
    public class KindleWindowChecker : IDisposable
    {
        public class KWndStateChangedArgs : EventArgs
        {
            public bool isFocused = false;
            public KWndStateChangedArgs(bool isFocused)
            {
                this.isFocused = isFocused;
            }
        }
        public event EventHandler<KWndStateChangedArgs> KWndStateChanged;

        public KindleWindowChecker()
        {
            Refresh();
        }

        private static string Flag_searchForProcess = "searchProcessFor:";
        private static string Flag_searchWindowFor = "searchWindowFor:";

        private string value_searchForProcess = null;
        private string value_searchWindowFor = null;

        private IntPtr _KindleWndHandle = IntPtr.Zero;
        public IntPtr KindleWndHandle
        {
            get
            {
                return _KindleWndHandle;
            }
        }
        public bool IsKindleWndFound
        {
            get
            {
                return _KindleWndHandle != IntPtr.Zero;
            }
        }

        public void Refresh()
        {
            string argsFileFullName = AppDomain.CurrentDomain.BaseDirectory + Path.DirectorySeparatorChar + "args.txt";
            if (File.Exists(argsFileFullName))
            {
                foreach (string line in File.ReadAllLines(argsFileFullName))
                {
                    if (line.StartsWith(Flag_searchForProcess)) value_searchForProcess = line.Substring(Flag_searchForProcess.Length);
                    else if (line.StartsWith(Flag_searchWindowFor)) value_searchWindowFor = line.Substring(Flag_searchWindowFor.Length);
                }
            }
            else
            {
                File.WriteAllText(argsFileFullName, "searchProcessFor:Kindle" + Environment.NewLine + "searchWindowFor:Kindle for PC");
            }


            Process[] kindleProcs = Process.GetProcessesByName(value_searchForProcess);
            Process curPro = null;
            bool targetWndFound = false;
            for (int idx = kindleProcs.Length - 1; idx >= 0; idx--)
            {
                curPro = kindleProcs[idx];
                if (curPro.MainWindowTitle.Contains(value_searchWindowFor))
                {
                    targetWndFound = true;
                    break;
                }
            }
            if (targetWndFound)
            {
                _KindleWndHandle = curPro.MainWindowHandle;
                RestartWorking();
            }
            else
            {
                _KindleWndHandle = IntPtr.Zero;
                StopWorking();
            }
        }

        private Thread worker = null;
        private void RestartWorking()
        {
            StopWorking();

            worker = new Thread(new ThreadStart(DoWork));
            worker.Start();
        }
        private void StopWorking()
        {
            if (worker != null && worker.IsAlive)
            {
                worker.Abort();
                worker = null;
            }
        }
        public bool IsActive = false;
        private bool _IsKWndInFront = false;
        public bool IsKWndInFront
        {
            get
            {
                return _IsKWndInFront;
            }
        }

        private void DoWork()
        {
            IntPtr curWndHdl, preWndHdl = IntPtr.Zero;

            while (true)
            {
                if (IsActive && _KindleWndHandle != IntPtr.Zero)
                {
                    curWndHdl = GetForegroundWindow();

                    if (preWndHdl != curWndHdl)
                    {
                        if (curWndHdl == _KindleWndHandle)
                        {
                            // focused
                            _IsKWndInFront = true;
                            KWndStateChanged?.Invoke(this, new KWndStateChangedArgs(true));
                        }
                        else
                        {
                            // un focused
                            _IsKWndInFront = false;
                            KWndStateChanged?.Invoke(this, new KWndStateChangedArgs(false));
                        }
                    }
                    preWndHdl = curWndHdl;
                }
                Thread.Sleep(100);
            }
        }

        /// <summary>
        ///     Retrieves a handle to the foreground window (the window with which the user is currently working). The system
        ///     assigns a slightly higher priority to the thread that creates the foreground window than it does to other threads.
        ///     <para>See https://msdn.microsoft.com/en-us/library/windows/desktop/ms633505%28v=vs.85%29.aspx for more information.</para>
        /// </summary>
        /// <returns>
        ///     C++ ( Type: Type: HWND )<br /> The return value is a handle to the foreground window. The foreground window
        ///     can be NULL in certain circumstances, such as when a window is losing activation.
        /// </returns>
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        public void Dispose()
        {
            StopWorking();
        }
    }
}
