﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using MadTomDev.Common;

namespace MadTomDev.App.Workers
{
    public class ClipboardHelper : IDisposable
    {
        public class NewTextArgs : EventArgs
        {
            public string newText;
            public NewTextArgs(string newText)
            {
                this.newText = newText;
            }
        }
        public event EventHandler<NewTextArgs> NewText;

        Thread worker = null;
        public void StartWatching()
        {
            if (worker != null)
            {
                //if (worker.IsAlive)
                //{
                //    throw new ThreadStateException("Watcher is already doing work!");
                //}
                //else
                //{
                //    worker.Abort();
                //    worker = null;
                //}
                if (worker.IsAlive) worker.Abort();
                worker = null;
            }
            _IsWorking = true;
            worker = new Thread(new ThreadStart(DoWork));
            worker.Start();
        }


        private bool _IsWorking = false;
        public bool IsWorking
        {
            get
            {
                return _IsWorking;
            }
        }
        private bool _IsOkToWatching = false;
        public bool IsOkToWatching
        {
            set
            {
                _IsOkToWatching = value;
            }
            get
            {
                return _IsOkToWatching;
            }
        }
        private string preText = null;
        private void DoWork()
        {
            string curText;
            while (true)
            {
                if (_IsOkToWatching)
                {
                    curText = GetText();
                    if (curText != preText)
                    {
                        string[] lines = curText.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                        if (lines.Length == 3)
                        {

                            NewText?.Invoke(this, new NewTextArgs(SimpleStringHelper.RemoveAdditionalSpace(lines[0])));
                        }
                    }
                    preText = curText;
                }

                Thread.Sleep(20);
            }
        }
        [DllImport("user32.dll", SetLastError = true)]
        private static extern Int32 IsClipboardFormatAvailable(uint format);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern Int32 OpenClipboard(IntPtr hWndNewOwner);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetClipboardData(uint uFormat);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern Int32 CloseClipboard();
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern Int32 GlobalLock(IntPtr hMem);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern Int32 GlobalUnlock(IntPtr hMem);
        [DllImport("kernel32.dll")]
        public static extern UIntPtr GlobalSize(IntPtr hMem);
        const uint CF_TEXT = 1;

        private string GetText()
        {
            string result = "";
            if (IsClipboardFormatAvailable(CF_TEXT) == 0)
            {
                return result;
            }
            if (OpenClipboard((IntPtr)0) == 0)
            {
                return result;
            }

            IntPtr hglb = GetClipboardData(CF_TEXT);
            if (hglb != (IntPtr)0)
            {
                UIntPtr size = GlobalSize(hglb);
                IntPtr s = (IntPtr)GlobalLock(hglb);
                byte[] buffer = new byte[(int)size];
                Marshal.Copy(s, buffer, 0, (int)size);
                if (s != null)
                {
                    result = Encoding.Default.GetString(buffer);
                    GlobalUnlock(hglb);
                }
            }

            CloseClipboard();
            return result;
        }

        

        public void StopWatching()
        {
            if (worker != null && worker.IsAlive)
            {
                worker.Abort();
                worker = null;
            }
            _IsWorking = false;
        }

        public void Dispose()
        {
            StopWatching();
        }
    }
}
