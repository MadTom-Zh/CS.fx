﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.UserActivityMonitor;
using MadTomDev.Data;

namespace MadTomDev.App.Workers
{
    public class KeyDownWatcher
    {
        private SettingsTxt settings = new SettingsTxt();
        private const string SettingKey_OCRShortKeys = "OCRShortKeys";

        public KeyDownWatcher()
        {
            IsWatching = false;
            settings.ReLoad();
            string setting_key = settings[SettingKey_OCRShortKeys];
            if (setting_key != null && setting_key.Length > 0)
            {
                SetShortKeys = (Keys)Enum.Parse(typeof(Keys), setting_key, true);
            }
            HookManager.KeyDown += HookManager_KeyDown;

            timer = new Timer()
            {
                Interval = 100,                
            };
            timer.Tick += Timer_Tick;
        }


        private Keys _setKeyData = Keys.Back;
        private string[] setKeyData_strArray = null;
        public Keys SetShortKeys
        {
            set
            {
                _setKeyData = value;
                setKeyData_strArray = _setKeyData.ToString().Split(new char[] { ',' });
                FormatKeyStringArray(ref setKeyData_strArray);
            }
            get
            {
                return _setKeyData;
            }
        }
        public void SaveShortKeys()
        {
            settings[SettingKey_OCRShortKeys] = _setKeyData.ToString();
            settings.Save();
        }

        public bool IsWatching { set; get; }

        public event EventHandler KeyDownMatchFound;

        private LinkedList<Keys> PressedKeys = new LinkedList<Keys>();
        private void HookManager_KeyDown(object sender, KeyEventArgs e)
        {
            if (!IsWatching ) 
                return;

            PressedKeys.AddFirst(e.KeyData);

            Timer_Tick_counter = 0;
            timer.Enabled = true;

            if (setKeyData_strArray == null || setKeyData_strArray.Length > PressedKeys.Count) return;

            List<string> curKeyCombin = new List<string>();
            foreach (Keys k in PressedKeys)
            {
                curKeyCombin.Add(k.ToString());
            }
            string[] curKeyCombin_strArray = curKeyCombin.ToArray();
            FormatKeyStringArray(ref curKeyCombin_strArray);

            if (CompareKeyStringArray(setKeyData_strArray, curKeyCombin_strArray))
            {
                PressedKeys.Clear();
                KeyDownMatchFound?.Invoke(this, null);
            }

            while (PressedKeys.Count >= setKeyData_strArray.Length)
            {
                PressedKeys.RemoveLast();
            }
        }
        private void FormatKeyStringArray(ref string[] array)
        {
            string tmp;
            for (int idx = array.Length - 1; idx >= 0; idx--)
            {
                tmp = array[idx].Trim().ToLower();
                if (tmp.Contains("menu")) tmp = tmp.Replace("menu", "alt");
                if (tmp.Contains("next")) tmp = tmp.Replace("next", "pagedown");
                array[idx] = tmp;
            }
        }
        private bool CompareKeyStringArray(string[] ary1, string[] ary2)
        {
            //string[] tmp1 = new string[ary1.Length];
            //Array.Copy(ary1, tmp1, ary1.Length);
            //string[] tmp2 = new string[ary2.Length];
            //Array.Copy(ary2, tmp2, ary2.Length);

            List<string> c1 = new List<string>();
            c1.AddRange(ary1);
            List<string> c2 = new List<string>();
            c2.AddRange(ary2);

            string tmp1, tmp2;
            for (int i1 = c1.Count - 1; i1 >= 0; i1--)
            {
                tmp1 = c1[i1];
                if (tmp1.Length == 1)
                {
                    for (int i2 = c2.Count - 1; i2 >= 0; i2--)
                    {
                        tmp2 = c2[i2];
                        if (tmp1 == tmp2)
                        {
                            c1.RemoveAt(i1);
                            c2.RemoveAt(i2);
                            break;
                        }
                    }
                }
                else
                {
                    for (int i2 = c2.Count - 1; i2 >= 0; i2--)
                    {
                        tmp2 = c2[i2];
                        if (tmp2.Length > 0 && (tmp1.Contains(tmp2) || tmp2.Contains(tmp1)))
                        {
                            c1.RemoveAt(i1);
                            c2.RemoveAt(i2);
                            break;
                        }
                    }
                }
            }

            return (c1.Count == 0 && c1.Count == c2.Count);
        }

        Timer timer;
        private int Timer_Tick_counter = 100;
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (Timer_Tick_counter++ > 50)
            {
                PressedKeys.Clear();
                timer.Enabled = false;
            }
        }
    }
}
