﻿namespace MadTomDev.App.Ctrls
{
    partial class Form_TectangleSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.handle_tl = new System.Windows.Forms.PictureBox();
            this.handle_tr = new System.Windows.Forms.PictureBox();
            this.handle_bl = new System.Windows.Forms.PictureBox();
            this.handle_br = new System.Windows.Forms.PictureBox();
            this.handle_t = new System.Windows.Forms.PictureBox();
            this.handle_b = new System.Windows.Forms.PictureBox();
            this.handle_l = new System.Windows.Forms.PictureBox();
            this.handle_r = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.handle_tl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_tr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_bl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_br)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_t)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_b)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_l)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_r)).BeginInit();
            this.SuspendLayout();
            // 
            // handle_tl
            // 
            this.handle_tl.Cursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.handle_tl.Location = new System.Drawing.Point(0, 0);
            this.handle_tl.Name = "handle_tl";
            this.handle_tl.Size = new System.Drawing.Size(20, 20);
            this.handle_tl.TabIndex = 0;
            this.handle_tl.TabStop = false;
            this.handle_tl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_tl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_tl.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_tr
            // 
            this.handle_tr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.handle_tr.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.handle_tr.Location = new System.Drawing.Point(118, 0);
            this.handle_tr.Name = "handle_tr";
            this.handle_tr.Size = new System.Drawing.Size(20, 20);
            this.handle_tr.TabIndex = 1;
            this.handle_tr.TabStop = false;
            this.handle_tr.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_tr.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_tr.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_bl
            // 
            this.handle_bl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.handle_bl.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.handle_bl.Location = new System.Drawing.Point(0, 96);
            this.handle_bl.Name = "handle_bl";
            this.handle_bl.Size = new System.Drawing.Size(20, 20);
            this.handle_bl.TabIndex = 2;
            this.handle_bl.TabStop = false;
            this.handle_bl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_bl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_bl.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_br
            // 
            this.handle_br.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.handle_br.Cursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.handle_br.Location = new System.Drawing.Point(118, 96);
            this.handle_br.Name = "handle_br";
            this.handle_br.Size = new System.Drawing.Size(20, 20);
            this.handle_br.TabIndex = 3;
            this.handle_br.TabStop = false;
            this.handle_br.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_br.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_br.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_t
            // 
            this.handle_t.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.handle_t.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.handle_t.Location = new System.Drawing.Point(26, 0);
            this.handle_t.Name = "handle_t";
            this.handle_t.Size = new System.Drawing.Size(86, 20);
            this.handle_t.TabIndex = 4;
            this.handle_t.TabStop = false;
            this.handle_t.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_t.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_t.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_b
            // 
            this.handle_b.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.handle_b.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.handle_b.Location = new System.Drawing.Point(26, 96);
            this.handle_b.Name = "handle_b";
            this.handle_b.Size = new System.Drawing.Size(86, 20);
            this.handle_b.TabIndex = 5;
            this.handle_b.TabStop = false;
            this.handle_b.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_b.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_b.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_l
            // 
            this.handle_l.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.handle_l.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.handle_l.Location = new System.Drawing.Point(0, 26);
            this.handle_l.Name = "handle_l";
            this.handle_l.Size = new System.Drawing.Size(20, 64);
            this.handle_l.TabIndex = 6;
            this.handle_l.TabStop = false;
            this.handle_l.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_l.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_l.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // handle_r
            // 
            this.handle_r.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.handle_r.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.handle_r.Location = new System.Drawing.Point(118, 26);
            this.handle_r.Name = "handle_r";
            this.handle_r.Size = new System.Drawing.Size(20, 64);
            this.handle_r.TabIndex = 7;
            this.handle_r.TabStop = false;
            this.handle_r.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.handle_r.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.handle_r.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            // 
            // Form_TectangleSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.ClientSize = new System.Drawing.Size(138, 116);
            this.ControlBox = false;
            this.Controls.Add(this.handle_r);
            this.Controls.Add(this.handle_l);
            this.Controls.Add(this.handle_b);
            this.Controls.Add(this.handle_t);
            this.Controls.Add(this.handle_br);
            this.Controls.Add(this.handle_bl);
            this.Controls.Add(this.handle_tr);
            this.Controls.Add(this.handle_tl);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(42, 42);
            this.Name = "Form_TectangleSelection";
            this.Opacity = 0.3D;
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_TectangleSelection_Load);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form_TectangleSelection_MouseDoubleClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.handle_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.handle_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.handle_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.handle_tl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_tr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_bl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_br)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_t)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_b)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_l)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handle_r)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox handle_tl;
        private System.Windows.Forms.PictureBox handle_tr;
        private System.Windows.Forms.PictureBox handle_bl;
        private System.Windows.Forms.PictureBox handle_br;
        private System.Windows.Forms.PictureBox handle_t;
        private System.Windows.Forms.PictureBox handle_b;
        private System.Windows.Forms.PictureBox handle_l;
        private System.Windows.Forms.PictureBox handle_r;
    }
}