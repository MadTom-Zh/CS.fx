﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.Ctrls
{
    public partial class Form_TectangleSelection : Form
    {
        public Form_TectangleSelection()
        {
            InitializeComponent();
        }

        public event EventHandler Hiding;

        private void Form_TectangleSelection_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Hiding?.Invoke(this, null);
            this.Hide();
        }

        private enum HandleLocations
        {
            TopLeft, Top, TopRight,
            Left, Right,
            ButtomLeft, Buttom, ButtomRight,
            Form,
            None,
        }

        private HandleLocations SelectedHandleLocation = HandleLocations.None;
        private bool _isMouseDown = false;

        private int boundaryLeft, boundaryTop, boundaryWidth, boundaryHeight;
        public void SetBoundary(int bLeft, int bTop, int bWidth, int bHeight)
        {
            boundaryLeft = bLeft;
            boundaryTop = bTop;
            boundaryWidth = bWidth;
            boundaryHeight = bHeight;
        }

        private void handle_MouseDown(object sender, MouseEventArgs e)
        {
            if (_isMouseDown) return;

            string handleName;
            if (sender is PictureBox)
            {
                PictureBox targetCtrl = (PictureBox)sender;
                handleName = targetCtrl.Name.ToLower();

                if (handleName.EndsWith("_tl")) SelectedHandleLocation = HandleLocations.TopLeft;
                else if (handleName.EndsWith("_t")) SelectedHandleLocation = HandleLocations.Top;
                else if (handleName.EndsWith("_tr")) SelectedHandleLocation = HandleLocations.TopRight;

                else if (handleName.EndsWith("_l")) SelectedHandleLocation = HandleLocations.Left;
                else if (handleName.EndsWith("_r")) SelectedHandleLocation = HandleLocations.Right;

                else if (handleName.EndsWith("_bl")) SelectedHandleLocation = HandleLocations.ButtomLeft;
                else if (handleName.EndsWith("_b")) SelectedHandleLocation = HandleLocations.Buttom;
                else if (handleName.EndsWith("_br")) SelectedHandleLocation = HandleLocations.ButtomRight;
                else SelectedHandleLocation = HandleLocations.None;
            }
            else if (sender is Form)
            {
                Form mainForm = (Form)sender;
                if (mainForm.Name.ToLower().EndsWith("selection")) SelectedHandleLocation = HandleLocations.Form;
                else SelectedHandleLocation = HandleLocations.None;
            }
            else SelectedHandleLocation = HandleLocations.None;

            startMousePoint = MousePosition;
            startWndPoint = this.Location;
            startWndSize = this.Size;
            _isMouseDown = true;
        }

        private Point startMousePoint;
        private Point startWndPoint;
        private Size startWndSize;
        private void handle_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isMouseDown == false) return;


            Point curMousePosition = MousePosition;
            string locString = SelectedHandleLocation.ToString().ToLower();
            int tmp;
            if (locString.Contains("form"))
            {
                tmp = startWndPoint.Y + curMousePosition.Y - startMousePoint.Y;
                if (tmp < boundaryTop) tmp = boundaryTop;
                this.Top = tmp;

                tmp = startWndPoint.X + curMousePosition.X - startMousePoint.X;
                if (tmp < boundaryLeft) tmp = boundaryLeft;
                this.Left = tmp;
                return;
            }
            if (locString.Contains("left"))
            {
                tmp = startWndPoint.X + curMousePosition.X - startMousePoint.X;
                if (tmp < boundaryLeft) tmp = boundaryLeft;
                this.Left = tmp;

                tmp = startWndSize.Width - curMousePosition.X + startMousePoint.X;
                if ((this.Left + tmp) > (boundaryLeft + boundaryWidth)) tmp = boundaryLeft + boundaryWidth - this.Left;
                this.Width = tmp;
            }
            if (locString.Contains("top"))
            {
                tmp = startWndPoint.Y + curMousePosition.Y - startMousePoint.Y;
                if (tmp < boundaryTop) tmp = boundaryTop;
                this.Top = tmp;

                tmp = startWndSize.Height - curMousePosition.Y + startMousePoint.Y;
                if ((this.Top + tmp) > (boundaryTop + boundaryHeight)) tmp = boundaryTop + boundaryHeight - this.Top;
                this.Height = tmp;
            }
            if (locString.Contains("right"))
            {
                tmp = startWndSize.Width + curMousePosition.X - startMousePoint.X;
                if ((this.Left + tmp) > (boundaryLeft + boundaryWidth)) tmp = boundaryLeft + boundaryWidth - this.Left;
                this.Width = tmp;
            }
            if (locString.Contains("buttom"))
            {
                tmp = startWndSize.Height + curMousePosition.Y - startMousePoint.Y;
                if ((this.Top + tmp) > (boundaryTop + boundaryHeight)) tmp = boundaryTop + boundaryHeight - this.Top;
                this.Height = tmp;
            }
        }


        private void handle_MouseUp(object sender, MouseEventArgs e)
        {
            _isMouseDown = false;
        }

        private void Form_TectangleSelection_Load(object sender, EventArgs e)
        {

        }
    }

}
