﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.Ctrls
{
    public partial class Form_TectangleDrag : Form
    {
        public Form_TectangleDrag()
        {
            InitializeComponent();
        }

        Ctrls.Form_TectangleSelection selectionForm = null;
        private void Form_TectangleDrag_Load(object sender, EventArgs e)
        {
            selectionForm = new Ctrls.Form_TectangleSelection();
            //selectionForm.TopMost = true;
            selectionForm.Hiding += SelectionForm_Hiding;
        }


        Point startMousePoint;
        bool setSelectionWndComplete = true;
        private void TectangleDrag_MouseDown(object sender, MouseEventArgs e)
        {
            if (setSelectionWndComplete) return;
            selectionForm.SetBoundary(this.Left, this.Top, this.Width, this.Height);
            startMousePoint = MousePosition;
            selectionForm.Location = startMousePoint;
            selectionForm.Size = selectionForm.MinimumSize;
            selectionForm.Show();
        }

        bool isGoLeft, isGoUp;
        Point curMousePoint;
        private void TectangleDrag_MouseMove(object sender, MouseEventArgs e)
        {
            if (setSelectionWndComplete) return;

            curMousePoint = MousePosition;
            isGoLeft = (curMousePoint.X - startMousePoint.X < 0);
            isGoUp = (curMousePoint.Y - startMousePoint.Y < 0);

            if (isGoLeft)
            {
                selectionForm.Left = curMousePoint.X;
                selectionForm.Width = startMousePoint.X - curMousePoint.X;
            }
            else
            {
                selectionForm.Left = startMousePoint.X;
                selectionForm.Width = curMousePoint.X - startMousePoint.X;
            }

            if (isGoUp)
            {
                selectionForm.Top = curMousePoint.Y;
                selectionForm.Height = startMousePoint.Y - curMousePoint.Y;
            }
            else
            {
                selectionForm.Top = startMousePoint.Y;
                selectionForm.Height = curMousePoint.Y - startMousePoint.Y;
            }

        }

        private void TectangleDrag_MouseUp(object sender, MouseEventArgs e)
        {
            setSelectionWndComplete = true;
        }
        private Image srcImage;
        public void SetImage(Image image)
        {
            _SelectedImage = null;
            srcImage = image;
            pictureBox.Image = srcImage;
            this.Size = image.Size;
            //this.Opacity = 0.01;
        }
        public void SetPositionNShow(int left, int top)
        {
            this.Show();
            this.Left = left;
            this.Top = top;
            //this.Opacity = 1;

            setSelectionWndComplete = false;
        }

        public event EventHandler Hiding;

        private Bitmap _SelectedImage = null;
        public Bitmap SelectedImage
        {
            get { return _SelectedImage; }
        }
        private void SelectionForm_Hiding(object sender, EventArgs e)
        {
            Point selectedLoc = new Point(selectionForm.Location.X - this.Location.X, selectionForm.Location.Y - this.Location.Y);
            Size selectionSize = selectionForm.Size;

            _SelectedImage = new Bitmap(selectionSize.Width, selectionSize.Height);



            Rectangle srcFrame = new Rectangle(selectedLoc, selectionSize);
            Rectangle tarFrame = new Rectangle(new Point(0, 0), selectionSize);
            using (Graphics g = Graphics.FromImage(_SelectedImage))
            {
                g.DrawImage(srcImage, tarFrame, srcFrame, GraphicsUnit.Pixel);
            }

            //pictureBox.Image = _SelectedImage;
            Hiding?.Invoke(this, null);
            this.Hide();
        }
    }
}
