﻿namespace MadTomDev.App
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox_active = new System.Windows.Forms.CheckBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_status = new System.Windows.Forms.ToolStripStatusLabel();
            this.checkBox_onKindleInFront = new System.Windows.Forms.CheckBox();
            this.button_refresh = new System.Windows.Forms.Button();
            this.checkBox_couldInterrupt = new System.Windows.Forms.CheckBox();
            this.groupBox_ocrMethod = new System.Windows.Forms.GroupBox();
            this.checkBox_useOcrCache = new System.Windows.Forms.CheckBox();
            this.numericUpDown_orcCacheLength = new System.Windows.Forms.NumericUpDown();
            this.textBox_ocrMethodSKeys = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButton_clipboardMethod = new System.Windows.Forms.RadioButton();
            this.radioButton_ocrMethod = new System.Windows.Forms.RadioButton();
            this.checkBox_saveToLog = new System.Windows.Forms.CheckBox();
            this.button_logDir = new System.Windows.Forms.Button();
            this.uC_MultiVoice = new MadTomDev.Resources.T2S_HCore.UI.UC_MultiVoice();
            this.statusStrip1.SuspendLayout();
            this.groupBox_ocrMethod.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_orcCacheLength)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBox_active
            // 
            this.checkBox_active.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_active.Checked = true;
            this.checkBox_active.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_active.Location = new System.Drawing.Point(12, 12);
            this.checkBox_active.Name = "checkBox_active";
            this.checkBox_active.Size = new System.Drawing.Size(125, 42);
            this.checkBox_active.TabIndex = 1;
            this.checkBox_active.Text = "Active";
            this.checkBox_active.UseVisualStyleBackColor = true;
            this.checkBox_active.CheckedChanged += new System.EventHandler(this.checkBox_active_CheckedChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_status});
            this.statusStrip1.Location = new System.Drawing.Point(0, 509);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(917, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_status
            // 
            this.toolStripStatusLabel_status.Name = "toolStripStatusLabel_status";
            this.toolStripStatusLabel_status.Size = new System.Drawing.Size(59, 17);
            this.toolStripStatusLabel_status.Text = "Loading...";
            // 
            // checkBox_onKindleInFront
            // 
            this.checkBox_onKindleInFront.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_onKindleInFront.Enabled = false;
            this.checkBox_onKindleInFront.Location = new System.Drawing.Point(143, 12);
            this.checkBox_onKindleInFront.Name = "checkBox_onKindleInFront";
            this.checkBox_onKindleInFront.Size = new System.Drawing.Size(125, 42);
            this.checkBox_onKindleInFront.TabIndex = 4;
            this.checkBox_onKindleInFront.Text = "on Kindle\r\nin front";
            this.checkBox_onKindleInFront.UseVisualStyleBackColor = true;
            // 
            // button_refresh
            // 
            this.button_refresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_refresh.Enabled = false;
            this.button_refresh.Location = new System.Drawing.Point(830, 12);
            this.button_refresh.Name = "button_refresh";
            this.button_refresh.Size = new System.Drawing.Size(75, 41);
            this.button_refresh.TabIndex = 5;
            this.button_refresh.Text = "Refresh";
            this.button_refresh.UseVisualStyleBackColor = true;
            this.button_refresh.Click += new System.EventHandler(this.button_refresh_Click);
            // 
            // checkBox_couldInterrupt
            // 
            this.checkBox_couldInterrupt.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_couldInterrupt.Checked = true;
            this.checkBox_couldInterrupt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_couldInterrupt.Location = new System.Drawing.Point(274, 12);
            this.checkBox_couldInterrupt.Name = "checkBox_couldInterrupt";
            this.checkBox_couldInterrupt.Size = new System.Drawing.Size(125, 42);
            this.checkBox_couldInterrupt.TabIndex = 6;
            this.checkBox_couldInterrupt.Text = "Speek new immediately";
            this.checkBox_couldInterrupt.UseVisualStyleBackColor = true;
            this.checkBox_couldInterrupt.CheckedChanged += new System.EventHandler(this.checkBox_couldInterrupt_CheckedChanged);
            // 
            // groupBox_ocrMethod
            // 
            this.groupBox_ocrMethod.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_ocrMethod.Controls.Add(this.checkBox_useOcrCache);
            this.groupBox_ocrMethod.Controls.Add(this.numericUpDown_orcCacheLength);
            this.groupBox_ocrMethod.Controls.Add(this.textBox_ocrMethodSKeys);
            this.groupBox_ocrMethod.Controls.Add(this.label2);
            this.groupBox_ocrMethod.Location = new System.Drawing.Point(12, 92);
            this.groupBox_ocrMethod.Name = "groupBox_ocrMethod";
            this.groupBox_ocrMethod.Size = new System.Drawing.Size(893, 44);
            this.groupBox_ocrMethod.TabIndex = 8;
            this.groupBox_ocrMethod.TabStop = false;
            // 
            // checkBox_useOcrCache
            // 
            this.checkBox_useOcrCache.AutoSize = true;
            this.checkBox_useOcrCache.Checked = true;
            this.checkBox_useOcrCache.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_useOcrCache.Location = new System.Drawing.Point(197, 17);
            this.checkBox_useOcrCache.Name = "checkBox_useOcrCache";
            this.checkBox_useOcrCache.Size = new System.Drawing.Size(121, 17);
            this.checkBox_useOcrCache.TabIndex = 4;
            this.checkBox_useOcrCache.Text = "Cache Text(blocks):";
            this.checkBox_useOcrCache.UseVisualStyleBackColor = true;
            this.checkBox_useOcrCache.CheckedChanged += new System.EventHandler(this.checkBox_useOcrCache_CheckedChanged);
            // 
            // numericUpDown_orcCacheLength
            // 
            this.numericUpDown_orcCacheLength.Location = new System.Drawing.Point(324, 15);
            this.numericUpDown_orcCacheLength.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown_orcCacheLength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_orcCacheLength.Name = "numericUpDown_orcCacheLength";
            this.numericUpDown_orcCacheLength.Size = new System.Drawing.Size(42, 20);
            this.numericUpDown_orcCacheLength.TabIndex = 3;
            this.numericUpDown_orcCacheLength.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_orcCacheLength.ValueChanged += new System.EventHandler(this.numericUpDown_orcCacheLength_ValueChanged);
            // 
            // textBox_ocrMethodSKeys
            // 
            this.textBox_ocrMethodSKeys.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox_ocrMethodSKeys.Location = new System.Drawing.Point(99, 15);
            this.textBox_ocrMethodSKeys.Name = "textBox_ocrMethodSKeys";
            this.textBox_ocrMethodSKeys.ReadOnly = true;
            this.textBox_ocrMethodSKeys.Size = new System.Drawing.Size(92, 20);
            this.textBox_ocrMethodSKeys.TabIndex = 1;
            this.textBox_ocrMethodSKeys.Enter += new System.EventHandler(this.textBox_ocrMethodSKeys_Enter);
            this.textBox_ocrMethodSKeys.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_ocrMethodSKeys_KeyDown);
            this.textBox_ocrMethodSKeys.Leave += new System.EventHandler(this.textBox_ocrMethodSKeys_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Set Short Keys:";
            // 
            // radioButton_clipboardMethod
            // 
            this.radioButton_clipboardMethod.AutoSize = true;
            this.radioButton_clipboardMethod.Location = new System.Drawing.Point(18, 67);
            this.radioButton_clipboardMethod.Name = "radioButton_clipboardMethod";
            this.radioButton_clipboardMethod.Size = new System.Drawing.Size(108, 17);
            this.radioButton_clipboardMethod.TabIndex = 9;
            this.radioButton_clipboardMethod.Text = "Clipboard Method";
            this.radioButton_clipboardMethod.UseVisualStyleBackColor = true;
            this.radioButton_clipboardMethod.CheckedChanged += new System.EventHandler(this.radioButton_Methods_CheckedChanged);
            // 
            // radioButton_ocrMethod
            // 
            this.radioButton_ocrMethod.AutoSize = true;
            this.radioButton_ocrMethod.Checked = true;
            this.radioButton_ocrMethod.Location = new System.Drawing.Point(18, 90);
            this.radioButton_ocrMethod.Name = "radioButton_ocrMethod";
            this.radioButton_ocrMethod.Size = new System.Drawing.Size(87, 17);
            this.radioButton_ocrMethod.TabIndex = 10;
            this.radioButton_ocrMethod.TabStop = true;
            this.radioButton_ocrMethod.Text = "OCR Method";
            this.radioButton_ocrMethod.UseVisualStyleBackColor = true;
            this.radioButton_ocrMethod.CheckedChanged += new System.EventHandler(this.radioButton_Methods_CheckedChanged);
            // 
            // checkBox_saveToLog
            // 
            this.checkBox_saveToLog.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_saveToLog.Checked = true;
            this.checkBox_saveToLog.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_saveToLog.Location = new System.Drawing.Point(405, 12);
            this.checkBox_saveToLog.Name = "checkBox_saveToLog";
            this.checkBox_saveToLog.Size = new System.Drawing.Size(125, 42);
            this.checkBox_saveToLog.TabIndex = 6;
            this.checkBox_saveToLog.Text = "Save to log";
            this.checkBox_saveToLog.UseVisualStyleBackColor = true;
            this.checkBox_saveToLog.CheckedChanged += new System.EventHandler(this.checkBox_saveToLog_CheckedChanged);
            // 
            // button_logDir
            // 
            this.button_logDir.Location = new System.Drawing.Point(536, 12);
            this.button_logDir.Name = "button_logDir";
            this.button_logDir.Size = new System.Drawing.Size(75, 23);
            this.button_logDir.TabIndex = 11;
            this.button_logDir.Text = "Log dir...";
            this.button_logDir.UseVisualStyleBackColor = true;
            this.button_logDir.Click += new System.EventHandler(this.button_logDir_Click);
            // 
            // uC_MultiVoice
            // 
            this.uC_MultiVoice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uC_MultiVoice.Location = new System.Drawing.Point(12, 142);
            this.uC_MultiVoice.Name = "uC_MultiVoice";
            this.uC_MultiVoice.Size = new System.Drawing.Size(893, 353);
            this.uC_MultiVoice.TabIndex = 0;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 531);
            this.Controls.Add(this.button_logDir);
            this.Controls.Add(this.button_refresh);
            this.Controls.Add(this.checkBox_active);
            this.Controls.Add(this.radioButton_ocrMethod);
            this.Controls.Add(this.checkBox_saveToLog);
            this.Controls.Add(this.checkBox_couldInterrupt);
            this.Controls.Add(this.radioButton_clipboardMethod);
            this.Controls.Add(this.groupBox_ocrMethod);
            this.Controls.Add(this.checkBox_onKindleInFront);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.uC_MultiVoice);
            this.Name = "FormMain";
            this.Text = "OCR-TTS   by MadTom 2022 0402";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox_ocrMethod.ResumeLayout(false);
            this.groupBox_ocrMethod.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_orcCacheLength)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MadTomDev.Resources.T2S_HCore.UI.UC_MultiVoice uC_MultiVoice;
        private System.Windows.Forms.CheckBox checkBox_active;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_status;
        private System.Windows.Forms.CheckBox checkBox_onKindleInFront;
        private System.Windows.Forms.Button button_refresh;
        private System.Windows.Forms.CheckBox checkBox_couldInterrupt;
        private System.Windows.Forms.GroupBox groupBox_ocrMethod;
        private System.Windows.Forms.RadioButton radioButton_clipboardMethod;
        private System.Windows.Forms.RadioButton radioButton_ocrMethod;
        private System.Windows.Forms.TextBox textBox_ocrMethodSKeys;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox_useOcrCache;
        private System.Windows.Forms.NumericUpDown numericUpDown_orcCacheLength;
        private System.Windows.Forms.CheckBox checkBox_saveToLog;
        private System.Windows.Forms.Button button_logDir;
    }
}

