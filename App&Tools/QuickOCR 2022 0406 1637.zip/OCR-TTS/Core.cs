﻿
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using MadTomDev.Resources.T2S_HCore.Classes;
using MadTomDev.Data;
using MadTomDev.Common;

namespace MadTomDev.App
{
    public class Core : IDisposable
    {
        MultiVoice mVoice;
        //public Workers.KindleWindowChecker kWndChecker = new Workers.KindleWindowChecker();
        public Workers.ClipboardHelper clipboardWatcher = new Workers.ClipboardHelper();
        public Workers.ScreenImageSelector screenImageSelector = new Workers.ScreenImageSelector();
        public OCRTesseractHelper ocr = new OCRTesseractHelper();
        public Workers.KeyDownWatcher keyDownHelper = new Workers.KeyDownWatcher();

        Logger logger;

        public Core()
        {
            mVoice = MultiVoice.GetInstance();
            mVoice.MVSpeekStart += MVoice_MVSpeekStart; ;
            mVoice.MVSpeekEnd += MVoice_MVSpeekEnd;

            //kWndChecker.KWndStateChanged += KWndChecker_KWndStateChanged;

            clipboardWatcher.NewText += ClipboardWatcher_NewText;
            clipboardWatcher.IsOkToWatching = true;

            screenImageSelector.PictureSelected += ScreenImageSelector_PictureSelected;

            ocr.OCRStart += Ocr_OCRStart;
            ocr.OCRError += Ocr_OCRError;
            ocr.OCRComplete += Ocr_OCRComplete;

            keyDownHelper.KeyDownMatchFound += KeyDownHelper_KeyDownMatchFound;
        }

        public class EventReportArgs : EventArgs
        {
            public enum InfoTypes
            {
                none,
                info, error,
            }
            public InfoTypes infoType = InfoTypes.none;
            public string info;
            public Exception error;
        }
        public event EventHandler<EventReportArgs> EventReport;

        #region basic status controls
        private bool _IsActive = false;
        public bool IsActive
        {
            set
            {
                _IsActive = value;
                ReSetWorkers();
            }
            get
            {
                return _IsActive;
            }
        }
        public void Active(bool doActive)
        {
            IsActive = doActive;
        }

        public bool CouldInterrupt
        {
            get; set;
        }
        public bool SaveToLog
        {
            get; set;
        }

        //public bool WorkOnlyWhenKindleWndInFront
        //{
        //    get; set;
        //}
        public enum WorkingMethods
        {
            clipboardText,
            OCR,
        }
        private WorkingMethods _WorkingMethod;
        public WorkingMethods WorkingMethod
        {
            get
            {
                return _WorkingMethod;
            }
            set
            {
                _WorkingMethod = value;
                ReSetWorkers();
            }
        }


        private void ReSetWorkers()
        {
            if (_IsActive == false)
            {
                //kWndChecker.IsActive = false;
                clipboardWatcher.IsOkToWatching = false;
                screenImageSelector.IsActive = false;
                keyDownHelper.IsWatching = false;
            }
            else
            {
                //kWndChecker.IsActive = true;

                bool canClipboard = false;
                bool canOCR = false;
                switch (_WorkingMethod)
                {
                    case WorkingMethods.clipboardText:
                        canClipboard = true;

                        canOCR = false;

                        break;
                    case WorkingMethods.OCR:
                        canClipboard = false;

                        canOCR = true;
                        break;
                }

                //  canClipboard
                clipboardWatcher.IsOkToWatching = canClipboard;

                //  canOCR
                screenImageSelector.IsActive = canOCR;
                keyDownHelper.IsWatching = canOCR;

            }
        }

        #endregion




        #region Kindle window checker
        private void KWndChecker_KWndStateChanged(object sender, Workers.KindleWindowChecker.KWndStateChangedArgs e)
        {
            if (e.isFocused == false)
            {
                switch (_WorkingMethod)
                {
                    case WorkingMethods.clipboardText:
                        if (mVoice.isPlaying) mVoice.Stop();
                        break;
                    case WorkingMethods.OCR:
                        //
                        break;
                }
            }
            ReSetWorkers();
        }

        //public void RefindKWnd()
        //{
        //    kWndChecker.Refresh();
        //}

        private bool _IsCheckKWndFocused = false;
        public bool IsCheckKWndFocused
        {
            set
            {




                _IsCheckKWndFocused = value;
            }
            get
            {
                return _IsCheckKWndFocused;
            }
        }

        #endregion




        public event EventHandler StartSpeaking;
        public event EventHandler SpeakingStoped;

        #region Multiple Voice

        private void MVoice_Speak(string text2Speak)
        {
            if (mVoice.isPlaying)
            {
                if (CouldInterrupt) mVoice.Stop();
                else return;
            }

            StartSpeaking?.Invoke(this, null);
            mVoice.Speek(text2Speak);
        }

        private void MVoice_MVSpeekStart(object sender, EventArgs e)
        {
            StartSpeaking?.Invoke(this, null);
            EventReport?.Invoke(this, new EventReportArgs() { infoType = EventReportArgs.InfoTypes.info, info = "MultiVoice speak start." });
        }
        private void MVoice_MVSpeekEnd(object sender, BroadCaster.StreamEnd_Args e)
        {
            SpeakingStoped?.Invoke(this, null);
            EventReport?.Invoke(this, new EventReportArgs() { infoType = EventReportArgs.InfoTypes.info, info = "MultiVoice speak complete." });

            switch (WorkingMethod)
            {
                case WorkingMethods.clipboardText:
                    break;
                case WorkingMethods.OCR:
                    if (IsUsingOcrCache)
                    {
                        if (OcrCachedLength > 0)
                        {
                            MVoice_Speak(OcrTextCache.Dequeue());
                        }
                    }
                    break;
            }
        }

        #endregion




        #region clipboard text
        private void ClipboardWatcher_NewText(object sender, Workers.ClipboardHelper.NewTextArgs e)
        {
            MVoice_Speak(e.newText);
        }

        #endregion





        #region screen select & OCR

        public bool IsUsingOcrCache { get; set; }

        private int _OcrCacheLength = 1;
        private const int _OcrCacheLenghtMax = 5;
        public int OcrCacheLenght
        {
            set
            {
                if (value < 0) throw new Exception("Cache length will not below zero.");
                if (value > _OcrCacheLenghtMax) throw new Exception("Max cache length is " + _OcrCacheLenghtMax);

                _OcrCacheLength = value;
            }
            get
            {
                return _OcrCacheLength;
            }
        }

        private Queue<string> OcrTextCache = new Queue<string>();
        public int OcrCachedLength
        {
            get
            {
                return OcrTextCache.Count;
            }
        }


        private void KeyDownHelper_KeyDownMatchFound(object sender, EventArgs e)
        {
            Ocr_StartSelectScreen();
        }
        private void Ocr_StartSelectScreen()
        {
            bool doSlct = true;
            //if (kWndChecker.IsKindleWndFound)
            //{
            //    if (WorkOnlyWhenKindleWndInFront)
            //    {
            //        if (kWndChecker.IsKWndInFront) doSlct = true;
            //    }
            //    else doSlct = true;
            //}
            if (doSlct)
            {
                if (IsUsingOcrCache && OcrCachedLength < OcrCacheLenght)
                {
                }
                else doSlct = false;
            }
            if (doSlct)
            {
                //screenImageSelector.StartRectangleDrag(kWndChecker.KindleWndHandle);
                screenImageSelector.StartRectangleDrag();
            }
        }
        private void ScreenImageSelector_PictureSelected(object sender, Workers.ScreenImageSelector.PictureSelectedArgs e)
        {
            ocr.OCR_async(e.selectedImg);
        }


        public event EventHandler OCRStart;
        public event EventHandler OCRStoped;


        private void Ocr_OCRStart(OCRTesseractHelper sender)
        {
            keyDownHelper.IsWatching = false;
            EventReport?.Invoke(this, new EventReportArgs() { infoType = EventReportArgs.InfoTypes.info, info = "OCRing..." });
            OCRStart?.Invoke(this, null);
        }
        private void Ocr_OCRError(OCRTesseractHelper sender, Exception err)
        {
            OCRStoped?.Invoke(this, null);
            EventReport?.Invoke(this, new EventReportArgs() { infoType = EventReportArgs.InfoTypes.error, error = err });
            keyDownHelper.IsWatching = true;
        }
        private void Ocr_OCRComplete(OCRTesseractHelper sender, OCRTesseractHelper.OCRResult data)
        {
            OCRStoped?.Invoke(this, null);
            if (SaveToLog)
            {
                if (logger == null)
                {
                    logger = new Logger()
                    {
                        BaseDir = Common.Variables.IOPath.LogDir,
                        BaseFileNamePre = "OCR",
                    };
                }
                logger.Log(data.resultString);
            }
            if (IsUsingOcrCache)
            {
                if (OcrCachedLength < OcrCacheLenght)
                {
                    if (data.FormatedResultString.Length <= 0)
                    {
                        EventReport?.Invoke(this, new EventReportArgs() { infoType = EventReportArgs.InfoTypes.info, info = "No text got." });
                        return;
                    }

                    if (mVoice.isPlaying == false) MVoice_Speak(data.FormatedResultString);
                    else OcrTextCache.Enqueue(data.FormatedResultString);
                }
            }
            else
            {
                MVoice_Speak(data.FormatedResultString);
            }
            keyDownHelper.IsWatching = true;
        }

        public void Dispose()
        {
            mVoice.Dispose();
            //kWndChecker.Dispose();
            clipboardWatcher.Dispose();
            //screenImageSelector.Dispose();
            //ocr.Dispose();
            //keyDownHelper.Dispose();
        }

        #endregion

    }
}
