﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MadTomDev.Resources;

namespace MadTomDev.App
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            uC_MultiVoice.CanAutoReadClipboard = false;
            core.SaveToLog = checkBox_saveToLog.Checked;
            
            core.EventReport += Core_EventReport;            
            core.clipboardWatcher.NewText += ClipboardWatcher_NewText;

            checkBox_active_CheckedChanged(sender, e);
            checkBox_couldInterrupt_CheckedChanged(sender, e);

            textBox_ocrMethodSKeys.Text = core.keyDownHelper.SetShortKeys.ToString();

            checkBox_useOcrCache_CheckedChanged(sender, e);

            numericUpDown_orcCacheLength_ValueChanged(sender, e);
            core.WorkingMethod = Core.WorkingMethods.OCR;

            core.OCRStart += Core_OCRStart;
            core.OCRStoped += Core_OCRStoped;

            core.IsActive = checkBox_active.Checked;
        }



        private void Core_EventReport(object sender, Core.EventReportArgs e)
        {
            switch (e.infoType)
            {
                case Core.EventReportArgs.InfoTypes.info:
                    SetInfo(e.info);
                    break;
                case Core.EventReportArgs.InfoTypes.error:
                    SetInfo(e.error.Message);
                    break;
            }
        }

        private void FormMain_Shown(object sender, EventArgs e)
        {

            SetInfo("Ready.");
        }

        private void ClipboardWatcher_NewText(object sender, Workers.ClipboardHelper.NewTextArgs e)
        {
            SetInfo("Found new text.");
        }

        private void KWndChecker_KWndStateChanged(object sender, Workers.KindleWindowChecker.KWndStateChangedArgs e)
        {
            SetInfo(e.isFocused ? "Kindle window focused." : "Kindle lost.");
        }

        private void SetInfo(string msg)
        {
            if (this.InvokeRequired)
            {
                SetInfo_callback dlt = new SetInfo_callback(SetInfo);
                this.Invoke(dlt, new object[] { msg });
            }
            else
            {
                toolStripStatusLabel_status.Text = msg;
            }
        }
        delegate void SetInfo_callback(string msg);


        Core core = new Core();

        private void checkBox_active_CheckedChanged(object sender, EventArgs e)
        {
            core.IsActive = checkBox_active.Checked;
        }


        private void checkBox_couldInterrupt_CheckedChanged(object sender, EventArgs e)
        {
            core.CouldInterrupt = checkBox_couldInterrupt.Checked;
        }
        private void checkBox_saveToLog_CheckedChanged(object sender, EventArgs e)
        {
            core.SaveToLog = checkBox_saveToLog.Checked;
        }
        private void button_logDir_Click(object sender, EventArgs e)
        {
            Process.Start("Explorer.exe",  Common.Variables.IOPath.LogDir);
        }

        private void button_refresh_Click(object sender, EventArgs e)
        {
            //core.RefindKWnd();
            //SetInfo("Refreshed: " + (core.kWndChecker.IsKindleWndFound ? "Kindle found" : "not found"));
        }

        private void radioButton_Methods_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton targetCtrl = (RadioButton)sender;

            if (targetCtrl.Checked == false) return;

            string ctrlName = targetCtrl.Name.ToLower();
            if (ctrlName.Contains("_clipboard"))
            {
                core.WorkingMethod = Core.WorkingMethods.clipboardText;
                groupBox_ocrMethod.Enabled = false;
            }
            else if (ctrlName.Contains("_ocr"))
            {
                core.WorkingMethod = Core.WorkingMethods.OCR;
                groupBox_ocrMethod.Enabled = true;
            }
        }

        private void textBox_ocrMethodSKeys_Enter(object sender, EventArgs e)
        {
            core.keyDownHelper.IsWatching = false;
        }

        private void textBox_ocrMethodSKeys_Leave(object sender, EventArgs e)
        {
            core.keyDownHelper.SetShortKeys = pressedKeys;
            core.keyDownHelper.SaveShortKeys();
        }

        Keys pressedKeys;
        private void textBox_ocrMethodSKeys_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Tab)
            {
                textBox_ocrMethodSKeys.Text = e.KeyData.ToString();
                pressedKeys = e.KeyData;
            }
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            core.Dispose();
        }

        private void checkBox_useOcrCache_CheckedChanged(object sender, EventArgs e)
        {
            core.IsUsingOcrCache = checkBox_useOcrCache.Checked;
        }

        private void numericUpDown_orcCacheLength_ValueChanged(object sender, EventArgs e)
        {
            core.OcrCacheLenght = (int)numericUpDown_orcCacheLength.Value;
        }

        private void Core_OCRStart(object sender, EventArgs e)
        {
            ThisEnable(false);
        }
        private void Core_OCRStoped(object sender, EventArgs e)
        {
            ThisEnable(true);
        }
        private void ThisEnable(bool isEnable)
        {
            if (this.InvokeRequired)
            {
                ThisEnable_callback dlg = new ThisEnable_callback(ThisEnable);
                this.Invoke(dlg, new object[] { isEnable });
            }
            else
            {
                this.Enabled = isEnable;
            }
        }
        private delegate void ThisEnable_callback(bool isEnable);



        //private const int SW_MAXIMIZE = 3;
        //[System.Runtime.InteropServices.DllImport("user32.dll")]
        //private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        //protected override void WndProc(ref Message m)
        //{
        //    core.kWndChecker.ProcessMessage(ref m);

        //    base.WndProc(ref m);
        //}
    }
}
