﻿namespace MadTomDev.App
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.entryPanel = new MadTomDev.UIs.EntryPanel();
            this.textBox_info = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.checkBox_useOCR = new System.Windows.Forms.CheckBox();
            this.checkBox_recgoQR = new System.Windows.Forms.CheckBox();
            this.button_newDoc = new System.Windows.Forms.Button();
            this.button_fromClipboard = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // entryPanel
            // 
            this.entryPanel.Location = new System.Drawing.Point(12, 12);
            this.entryPanel.Name = "entryPanel";
            this.entryPanel.Size = new System.Drawing.Size(186, 57);
            this.entryPanel.TabIndex = 0;
            // 
            // textBox_info
            // 
            this.textBox_info.Location = new System.Drawing.Point(12, 75);
            this.textBox_info.Multiline = true;
            this.textBox_info.Name = "textBox_info";
            this.textBox_info.ReadOnly = true;
            this.textBox_info.Size = new System.Drawing.Size(483, 84);
            this.textBox_info.TabIndex = 1;
            this.textBox_info.Text = resources.GetString("textBox_info.Text");
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_info,
            this.toolStripStatusLabel2,
            this.toolStripProgressBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 179);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(507, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(59, 17);
            this.toolStripStatusLabel_info.Text = "Loading...";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(331, 17);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            // 
            // checkBox_useOCR
            // 
            this.checkBox_useOCR.AutoSize = true;
            this.checkBox_useOCR.Checked = true;
            this.checkBox_useOCR.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_useOCR.Location = new System.Drawing.Point(237, 19);
            this.checkBox_useOCR.Name = "checkBox_useOCR";
            this.checkBox_useOCR.Size = new System.Drawing.Size(71, 17);
            this.checkBox_useOCR.TabIndex = 4;
            this.checkBox_useOCR.Text = "Use OCR";
            this.checkBox_useOCR.UseVisualStyleBackColor = true;
            // 
            // checkBox_recgoQR
            // 
            this.checkBox_recgoQR.AutoSize = true;
            this.checkBox_recgoQR.Checked = true;
            this.checkBox_recgoQR.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_recgoQR.Location = new System.Drawing.Point(237, 42);
            this.checkBox_recgoQR.Name = "checkBox_recgoQR";
            this.checkBox_recgoQR.Size = new System.Drawing.Size(77, 17);
            this.checkBox_recgoQR.TabIndex = 4;
            this.checkBox_recgoQR.Text = "Recog QR";
            this.checkBox_recgoQR.UseVisualStyleBackColor = true;
            // 
            // button_newDoc
            // 
            this.button_newDoc.Location = new System.Drawing.Point(321, 19);
            this.button_newDoc.Name = "button_newDoc";
            this.button_newDoc.Size = new System.Drawing.Size(84, 40);
            this.button_newDoc.TabIndex = 5;
            this.button_newDoc.Text = "New Doc";
            this.button_newDoc.UseVisualStyleBackColor = true;
            this.button_newDoc.Click += new System.EventHandler(this.button_newDoc_Click);
            // 
            // button_fromClipboard
            // 
            this.button_fromClipboard.Location = new System.Drawing.Point(411, 19);
            this.button_fromClipboard.Name = "button_fromClipboard";
            this.button_fromClipboard.Size = new System.Drawing.Size(84, 40);
            this.button_fromClipboard.TabIndex = 6;
            this.button_fromClipboard.Text = "From\r\nClipboard";
            this.button_fromClipboard.UseVisualStyleBackColor = true;
            this.button_fromClipboard.Click += new System.EventHandler(this.button_fromClipboard_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 201);
            this.Controls.Add(this.button_fromClipboard);
            this.Controls.Add(this.button_newDoc);
            this.Controls.Add(this.checkBox_recgoQR);
            this.Controls.Add(this.checkBox_useOCR);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.textBox_info);
            this.Controls.Add(this.entryPanel);
            this.Name = "FormMain";
            this.Text = "QuickOCR by longtombbj 2020 1201";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIs.EntryPanel entryPanel;
        private System.Windows.Forms.TextBox textBox_info;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.CheckBox checkBox_useOCR;
        private System.Windows.Forms.CheckBox checkBox_recgoQR;
        private System.Windows.Forms.Button button_newDoc;
        private System.Windows.Forms.Button button_fromClipboard;
    }
}

