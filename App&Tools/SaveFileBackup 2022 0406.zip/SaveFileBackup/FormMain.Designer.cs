﻿namespace SaveFileBackup
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_sourceDir = new System.Windows.Forms.TextBox();
            this.button_selectSource = new System.Windows.Forms.Button();
            this.button_selectTarget = new System.Windows.Forms.Button();
            this.textBox_targetDir = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown_interval = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.progressBar_countDown = new System.Windows.Forms.ProgressBar();
            this.checkBox_timerStart = new System.Windows.Forms.CheckBox();
            this.listViewMain = new System.Windows.Forms.ListView();
            this.contextMenuStrip_listViewMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_restore = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_delete = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.checkBox_isUsingSound = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_title = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.folderBrowserDialogSource = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialogTarget = new System.Windows.Forms.FolderBrowserDialog();
            this.button_Backup = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_interval)).BeginInit();
            this.contextMenuStrip_listViewMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "SourceDir";
            // 
            // textBox_sourceDir
            // 
            this.textBox_sourceDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_sourceDir.Location = new System.Drawing.Point(72, 12);
            this.textBox_sourceDir.Name = "textBox_sourceDir";
            this.textBox_sourceDir.Size = new System.Drawing.Size(673, 20);
            this.textBox_sourceDir.TabIndex = 1;
            this.textBox_sourceDir.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_sourceDir_KeyDown);
            this.textBox_sourceDir.Leave += new System.EventHandler(this.textBox_sourceDir_Leave);
            // 
            // button_selectSource
            // 
            this.button_selectSource.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_selectSource.Location = new System.Drawing.Point(751, 10);
            this.button_selectSource.Name = "button_selectSource";
            this.button_selectSource.Size = new System.Drawing.Size(75, 23);
            this.button_selectSource.TabIndex = 2;
            this.button_selectSource.Text = "S&ource...";
            this.button_selectSource.UseVisualStyleBackColor = true;
            this.button_selectSource.Click += new System.EventHandler(this.button_selectSource_Click);
            // 
            // button_selectTarget
            // 
            this.button_selectTarget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_selectTarget.Location = new System.Drawing.Point(751, 39);
            this.button_selectTarget.Name = "button_selectTarget";
            this.button_selectTarget.Size = new System.Drawing.Size(75, 23);
            this.button_selectTarget.TabIndex = 5;
            this.button_selectTarget.Text = "&Target...";
            this.button_selectTarget.UseVisualStyleBackColor = true;
            this.button_selectTarget.Click += new System.EventHandler(this.button_selectTarget_Click);
            // 
            // textBox_targetDir
            // 
            this.textBox_targetDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_targetDir.Location = new System.Drawing.Point(72, 41);
            this.textBox_targetDir.Name = "textBox_targetDir";
            this.textBox_targetDir.Size = new System.Drawing.Size(673, 20);
            this.textBox_targetDir.TabIndex = 4;
            this.textBox_targetDir.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_targetDir_KeyDown);
            this.textBox_targetDir.Leave += new System.EventHandler(this.textBox_targetDir_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "TargetDir";
            // 
            // numericUpDown_interval
            // 
            this.numericUpDown_interval.Location = new System.Drawing.Point(72, 70);
            this.numericUpDown_interval.Maximum = new decimal(new int[] {
            10080,
            0,
            0,
            0});
            this.numericUpDown_interval.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown_interval.Name = "numericUpDown_interval";
            this.numericUpDown_interval.Size = new System.Drawing.Size(80, 20);
            this.numericUpDown_interval.TabIndex = 6;
            this.numericUpDown_interval.ThousandsSeparator = true;
            this.numericUpDown_interval.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown_interval.ValueChanged += new System.EventHandler(this.numericUpDown_interval_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Interval(m)";
            // 
            // progressBar_countDown
            // 
            this.progressBar_countDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar_countDown.Location = new System.Drawing.Point(158, 70);
            this.progressBar_countDown.Name = "progressBar_countDown";
            this.progressBar_countDown.Size = new System.Drawing.Size(506, 20);
            this.progressBar_countDown.TabIndex = 8;
            // 
            // checkBox_timerStart
            // 
            this.checkBox_timerStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_timerStart.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_timerStart.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_timerStart.Location = new System.Drawing.Point(670, 68);
            this.checkBox_timerStart.Name = "checkBox_timerStart";
            this.checkBox_timerStart.Size = new System.Drawing.Size(75, 23);
            this.checkBox_timerStart.TabIndex = 9;
            this.checkBox_timerStart.Text = "&Start";
            this.checkBox_timerStart.UseVisualStyleBackColor = true;
            this.checkBox_timerStart.CheckedChanged += new System.EventHandler(this.checkBox_timerStart_CheckedChanged);
            // 
            // listViewMain
            // 
            this.listViewMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewMain.ContextMenuStrip = this.contextMenuStrip_listViewMain;
            this.listViewMain.HideSelection = false;
            this.listViewMain.LargeImageList = this.imageList;
            this.listViewMain.Location = new System.Drawing.Point(12, 97);
            this.listViewMain.Name = "listViewMain";
            this.listViewMain.Size = new System.Drawing.Size(814, 365);
            this.listViewMain.SmallImageList = this.imageList;
            this.listViewMain.TabIndex = 10;
            this.listViewMain.UseCompatibleStateImageBehavior = false;
            this.listViewMain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listViewMain_KeyDown);
            // 
            // contextMenuStrip_listViewMain
            // 
            this.contextMenuStrip_listViewMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_restore,
            this.toolStripMenuItem_delete});
            this.contextMenuStrip_listViewMain.Name = "contextMenuStrip_listViewMain";
            this.contextMenuStrip_listViewMain.Size = new System.Drawing.Size(114, 48);
            this.contextMenuStrip_listViewMain.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip_listViewMain_Opening);
            // 
            // toolStripMenuItem_restore
            // 
            this.toolStripMenuItem_restore.Name = "toolStripMenuItem_restore";
            this.toolStripMenuItem_restore.Size = new System.Drawing.Size(113, 22);
            this.toolStripMenuItem_restore.Text = "&Restore";
            this.toolStripMenuItem_restore.Click += new System.EventHandler(this.toolStripMenuItem_restore_Click);
            // 
            // toolStripMenuItem_delete
            // 
            this.toolStripMenuItem_delete.Name = "toolStripMenuItem_delete";
            this.toolStripMenuItem_delete.Size = new System.Drawing.Size(113, 22);
            this.toolStripMenuItem_delete.Text = "&Delete";
            this.toolStripMenuItem_delete.Click += new System.EventHandler(this.toolStripMenuItem_delete_Click);
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList.ImageSize = new System.Drawing.Size(32, 32);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // checkBox_isUsingSound
            // 
            this.checkBox_isUsingSound.AutoSize = true;
            this.checkBox_isUsingSound.Location = new System.Drawing.Point(12, 473);
            this.checkBox_isUsingSound.Name = "checkBox_isUsingSound";
            this.checkBox_isUsingSound.Size = new System.Drawing.Size(74, 17);
            this.checkBox_isUsingSound.TabIndex = 12;
            this.checkBox_isUsingSound.Text = "useSound";
            this.checkBox_isUsingSound.UseVisualStyleBackColor = true;
            this.checkBox_isUsingSound.CheckedChanged += new System.EventHandler(this.checkBox_isUsingSound_CheckedChanged);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(693, 473);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Title";
            // 
            // textBox_title
            // 
            this.textBox_title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_title.Location = new System.Drawing.Point(726, 469);
            this.textBox_title.Name = "textBox_title";
            this.textBox_title.Size = new System.Drawing.Size(100, 20);
            this.textBox_title.TabIndex = 14;
            this.textBox_title.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_title_KeyDown);
            this.textBox_title.Leave += new System.EventHandler(this.textBox_title_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(172, 473);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(369, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "*Right click item and select \"Restore\".   **Caution, the \"Delete\" is permanent";
            // 
            // folderBrowserDialogSource
            // 
            this.folderBrowserDialogSource.Description = "Select dir you want to backup";
            // 
            // folderBrowserDialogTarget
            // 
            this.folderBrowserDialogTarget.Description = "Put backup in here";
            // 
            // button_Backup
            // 
            this.button_Backup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Backup.Location = new System.Drawing.Point(751, 68);
            this.button_Backup.Name = "button_Backup";
            this.button_Backup.Size = new System.Drawing.Size(75, 23);
            this.button_Backup.TabIndex = 17;
            this.button_Backup.Text = "&BackupNow";
            this.button_Backup.UseVisualStyleBackColor = true;
            this.button_Backup.Click += new System.EventHandler(this.button_Backup_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 501);
            this.Controls.Add(this.button_Backup);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_title);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBox_isUsingSound);
            this.Controls.Add(this.listViewMain);
            this.Controls.Add(this.checkBox_timerStart);
            this.Controls.Add(this.progressBar_countDown);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDown_interval);
            this.Controls.Add(this.button_selectTarget);
            this.Controls.Add(this.textBox_targetDir);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_selectSource);
            this.Controls.Add(this.textBox_sourceDir);
            this.Controls.Add(this.label1);
            this.Name = "FormMain";
            this.Text = "SaveFileBackup";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_interval)).EndInit();
            this.contextMenuStrip_listViewMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_sourceDir;
        private System.Windows.Forms.Button button_selectSource;
        private System.Windows.Forms.Button button_selectTarget;
        private System.Windows.Forms.TextBox textBox_targetDir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown_interval;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar progressBar_countDown;
        private System.Windows.Forms.CheckBox checkBox_timerStart;
        private System.Windows.Forms.ListView listViewMain;
        private System.Windows.Forms.CheckBox checkBox_isUsingSound;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_title;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogSource;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogTarget;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_listViewMain;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_restore;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.Button button_Backup;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_delete;
    }
}

