﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using System.IO;

namespace SaveFileBackup
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            Application.ThreadException += Application_ThreadException1;
        }

        private void Application_ThreadException1(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            MessageBox.Show(e.Exception.ToString());
        }

        private ConfigSaver config;
        private Backup backup;
        private bool isUILoading;
        private void FormMain_Shown(object sender, EventArgs e)
        {
            Application.ThreadException += Application_ThreadException;

            config = ConfigSaver.GetInstance();

            backup = new Backup();
            // add listener
            backup.TimerTick += Backup_TimerTick;
            backup.ReloadBackupItems += Backup_ReloadBackupItems;
            backup.AddBackupItem += Backup_AddBackupItem;
            backup.DeleteBackupItems += Backup_DeleteBackupItems;

            // load data
            isUILoading = true;
            textBox_sourceDir.Text = config.SourceDir;
            SetSourceDir(config.SourceDir);
            textBox_targetDir.Text = config.TargetDir;
            SetTargetDir(config.TargetDir);

            numericUpDown_interval.Value = config.Interval;

            imageList.Images.Add("dir", DirNFileIcon.GetDirectoryIcon());

            this.Text = textBox_title.Text = config.Title;
            checkBox_isUsingLog.Checked = config.IsWriteLog;
            checkBox_isUsingSound.Checked = config.IsUseSound;
            isUILoading = false;
        }




        #region select source, select target

        private void SetSourceDir(string fullPath)
        {
            config.SourceDir = fullPath;
            backup.SetSourceDir(new System.IO.DirectoryInfo(config.SourceDir));
            textBox_sourceDir.Text = fullPath;
        }
        private void SetTargetDir(string fullPath)
        {
            config.TargetDir = fullPath;
            backup.SetBackupDir(new System.IO.DirectoryInfo(config.TargetDir));
            textBox_targetDir.Text = fullPath;
        }
        private void button_selectSource_Click(object sender, EventArgs e)
        {
            folderBrowserDialogSource.SelectedPath = config.SourceDir;
            if (folderBrowserDialogSource.ShowDialog() == DialogResult.OK)
            {
                SetSourceDir(folderBrowserDialogSource.SelectedPath);
            }
        }
        private void button_selectTarget_Click(object sender, EventArgs e)
        {
            folderBrowserDialogTarget.SelectedPath = config.TargetDir;
                if (folderBrowserDialogTarget.ShowDialog() == DialogResult.OK)
                {
                    SetTargetDir(folderBrowserDialogTarget.SelectedPath);
                }            
        }

        private void textBox_sourceDir_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SetSourceDir(textBox_sourceDir.Text);
            }
        }

        private void textBox_targetDir_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SetTargetDir(textBox_targetDir.Text);
            }
        }

        private void textBox_sourceDir_Leave(object sender, EventArgs e)
        {
            SetSourceDir(textBox_sourceDir.Text);
        }

        private void textBox_targetDir_Leave(object sender, EventArgs e)
        {
            SetTargetDir(textBox_targetDir.Text);
        }

        #endregion



        #region load listView, show progressBar
        private void Backup_TimerTick(object sender, EventArgs e)
        {
            progressBar_countDown.BeginInvoke(
                (MethodInvoker)delegate
                    {
                        progressBar_countDown.Maximum = backup.timerCountDownMax;
                        progressBar_countDown.Value = backup.timerCountDown + 1;
                    }
                );
        }
        private void Backup_ReloadBackupItems(object sender, Backup.ReloadBackupItemsArgs e)
        {
            listViewMain.Clear();
            ListViewItem lvItem;
            foreach (DirectoryInfo di in e.loadedItems)
            {
                lvItem = new ListViewItem(di.Name, "dir");
                lvItem.Name = lvItem.Text;
                lvItem.Tag = di;
                listViewMain.Items.Add(lvItem);
            }
        }
        private void Backup_AddBackupItem(object sender, Backup.AddBackupItemArgs e)
        {
            listViewMain.BeginInvoke(
                (MethodInvoker)delegate
                    {
                        ListViewItem lvItem
                            = new ListViewItem(e.newItem.Name, "dir");
                        lvItem.Name = lvItem.Text;
                        lvItem.Tag = e.newItem;
                        listViewMain.Items.Add(lvItem);
                    }
                );
        }

        private void Backup_DeleteBackupItems(object sender, Backup.DeleteBackupItemArgs e)
        {
            foreach (DirectoryInfo di in e.deletedItems)
            {
                listViewMain.Items.RemoveByKey(di.Name);
            }
        }
        #endregion




        #region restore, delete
        private void contextMenuStrip_listViewMain_Opening(object sender, CancelEventArgs e)
        {
            if (listViewMain.SelectedItems.Count <= 0)
            {
                e.Cancel = true;
            }
            toolStripMenuItem_restore.Enabled = (listViewMain.SelectedItems.Count == 1);
        }
        private void toolStripMenuItem_restore_Click(object sender, EventArgs e)
        {
            backup.Restore((DirectoryInfo)listViewMain.SelectedItems[0].Tag);
        }

        private void toolStripMenuItem_delete_Click(object sender, EventArgs e)
        {
            List<DirectoryInfo> disToDelete = new List<DirectoryInfo>();
            foreach (ListViewItem lvItem in listViewMain.SelectedItems)
            {
                disToDelete.Add((DirectoryInfo)lvItem.Tag);
            }
            backup.DeleteBackups(disToDelete);
        }

        private void listViewMain_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (listViewMain.SelectedItems.Count <= 0) return;
                List<DirectoryInfo> disToDelete = new List<DirectoryInfo>();
                foreach (ListViewItem lvItem in listViewMain.SelectedItems)
                {
                    disToDelete.Add((DirectoryInfo)lvItem.Tag);
                }
                backup.DeleteBackups(disToDelete);
            }
        }

        #endregion




        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            config.Save();
        }
        private void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            MessageBox.Show(this, e.Exception.Message, e.Exception.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }





        #region using log, sound, set title
        private void checkBox_isUsingLog_CheckedChanged(object sender, EventArgs e)
        {
            if (isUILoading) return;
            config.IsUseSound = checkBox_isUsingLog.Checked;
        }
        private void checkBox_isUsingSound_CheckedChanged(object sender, EventArgs e)
        {
            if (isUILoading) return;
            config.IsUseSound = checkBox_isUsingSound.Checked;
        }
        private void textBox_title_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SetTitle();
            }
        }
        private void textBox_title_Leave(object sender, EventArgs e)
        {
            SetTitle();
        }
        private void SetTitle()
        {
            this.Text
                = config.Title
                = textBox_title.Text;
        }
        #endregion


        private void checkBox_timerStart_CheckedChanged(object sender, EventArgs e)
        {
            backup.IsTiming = checkBox_timerStart.Checked;
            if (checkBox_timerStart.Checked)
            {
                progressBar_countDown.Enabled = true;
                progressBar_countDown.Value
                    = progressBar_countDown.Maximum
                    = int.MaxValue;
            }
            else
            {
                progressBar_countDown.Enabled = false;
                progressBar_countDown.Value = 0;
            }
        }

        private void button_Backup_Click(object sender, EventArgs e)
        {
            backup.DoBackup();
        }

        private void numericUpDown_interval_ValueChanged(object sender, EventArgs e)
        {
            config.Interval = (int)numericUpDown_interval.Value;
            backup.ResetCountDown();
        }
    }


    public class DirNFileIcon
    {
        public struct SHFILEINFO
        {
            public IntPtr hIcon;
            public IntPtr iIcon;
            public uint dwAttributes;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szDisplayName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
            public string szTypeName;
        }

        /// <summary>  
        /// 返回系统设置的图标  
        /// </summary>  
        /// <param name="pszPath">文件路径 如果为""  返回文件夹的</param>  
        /// <param name="dwFileAttributes">0</param>  
        /// <param name="psfi">结构体</param>  
        /// <param name="cbSizeFileInfo">结构体大小</param>  
        /// <param name="uFlags">枚举类型</param>  
        /// <returns>-1失败</returns>  
        [DllImport("shell32.dll")]
        public static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbSizeFileInfo, uint uFlags);

        public enum SHGFI
        {
            SHGFI_ICON = 0x100,
            SHGFI_LARGEICON = 0x0,
            SHGFI_USEFILEATTRIBUTES = 0x10
        }


        /// <summary>  
        /// 获取文件图标
        /// </summary>  
        /// <param name="p_Path">文件全路径</param>  
        /// <returns>图标</returns>  
        public static Icon GetFileIcon(string p_Path)
        {
            SHFILEINFO _SHFILEINFO = new SHFILEINFO();
            IntPtr _IconIntPtr = SHGetFileInfo(p_Path, 0, ref _SHFILEINFO, (uint)Marshal.SizeOf(_SHFILEINFO), (uint)(SHGFI.SHGFI_ICON | SHGFI.SHGFI_LARGEICON | SHGFI.SHGFI_USEFILEATTRIBUTES));
            if (_IconIntPtr.Equals(IntPtr.Zero)) return null;
            Icon _Icon = System.Drawing.Icon.FromHandle(_SHFILEINFO.hIcon);
            return _Icon;
        }
        /// <summary>  
        /// 获取文件夹图标
        /// </summary>  
        /// <returns>图标</returns>  
        public static Icon GetDirectoryIcon()
        {
            SHFILEINFO _SHFILEINFO = new SHFILEINFO();
            IntPtr _IconIntPtr = SHGetFileInfo(@"", 0, ref _SHFILEINFO, (uint)Marshal.SizeOf(_SHFILEINFO), (uint)(SHGFI.SHGFI_ICON | SHGFI.SHGFI_LARGEICON));
            if (_IconIntPtr.Equals(IntPtr.Zero)) return null;
            Icon _Icon = System.Drawing.Icon.FromHandle(_SHFILEINFO.hIcon);
            return _Icon;
        }
    }

}
