﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SaveFileBackup
{
    using System.IO;
    using System.Threading;
    using System.Media;

    class Backup
    {
        private Logger logger;
        private ConfigSaver config;
        public Backup()
        {
            logger = Logger.GetInstance();
            config = ConfigSaver.GetInstance();

            IsTiming = false;
            timer = new Timer(new TimerCallback(iTimerTick), this, 5000, 5000);
        }


        public List<DirectoryInfo> backupItems = new List<DirectoryInfo>();
        private DirectoryInfo sourceDir;
        private DirectoryInfo targetDir;
        public void SetSourceDir(DirectoryInfo sourceDir)
        {
            if (this.sourceDir != null && this.sourceDir.FullName == sourceDir.FullName)
                return;
            else
                this.sourceDir = sourceDir;
            iReloadBackupItems();
        }
        public void SetBackupDir(DirectoryInfo backupDir)
        {
            if (this.targetDir != null && this.targetDir.FullName == backupDir.FullName)
                return;
            else
                this.targetDir = backupDir;
            iReloadBackupItems();
        }
        private void iReloadBackupItems()
        {
            backupItems.Clear();

            if (targetDir == null) return;

            string sourceDirName = sourceDir.Name;
            int sourceDirNameLength = sourceDirName.Length;
            foreach (DirectoryInfo di in targetDir.GetDirectories())
            {
                if (di.Name.StartsWith(sourceDirName) && di.Name.Length > sourceDirNameLength)
                {
                    backupItems.Add(di);
                }
            }

            if (ReloadBackupItems != null)
            {
                ReloadBackupItems(this, new ReloadBackupItemsArgs() { loadedItems = backupItems });
            }
        }
        public class ReloadBackupItemsArgs : EventArgs
        {
            public List<DirectoryInfo> loadedItems = new List<DirectoryInfo>();
        }
        public event EventHandler<ReloadBackupItemsArgs> ReloadBackupItems;

        public int timerCountDown;
        private int _timerCountDownMax;
        public int timerCountDownMax
        {
            get
            {
                return _timerCountDownMax;
            }
        }
        private bool _IsTiming;
        public bool IsTiming
        {
            set
            {
                if (value == true) ResetCountDown();
                _IsTiming = value;
            }
        }
        public void ResetCountDown()
        {
            _timerCountDownMax
                = timerCountDown
                = config.Interval * 12;// tick per 5 sec, make it per minute
                                       //= config.Interval ;// testing
        }
        private Timer timer;
        private void iTimerTick(object obj)
        {
            if (_IsTiming)
            {
                if (timerCountDown <= 0)
                {
                    ResetCountDown();

                    try
                    {
                        DoBackup();
                    }
                    catch (Exception err)
                    {
                        if (config.IsWriteLog)
                            logger.Log_withTime(err.ToString());
                        if (config.IsUseSound)
                            SystemSounds.Hand.Play();
                    }
                }
                if (TimerTick != null)
                {
                    TimerTick(this, null);
                }
                timerCountDown--;
            }
        }
        public event EventHandler TimerTick;
        public void DoBackup()
        {
            DirectoryInfo backupItem;
            string backupItemName = sourceDir.Name + " " + DateTime.Now.ToString("yyyy MMdd HHmmss");
            DoBackup_Copy(sourceDir, targetDir, backupItemName, out backupItem);

            if (config.IsWriteLog)
                logger.Log_withTime("Complete backup for [" + sourceDir.Name + "], backup name [" + backupItem.Name + "]");
            if (config.IsUseSound)
                SystemSounds.Asterisk.Play();

            backupItems.Add(backupItem);

            if (AddBackupItem != null)
            {
                AddBackupItem(this, new AddBackupItemArgs() { newItem = backupItem });
            }
        }
        private void DoBackup_Copy(DirectoryInfo source, DirectoryInfo targetDir, string newName, out DirectoryInfo backupItem)
        {
            string bkFullName = targetDir.FullName + "\\" + newName;
            if (Directory.Exists(bkFullName))
            {
                throw new Exception("Directory[" + bkFullName + "] already exists!");
            }

            Directory.CreateDirectory(bkFullName);
            backupItem = new DirectoryInfo(bkFullName);
            Copy_innerLoop(source, backupItem);
        }
        private void Copy_innerLoop(DirectoryInfo source, DirectoryInfo target)
        {
            string targetDirPath = target.FullName;
            foreach (FileInfo fi in source.GetFiles())
            {
                fi.CopyTo(targetDirPath + "\\" + fi.Name);
            }
            foreach (DirectoryInfo di in source.GetDirectories())
            {
                string bkDirFullName = targetDirPath + "\\" + di.Name;
                Directory.CreateDirectory(bkDirFullName);
                DirectoryInfo bkDir = new DirectoryInfo(bkDirFullName);
                Copy_innerLoop(di, bkDir);
            }
        }
        public class AddBackupItemArgs : EventArgs
        {
            public DirectoryInfo newItem;
        }
        public event EventHandler<AddBackupItemArgs> AddBackupItem;

        public void Restore(DirectoryInfo backupItem)
        {
            string sourceDirFullName = sourceDir.FullName;
            Delete_withAllContent(sourceDir, false);
            //Directory.CreateDirectory(sourceDirFullName);
            //sourceDir = new DirectoryInfo(sourceDirFullName);

            Copy_innerLoop(backupItem, sourceDir);

            if (config.IsWriteLog)
                logger.Log_withTime("Successful restore from [" + backupItem.Name + "]");
            if (config.IsUseSound)
                SystemSounds.Asterisk.Play();
        }
        private void Delete_withAllContent(DirectoryInfo sourceDir, bool deleteSelf)
        {
            foreach (FileInfo fi in sourceDir.GetFiles())
            {
                fi.Delete();
            }
            foreach (DirectoryInfo di in sourceDir.GetDirectories())
            {
                Delete_withAllContent(di, deleteSelf);
            }
            if (deleteSelf)
            {
                sourceDir.Delete();
            }
        }

        public void DeleteBackups(List<DirectoryInfo> selectedBackupList)
        {
            List<DirectoryInfo> deletedItems = new List<DirectoryInfo>();
            foreach (DirectoryInfo di in selectedBackupList)
            {
                Delete_withAllContent(di, true);
                backupItems.Remove(di);
                deletedItems.Add(di);
            }
            if (DeleteBackupItems != null)
            {
                DeleteBackupItems(this, new DeleteBackupItemArgs() { deletedItems = deletedItems });
            }
        }
        public class DeleteBackupItemArgs : EventArgs
        {
            public List<DirectoryInfo> deletedItems;
        }
        public event EventHandler<DeleteBackupItemArgs> DeleteBackupItems;
    }
}
