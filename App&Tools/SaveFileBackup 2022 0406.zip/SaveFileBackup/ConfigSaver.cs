﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SaveFileBackup
{
    using System.IO;
    using System.Windows.Forms;

    class ConfigSaver
    {
        private static ConfigSaver instance;
        public static ConfigSaver GetInstance()
        {
            if (instance == null)
            {
                instance = new ConfigSaver();
            }
            return instance;
        }

        private string cfgFileName = "UIinfo.cfg";
        private string cfgFileFullName;
        public ConfigSaver()
        {
            instance = this;
            cfgFileFullName = AppDomain.CurrentDomain.BaseDirectory + "\\" + cfgFileName;

            Title = "SaveFileBackup";
            SourceDir = null;
            TargetDir = null;
            Interval = 15;
            IsWriteLog = true;
            IsUseSound = false;
            ReLoad();
        }

        private static string FLAG_TITLE = "Title:";
        private static string FLAG_SOURCE_DIR = "SourceDir:";
        private static string FLAG_TARGET_DIR = "TargetDir:";
        private static string FLAG_INTERVAL = "IntervalInMin:";
        private static string FLAG_IS_WRITE_LOG = "IsWriteLog:";
        private static string FLAG_IS_USE_SOUND = "IsUseSound:";

        public string Title { set; get; }
        private string _SourceDir;
        public string SourceDir
        {
            set
            {
                if (value == null || value.Length == 0) value = Logger.GetInstance().loggerDir;
                if (Directory.Exists(value))
                    _SourceDir = value;
                else
                    MessageBox.Show("Dir NOT Exists:" + Environment.NewLine + value);
            }
            get
            {
                return _SourceDir;
            }
        }
        private string _TargetDir;
        public string TargetDir
        {
            set
            {
                if (value == null || value.Length == 0) value = AppDomain.CurrentDomain.BaseDirectory;
                if (Directory.Exists(value) == false)
                    Directory.CreateDirectory(value);
                _TargetDir = value;
            }
            get
            {
                return _TargetDir;
            }
        }
        public int Interval
        {
            set; get;
        }
        public bool IsWriteLog
        {
            set; get;
        }
        public bool IsUseSound
        {
            set; get;
        }

        public void Save()
        {
            string content = FLAG_TITLE + Title + "\r";
            content += FLAG_SOURCE_DIR + SourceDir + "\r";
            content += FLAG_TARGET_DIR + TargetDir + "\r";
            content += FLAG_INTERVAL + Interval + "\r";
            content += FLAG_IS_WRITE_LOG + IsWriteLog.ToString() + "\r";
            content += FLAG_IS_USE_SOUND + IsUseSound.ToString() + "\r";
            File.WriteAllText(cfgFileFullName, content);
        }

        public void ReLoad()
        {
            if (File.Exists(cfgFileFullName))
            {
                string[] lines = File.ReadAllLines(cfgFileFullName);
                foreach (string line in lines)
                {
                    if (line.StartsWith(FLAG_TITLE))
                    {
                        Title = line.Substring(FLAG_TITLE.Length);
                        if (Title.Trim().Length == 0) Title = "SaveFileBackup";
                    }
                    else if (line.StartsWith(FLAG_SOURCE_DIR)) SourceDir = line.Substring(FLAG_SOURCE_DIR.Length);
                    else if (line.StartsWith(FLAG_TARGET_DIR)) TargetDir = line.Substring(FLAG_TARGET_DIR.Length);
                    else if (line.StartsWith(FLAG_INTERVAL)) Interval = int.Parse(line.Substring(FLAG_INTERVAL.Length));
                    else if (line.StartsWith(FLAG_IS_WRITE_LOG)) IsWriteLog = bool.Parse(line.Substring(FLAG_IS_WRITE_LOG.Length));
                    else if (line.StartsWith(FLAG_IS_USE_SOUND)) IsUseSound = bool.Parse(line.Substring(FLAG_IS_USE_SOUND.Length));
                }
            }
        }
    }
}
