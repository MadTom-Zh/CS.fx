
Backup your Game Save, super easy

I��m doing the ��Faithful Cartographer��, I don��t know if the game will delete save if the player dies on Pilgrim difficulty, didn��t try that yet.
Save file path: ///////
To prevent losing (all my) hard work progress, I made a app to back up save files, let me show you ;)

Take it:
A simple tool (based on .net framework 2.0) for backing up your save files.
Download at [/////////////]

What it can do:
Backup you save files by copying the whole (parent)folder to a specific location at intervals;
Quickly restore a selected backup by right click and click ��Restore��;
Delete any selected backup(s) any time you like by right click and click ��Delete��;

Other features:
Instantly backup by click ��Backup Now�� button;
Turn on/off log, if you (don��t) want to check the event history (or error messages);
Turn on/off sound, if you (don��t) want to hear sound after backing up (or error arising);
Reset the app ��Title��, if you want multiple app running and mark which is which;

Notes:
The interval can be set between 5 mins to 10080 mins (1 week);
All info on UI will only be saved when the app is closing, if you kill the app process, the info will not be saved; after first ��closing�� it can auto load when app startup;
If you want multiple instances (for other use), make sure the ��.exe�� files are not in the same directory, cause one ��.exe�� using one ��.cfg��, or they will share the same configuration;
Don��t bother manually restore (delete and copy by yourself), let the app do the job, if something missing, it may crush;
Some folder is protected by OS, or your account don��t have full authority, if you can��t see the folder in ��Source����, that may be the reason; Even if you can set the ��Source Dir�� but the app just doesn��t work, please turn on log, hit ��Backup Now�� and check the log file;
��Use Sound�� is totally optional, I don��t want to hear any sound not related when I��m playing a video game, but maybe someone does, who knows.

Plus:
Source code [here///////////////////], of course.
Happy mapping, or�� happy surviving :)
