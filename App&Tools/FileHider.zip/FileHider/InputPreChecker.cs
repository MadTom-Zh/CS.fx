﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadTomDev.App
{
    class InputPreChecker
    {
        public static bool CheckHaveAnyExistence(FileHiderCore core, string targetDirInBase,
            IEnumerable<FileHiderCore.RenameStruct> inputItemsToCheck,
            out List<FileHiderCore.HidenItemInfo> subItemsInDB)
        {
            subItemsInDB = core.DB_GetSubItemsInfo(targetDirInBase);
            HashSet<string> inputNames = new HashSet<string>();
            foreach (FileHiderCore.RenameStruct iis in inputItemsToCheck)
                inputNames.Add(FileHiderCore.GetName(iis.GetNewFullName()));
            foreach (FileHiderCore.HidenItemInfo hii in subItemsInDB)
            {
                if (inputNames.Contains(FileHiderCore.GetName(hii.pathInBase)))
                    return true;
            }
            return false;
        }

        public static void ReNameExistences(List<FileHiderCore.HidenItemInfo> subItemsInDB,
            ref List<FileHiderCore.RenameStruct> inputItemsToRename)
        {
            HashSet<string> existNames = new HashSet<string>();
            foreach (FileHiderCore.HidenItemInfo hii in subItemsInDB)
                existNames.Add(FileHiderCore.GetName(hii.pathInBase));

            int addNo, dotIndex;
            string oriName, curName;
            FileHiderCore.RenameStruct iis;
            for (int i = inputItemsToRename.Count - 1; i >= 0; i--)
            {
                iis = inputItemsToRename[i];
                oriName = FileHiderCore.GetName(iis.GetNewFullName());
                addNo = 1;
                while (true)
                {
                    curName = FileHiderCore.GetName(iis.GetNewFullName());
                    if (existNames.Contains(curName))
                    {
                        if (oriName.Contains("."))
                        {
                            dotIndex = oriName.LastIndexOf(".");
                            iis.newName = curName.Substring(0, dotIndex)
                                + " (" + (addNo++).ToString() + ")"
                                + oriName.Substring(dotIndex);
                        }
                        else
                        {
                            iis.newName = oriName + " (" + (addNo++).ToString() + ")";
                        }
                        inputItemsToRename[i] = iis;
                    }
                    else
                    {
                        existNames.Add(curName);
                        break;
                    }
                }
            }
        }
    }
}
