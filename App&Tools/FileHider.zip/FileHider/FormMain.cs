﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MadTomDev.Data;
using MadTomDev.UIs;
using MadTomDev.CommonClasses;
using System.Collections;
using Delay;
using MadTomDev.UIs.ExDialogs;

namespace MadTomDev.App
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private SettingsTxt setting;
        private const string FLAG_SETTING_HIDEOUT_DIRS = "FLAG_SETTING_HIDEOUT_DIRS";
        private const string IMAGE_KEY_STATE_SHIELD = "shield";
        private const string TEXT_LOADING = "Loading...";
        private List<FileHiderCore> openedCores = new List<FileHiderCore>();
        private IOIcons ioIcons;
        private LVSorter lvSorter;
        private void FormMain_Shown(object sender, EventArgs e)
        {
            //init
            lvSorter = new LVSorter();
            listView.ListViewItemSorter = lvSorter;
            SetProgressBarVisible(false);
            ioIcons = IOIcons.GetInstance();
            imageList_State.Images.Add(IMAGE_KEY_STATE_SHIELD, SystemIcons.Shield);
            imageList.Images.Add(IOIcons.IMAGE_KEY_DIR, ioIcons.GetDirIcon());
            setting = new SettingsTxt(Application.StartupPath + "\\settings.txt");
            setting.ReLoad();

            toolStripStatusLabel_info.Text = "Ready";

            string selfIndex = Application.StartupPath + "\\index";
            if (File.Exists(selfIndex))
                TryOpenHideout(Application.StartupPath);
        }






        #region init and load
        private void button_hoOpen_Click(object sender, EventArgs e)
        {
            if (betterFolderBrowser_selectHO.ShowDialog() == DialogResult.OK)
            {
                TryOpenHideout(betterFolderBrowser_selectHO.SelectedFolder);
            }
        }
        private void TryOpenHideout(string hDir)
        {
            DirectoryInfo hoDi = new DirectoryInfo(hDir);
            foreach (FileHiderCore c in openedCores)
            {
                if (c.HideoutDir == hoDi.FullName)
                {
                    MessageBox.Show(this,
                        "Hideout [" + hoDi.Name + "] is already opened.",
                        "Duplicated Open",
                        MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            if (hoDi.GetFiles(FileHiderCore.DBFile_Name).Length > 0)
            {
                // open
                PasswordInputBox pwdWin = new PasswordInputBox(
                    "Input the password to unlock this hideout.", "Unlock Hideout", false);
                if (pwdWin.ShowDialog() == DialogResult.OK)
                {
                    FileHiderCore core = new FileHiderCore(hoDi.FullName, pwdWin.Password);
                    InitCore_AddListeners(core);
                    openedCores.Add(core);
                    AddUpdateCore_toTreeView(core);
                }

            }
            else if (hoDi.GetFileSystemInfos().Length == 0)
            {
                // new
                PasswordInputBox pwdWin = new PasswordInputBox(
                    "Set a password to init a hideout.", "Init Hideout", true);
                if (pwdWin.ShowDialog() == DialogResult.OK)
                {
                    FileHiderCore core = new FileHiderCore(hoDi.FullName, pwdWin.Password);
                    InitCore_AddListeners(core);
                    openedCores.Add(core);
                    AddUpdateCore_toTreeView(core);
                }
            }
            else
            {
                MessageBox.Show(this,
                    "This folder do not contains index file",
                    "Not a Hideout",
                    MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }
        private void InitCore_AddListeners(FileHiderCore core)
        {
            core.ItemAdded += Core_ItemAdded;
            core.ItemRemoved += Core_ItemRemoved;

            core.InputStepsCounted += Core_InputStepsCounted;
            core.InputProgress += Core_InputProgress;

            core.VacuumProgress += Core_VacuumProgress;
            core.VacuumEndPhase += Core_VacuumEndPhase;
            core.VacuumComplete += Core_VacuumComplete;
        }

        private void button_hoClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this,
                "Are you sure?",
                "Close hideout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes)
            {
                FileHiderCore core = (FileHiderCore)treeView.SelectedNode.Tag;
                openedCores.Remove(core);
                core.Vacuum();
                core.Dispose();
                if (treeView.SelectedNode == null)
                    listView.Items.Clear();
                else
                    treeView.Nodes.Remove(treeView.SelectedNode);
            }
        }


        private void AddUpdateCore_toTreeView(FileHiderCore core)
        {
            TreeNode oriTn = treeView_FindCoreTN(core);
            if (oriTn != null)
                treeView.Nodes.Remove(oriTn);

            string rootNodeText = "H" + treeView.Nodes.Count.ToString();
            TreeNode rootTN = new TreeNode(rootNodeText)
            { Name = rootNodeText, Tag = core, };
            rootTN.ImageKey = ".HideOutRoot";
            rootTN.StateImageKey = IMAGE_KEY_STATE_SHIELD;
            treeView.Nodes.Add(rootTN);
            if (core.DB_HaveSubDirs(null))
                rootTN.Nodes.Add(TEXT_LOADING);
            rootTN.ToolTipText = "Hideout: " + FileHiderCore.GetName(core.HideoutDir) + "\r"
                + core.HideoutDir;

            listView.Items.Clear();
            if (treeView.SelectedNode == null)
                treeView.SelectedNode = treeView.Nodes[0];
        }
        private TreeNode treeView_FindCoreTN(FileHiderCore core)
        {
            TreeNode result = null;
            foreach (TreeNode tn in treeView.Nodes)
            {
                if (tn.Tag is FileHiderCore && (FileHiderCore)tn.Tag == core)
                {
                    result = tn;
                    break;
                }
            }
            return result;
        }
        private TreeNode MakeTreeNode(FileHiderCore core, FileHiderCore.HidenItemInfo dirInfo)
        {
            if (!dirInfo.isDir)
                return null;

            string nodeText = FileHiderCore.GetName(dirInfo.pathInBase);
            TreeNode result = new TreeNode(nodeText)
            { Name = nodeText, Tag = dirInfo, };
            result.ImageKey
                = result.SelectedImageKey
                = IOIcons.IMAGE_KEY_DIR;
            result.StateImageKey = IMAGE_KEY_STATE_SHIELD;
            if (core.DB_HaveSubDirs(dirInfo.pathInBase))
                result.Nodes.Add(TEXT_LOADING);
            return result;
        }
        private ListViewItem MakeListViewItem(FileHiderCore.HidenItemInfo hii)
        {
            string suffix = FileHiderCore.GetSuffixName(hii.pathInBase);
            string textName = FileHiderCore.GetName(hii.pathInBase);
            ListViewItem result
                = new ListViewItem(new string[]
                {
                    textName,
                    hii.isDir? "[dir]": suffix,
                    hii.fileLength.ToString("###,###,###,###,###"),
                    hii.position.PkgIndex.ToString(),
                    hii.position.ItmIndex.ToString(),
                    (hii.lastWriteTime.Ticks != 0) ?
                        hii.lastWriteTime.ToString("yyyy-MM-dd HH:mm:ss.fff") : "",
                });
            result.Name = textName;
            result.Tag = hii;
            if (hii.isDir)
            {
                result.ImageKey = IOIcons.IMAGE_KEY_DIR;
            }
            else
            {
                if (imageList.Images[suffix] == null)
                    imageList.Images.Add(suffix, ioIcons.GetFileIcon_bySuffix(suffix));
                result.ImageKey = suffix;
            }
            result.StateImageIndex = 0;
            return result;
        }
        private bool ListView_JustAdded = false;

        private void Core_ItemAdded(FileHiderCore core, FileHiderCore.HidenItemInfo patheInBase)
        {
            if (InvokeRequired)
            {
                Delegate_void_coreHidenItemInfo callback = new Delegate_void_coreHidenItemInfo(Core_ItemAdded);
                this.Invoke(callback, core, patheInBase);
                return;
            }

            progressStoped = true;
            SetProgressBarVisible(false);
            string fullPath, parentPath;
            TreeNode parentTreeNode = null;
            fullPath = "H" + openedCores.IndexOf(core).ToString() + "\\" + patheInBase.pathInBase;
            parentPath = FileHiderCore.GetParentPath(fullPath);

            parentTreeNode = GetTreeNode(parentPath);
            if (parentTreeNode != null && patheInBase.isDir)
            {
                if (parentTreeNode.IsExpanded)
                {
                    if (parentTreeNode.Nodes[FileHiderCore.GetName(patheInBase.pathInBase)] == null)
                        parentTreeNode.Nodes.Add(MakeTreeNode(core, patheInBase));
                }
                else if (parentTreeNode.Nodes.Count == 0)
                {
                    parentTreeNode.Nodes.Add(TEXT_LOADING);
                }
            }

            if (treeView.SelectedNode == parentTreeNode)
            {
                if (GetListViewItem(patheInBase.pathInBase) == null)
                {
                    listView.Items.Add(MakeListViewItem(patheInBase));
                    ListView_JustAdded = true;
                }
            }
            toolStripStatusLabel_info.Text = "Item added.";
        }
        private void Core_ItemRemoved(FileHiderCore core, string pathInBase)
        {
            if (InvokeRequired)
            {
                Delegate_void_core_string callback = new Delegate_void_core_string(Core_ItemRemoved);
                this.Invoke(callback, core, pathInBase);
                return;
            }


            if (progressStoped)
                SetProgressBarVisible(false);
            string fullPath, parentPath = null;
            fullPath = "H" + openedCores.IndexOf(core).ToString() + "\\" + pathInBase;
            TreeNode parentTreeNode = null, tnToDel;
            ListViewItem lviToDel;
            bool isCheckParentTreeNode = false;
            parentPath = FileHiderCore.GetParentPath(fullPath);

            parentTreeNode = GetTreeNode(parentPath);
            if (parentTreeNode != null)
            {
                if (parentTreeNode.IsExpanded)
                {
                    tnToDel = parentTreeNode.Nodes[FileHiderCore.GetName(pathInBase)];
                    if (tnToDel != null)
                        parentTreeNode.Nodes.Remove(tnToDel);
                }
                else
                    isCheckParentTreeNode = true;
            }




            if (treeView.SelectedNode == null)
            {
                lviToDel = GetListViewItem(fullPath);
                if (lviToDel != null)
                    listView.Items.Remove(lviToDel);
            }
            else if (treeView.SelectedNode == parentTreeNode)
            {
                lviToDel = GetListViewItem(pathInBase);
                if (lviToDel != null)
                    listView.Items.Remove(lviToDel);
            }

            if (isCheckParentTreeNode)
            {
                if (core.DB_HaveSubDirs(parentPath))
                {
                    if (parentTreeNode.Nodes.Count == 0)
                        parentTreeNode.Nodes.Add(TEXT_LOADING);
                }
                else
                {
                    parentTreeNode.Nodes.Clear();
                }
            }
            toolStripStatusLabel_info.Text = "Item removed.";
        }


        private TreeNode GetTreeNode(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return null;

            string[] pathParts = path.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries);
            string pathPart;
            TreeNode targetTNode = null;
            for (int i = 0; i < pathParts.Length; i++)
            {
                pathPart = pathParts[i];
                if (i == 0)
                {
                    targetTNode = treeView.Nodes[pathPart];
                }
                else targetTNode = targetTNode.Nodes[pathPart];
                if (targetTNode == null)
                    return null;
            }

            return targetTNode;
        }
        private ListViewItem GetListViewItem(string nameOrPath)
        { return listView.Items[FileHiderCore.GetName(nameOrPath)]; }

        #endregion

        #region tree view node selected, expand, collapse
        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            textBox_adr.Text = treeView.SelectedNode.FullPath;
            listView.Items.Clear();
            listView.Items.Add(TEXT_LOADING);
            Update();

            listView.Items.Clear();
            button_hoClose.Enabled = (treeView.SelectedNode.Level == 0);

            TreeNode hideTn = treeView_getRootNode(treeView.SelectedNode);
            FileHiderCore core = (FileHiderCore)hideTn.Tag;
            foreach (FileHiderCore.HidenItemInfo hii in core.DB_GetSubItemsInfo(
                treeView_getPath_removeRoot(treeView.SelectedNode)))
            {
                listView.Items.Add(MakeListViewItem(hii));
                ListView_JustAdded = true;
            }
            listView.Sort();
        }
        private void button_adrGo_Click(object sender, EventArgs e)
        {
            string[] pathParts = textBox_adr.Text.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            int ppLength = pathParts.Length;
            TreeNode lookingTN = null, lookingTNPre;
            for (int i = 0; i < ppLength; i++)
            {
                lookingTNPre = lookingTN;
                if (i == 0)
                    lookingTN = treeView.Nodes[pathParts[0]];
                else
                    lookingTN = lookingTN.Nodes[pathParts[i]];

                if (lookingTN == null)
                {
                    toolStripStatusLabel_info.Text = "Unable to find node at [" + pathParts[i] + "].";
                    if (lookingTNPre != null)
                        treeView.SelectedNode = lookingTNPre;
                    return;
                }
                else
                {
                    lookingTN.Expand();
                }
            }
            treeView.SelectedNode = lookingTN;
        }
        private string treeView_getPath_removeRoot(TreeNode targetTN)
        {
            string result = targetTN.FullPath;
            if (result.Contains("\\"))
                return result.Substring(result.IndexOf("\\") + 1);
            else
                return "";
        }
        private TreeNode treeView_getRootNode(TreeNode targetTN)
        {
            TreeNode result = targetTN;
            if (result == null)
                return null;
            while (result.Parent != null)
                result = result.Parent;
            return result;
        }

        private void treeView_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {   /* do nothing */     }
        private void treeView_AfterExpand(object sender, TreeViewEventArgs e)
        {
            Update();

            e.Node.Nodes.Clear();
            TreeNode coreTN = treeView_getRootNode(e.Node);
            FileHiderCore core = (FileHiderCore)coreTN.Tag;
            foreach (FileHiderCore.HidenItemInfo hii in core.DB_GetSubItemsInfo(treeView_getPath_removeRoot(e.Node)))
            {
                if (hii.isDir)
                    e.Node.Nodes.Add(MakeTreeNode(core, hii));
            }
        }

        private void treeView_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            e.Node.Nodes.Clear();
            e.Node.Nodes.Add(TEXT_LOADING);
        }
        #endregion

        #region drop files in

        private string[] DragEnterIOFiles;
        private bool CheckDragDataIsIOFiles(DragEventArgs test)
        {
            DragEnterIOFiles = (string[])test.Data.GetData(DataFormats.FileDrop);
            return DragEnterIOFiles != null && DragEnterIOFiles.Length > 0;
        }
        private void TreeView_DragEnter(object sender, DragEventArgs e)
        { ManageDragEnter(sender, e); }
        private void ListView_DragEnter(object sender, DragEventArgs e)
        { ManageDragEnter(sender, e); }
        private void ManageDragEnter(object sender, DragEventArgs e)
        {
            DragEnterIOFiles = null;
            if (treeView.SelectedNode == null)
            {
                e.Effect = DragDropEffects.None;
                return;
            }
            if (CheckDragDataIsIOFiles(e))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        FileHiderCore.HidenItemInfo DragOverTarget;
        private TreeNode DragOverTreeNode = null;
        private FileHiderCore DragOverCore = null;
        private ListViewItem DragOverListViewItem = null;
        private Color DragOverControlPreBackColor;
        private void TreeView_DragOver(object sender, DragEventArgs e)
        {
            if (e.AllowedEffect == DragDropEffects.None)
                return;

            Point p = treeView.PointToClient(new Point(e.X, e.Y));
            TreeNode curTVNode = treeView.GetNodeAt(p.X, p.Y);
            if (curTVNode == null)
            {
                DragOverCore = null;
                DragOverTarget = null;
                e.Effect = DragDropEffects.None;
                return;
            }

            DragOverCore = (FileHiderCore)treeView_getRootNode(curTVNode).Tag;
            if (curTVNode.Tag is FileHiderCore.HidenItemInfo)
                DragOverTarget = (FileHiderCore.HidenItemInfo)curTVNode.Tag;
            else
                DragOverTarget = null;

            if (DragOverTreeNode != curTVNode)
            {
                if (DragOverTreeNode != null)
                    DragOverTreeNode.BackColor = DragOverControlPreBackColor;

                if (curTVNode != null)
                {
                    DragOverTreeNode = curTVNode;
                    DragOverControlPreBackColor = DragOverTreeNode.BackColor;
                    DragOverTreeNode.BackColor = SystemColors.ActiveCaption;
                }
                else
                    DragOverTreeNode = null;
            }

            ManageDragOver(sender, e);
        }
        private void ListView_DragOver(object sender, DragEventArgs e)
        {
            if (e.AllowedEffect == DragDropEffects.None)
                return;

            if (treeView.SelectedNode == null)
            {
                e.Effect = DragDropEffects.None;
                return;
            }

            Point p = listView.PointToClient(new Point(e.X, e.Y));
            ListViewItem curLVItem = listView.GetItemAt(p.X, p.Y);
            DragOverCore = (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag;
            if (curLVItem == null)
            {
                if (treeView.SelectedNode.Level > 0)
                    DragOverTarget = (FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag;
                else
                    DragOverTarget = null;
            }
            else
            {
                DragOverTarget = (FileHiderCore.HidenItemInfo)curLVItem.Tag;
            }

            if (DragOverListViewItem != curLVItem)
            {
                if (DragOverListViewItem != null)
                    DragOverListViewItem.BackColor = DragOverControlPreBackColor;

                if (curLVItem != null)
                {
                    DragOverListViewItem = curLVItem;
                    DragOverControlPreBackColor = DragOverListViewItem.BackColor;
                    DragOverListViewItem.BackColor = SystemColors.ActiveCaption;
                }
                else
                    DragOverListViewItem = null;
            }

            ManageDragOver(sender, e);
        }
        private void ManageDragOver(object sender, DragEventArgs e)
        {
            if (DragOverCore == null || (DragOverTarget != null && !DragOverTarget.isDir))
                e.Effect = DragDropEffects.None;
            else
                e.Effect = DragDropEffects.Copy;
        }

        private void TreeView_DragLeave(object sender, EventArgs e)
        { }
        private void ListView_DragLeave(object sender, EventArgs e)
        { }
        private void TreeView_DragDrop(object sender, DragEventArgs e)
        { ManageDragDrop(sender, e); }

        private void ListView_DragDrop(object sender, DragEventArgs e)
        { ManageDragDrop(sender, e); }
        private async void ManageDragDrop(object sender, DragEventArgs e)
        {
            if (e.Effect == DragDropEffects.Copy)
            {
                InputFiles_withDialog(DragOverCore, DragOverTarget, DragEnterIOFiles);
            }
        }
        private async void InputFiles_withDialog(FileHiderCore core, FileHiderCore.HidenItemInfo targetDir, params FileHiderCore.RenameStruct[] inputItems)
        {
            List<FileHiderCore.HidenItemInfo> subItemsInDB;
            List<FileHiderCore.RenameStruct> inputItemList = new List<FileHiderCore.RenameStruct>();
            inputItemList.AddRange(inputItems);
            if (InputPreChecker.CheckHaveAnyExistence(
                core,
                targetDir == null ? null : targetDir.pathInBase,
                inputItemList, out subItemsInDB))
            {
                switch (MessageBox.Show(this,
                    "Same item found, what will you do?\r\r"
                    + "   Yes - Overwrite\r"
                    + "    No - Rename\r"
                    + "Cancel - Cancel",
                    "Choose a decision", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        // do nothing
                        break;
                    case DialogResult.No:
                        // rename
                        InputPreChecker.ReNameExistences(subItemsInDB, ref inputItemList);
                        break;
                    case DialogResult.Cancel:
                        return;
                }
            }
            Exception err = await DragOverCore.Input_ASync(targetDir, inputItemList.ToArray());
            if (err != null)
            {
                MessageBox.Show(this, err.ToString(), "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void InputFiles_withDialog(FileHiderCore core, FileHiderCore.HidenItemInfo targetDir, params string[] files)
        {
            List<FileHiderCore.RenameStruct> inputItems = new List<FileHiderCore.RenameStruct>();
            foreach (string f in files)
                inputItems.Add(new FileHiderCore.RenameStruct() { fullName = f, });
            InputFiles_withDialog(core, targetDir, inputItems.ToArray());
        }
        #endregion

        #region drag files out

        private Point MouseDownPoint;
        private bool IsDragOut = true;
        private void listView_MouseDown(object sender, MouseEventArgs e)
        {
            MouseDownPoint = MousePosition;
            IsDragOut = false;
        }
        private void treeView_MouseDown(object sender, MouseEventArgs e)
        {
            MouseDownPoint = MousePosition;
            IsDragOut = false;
        }
        private void listView_MouseUp(object sender, MouseEventArgs e)
        {
            IsDragOut = true;
        }
        private void treeView_MouseUp(object sender, MouseEventArgs e)
        {
            IsDragOut = true;
        }

        private void listView_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsDragOut)
                return;

            Point newMP = MousePosition;
            if (Math.Abs(newMP.X - MouseDownPoint.X) > 3
                || Math.Abs(newMP.Y - MouseDownPoint.Y) > 3)
            {
                IsDragOut = true;
                if (listView.SelectedItems.Count > 0)
                {
                    List<FileHiderCore.HidenItemInfo> hiiList = new List<FileHiderCore.HidenItemInfo>();
                    foreach (ListViewItem lvi in listView.SelectedItems)
                    {
                        if (lvi.Tag is FileHiderCore.HidenItemInfo)
                            hiiList.Add((FileHiderCore.HidenItemInfo)lvi.Tag);
                        else
                            return;
                    }
                    SetClipBoardOrDrag(sender,
                        (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag,
                        FileHiderCore.GetParentPath(hiiList[0].pathInBase),
                        true,
                        hiiList.ToArray());
                }
            }
        }

        private void treeView_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsDragOut)
                return;

            Point newMP = MousePosition;
            if (Math.Abs(newMP.X - MouseDownPoint.X) > 3
                || Math.Abs(newMP.Y - MouseDownPoint.Y) > 3)
            {
                IsDragOut = true;
                if (treeView.SelectedNode != null && treeView.SelectedNode.Tag is FileHiderCore.HidenItemInfo)
                {
                    FileHiderCore.HidenItemInfo dragingHii = (FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag;
                    SetClipBoardOrDrag(sender,
                        (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag,
                        FileHiderCore.GetParentPath(dragingHii.pathInBase), true, dragingHii
                        );
                }
            }
        }
        private List<Stream> streamHolder = new List<Stream>();
        private void SetClipBoardOrDrag(object sender, FileHiderCore core, string basePath, bool isDragOrSetCB, params FileHiderCore.HidenItemInfo[] sources)
        {
            // make final list
            List<FileHiderCore.HidenItemInfo> singleList = GetSingleLayerHIIList(sources);
            List<FileHiderCore.HidenItemInfo> fullList = GetFullHIIList(core, singleList);

            streamHolder.Clear();
            var virtualFileDataObject = new VirtualFileDataObject(
                // BeginInvoke ensures UI operations happen on the right thread
                (vfdo) => this.BeginInvoke((Action)(() =>
                {
                    SetProgressBarVisible(true);
                    toolStripProgressBar_prg.Style = ProgressBarStyle.Marquee;
                    toolStripStatusLabel_prg.Text = "Extin";
                    toolStripStatusLabel_info.Text = "Please wait for a while...";
                })),
                (vfdo) => this.BeginInvoke((Action)(() =>
                {
                    SetProgressBarVisible(false);
                    toolStripProgressBar_prg.Style = ProgressBarStyle.Blocks;
                    toolStripStatusLabel_prg.Text = "";
                    toolStripStatusLabel_info.Text = "Extracting complete.";
                })));

            List<VirtualFileDataObject.FileDescriptor> dataList = new List<VirtualFileDataObject.FileDescriptor>();
            FileInfo hiiFileInfo;
            foreach (FileHiderCore.HidenItemInfo hii in fullList)
            {
                hiiFileInfo = FileHiderCore.GetHideOutPhycalItemFileInfo(core.HideoutDir, hii.position);
                dataList.Add(new VirtualFileDataObject.FileDescriptor()
                {
                    Name = string.IsNullOrWhiteSpace(basePath) ? hii.pathInBase : hii.pathInBase.Substring(basePath.Length + 1),
                    Length = hiiFileInfo.Length,
                    ChangeTimeUtc = hiiFileInfo.LastWriteTime,
                    StreamContents = () =>
                    {
                        //File.WriteAllText("test.txt",DateTime.Now.ToString());
                        Stream es = File.OpenRead(hiiFileInfo.FullName);
                        streamHolder.Add(es);
                        Stream result;
                        EncryptedGZip.UnGZipDecrypt(es, out result, core.Password, FileHiderCore.EncrytConfusionLength);
                        streamHolder.Add(result);
                        return result;
                    }
                });
            }

            virtualFileDataObject.SetData(dataList.ToArray());

            if (isDragOrSetCB)
            {
                VirtualFileDataObject.DoDragDrop((Control)sender, virtualFileDataObject, System.Windows.DragDropEffects.Copy);
            }
            else
            {
                virtualFileDataObject.PreferredDropEffect = System.Windows.DragDropEffects.Copy;
                Clipboard.SetDataObject(virtualFileDataObject);
            }
        }
        private List<FileHiderCore.HidenItemInfo> GetSingleLayerHIIList(IEnumerable<FileHiderCore.HidenItemInfo> input)
        {
            List<FileHiderCore.HidenItemInfo> result = new List<FileHiderCore.HidenItemInfo>();
            result.AddRange(input);
            result.Sort((a, b) => a.pathInBase.CompareTo(b.pathInBase));
            FileHiderCore.HidenItemInfo test, test2;
            string parPath;
            for (int i = 0; i < result.Count; i++)
            {
                test = result[i];
                if (test.isDir)
                {
                    parPath = test.pathInBase + "\\";
                    for (int j = i + 1; j < result.Count; j++)
                    {
                        test2 = result[j];
                        if (test2.pathInBase.StartsWith(parPath))
                        {
                            result.RemoveAt(j--);
                        }
                    }
                }
            }
            return result;
        }
        private List<FileHiderCore.HidenItemInfo> GetFullHIIList(FileHiderCore core, IEnumerable<FileHiderCore.HidenItemInfo> input)
        {
            List<FileHiderCore.HidenItemInfo> result = new List<FileHiderCore.HidenItemInfo>();
            List<FileHiderCore.HidenItemInfo> subList;
            foreach (FileHiderCore.HidenItemInfo hii in input)
            {
                if (hii.isDir)
                {
                    subList = core.DB_GetSubItemsInfo(hii.pathInBase, true);
                    foreach (FileHiderCore.HidenItemInfo subHii in subList)
                    {
                        if (!subHii.isDir)
                            result.Add(subHii);
                    }
                }
                else
                {
                    result.Add(hii);
                }
            }
            return result;
        }

        #endregion

        #region  states infos

        private bool progressStoped = true;
        private int progressStepsAll, progressStepsCur;
        private delegate void Delegate_void();
        private delegate void Delegate_void_int(int i);
        private delegate void Delegate_void_int_int(int i, int j);
        private delegate void Delegate_void_string(string s);
        private delegate void Delegate_void_core_string(FileHiderCore core, string s);
        private delegate void Delegate_void_bool(bool b);
        private delegate void Delegate_void_coreHidenItemInfo(FileHiderCore core, FileHiderCore.HidenItemInfo hii);

        private void Core_InputStepsCounted(int allSteps)
        {
            if (InvokeRequired)
            {
                Delegate_void_int callback = new Delegate_void_int(Core_InputStepsCounted);
                this.Invoke(callback, allSteps);
            }
            else
            {
                progressStoped = false;
                progressStepsCur = 0;
                progressStepsAll = allSteps;
                toolStripProgressBar_prg.Maximum = progressStepsAll;
                SetProgressBarVisible(true);
            }
        }
        private void Core_InputProgress(string progressingPath)
        {
            if (InvokeRequired)
            {
                Delegate_void_string callback = new Delegate_void_string(Core_InputProgress);
                this.Invoke(callback, progressingPath);
            }
            else
            {
                progressStepsCur++;
                toolStripStatusLabel_prg.Text = "Prg: " + progressStepsCur.ToString() + "/" + progressStepsAll.ToString();
                toolStripProgressBar_prg.Value = progressStepsCur;
                toolStripStatusLabel_info.Text = "Inputing: " + progressingPath;
                Update();
            }
        }
        private void SetProgressBarVisible(bool isVisible)
        {
            toolStripStatusLabel_prg.Visible = isVisible;
            toolStripProgressBar_prg.Visible = isVisible;
        }

        private DateTime ListView_JustAddedTime = DateTime.MinValue;

        private void listView_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if ((e.Column == 3 || e.Column == 4)
                && (lvSorter.SortColumnPre == 3 || lvSorter.SortColumnPre == 4))
            {
                if (lvSorter.SortOrder == SortOrder.Ascending)
                    lvSorter.SortOrder = SortOrder.Descending;
                else
                    lvSorter.SortOrder = SortOrder.Ascending;
            }
            else if (e.Column == lvSorter.SortColumn)
            {
                if (lvSorter.SortOrder == SortOrder.Ascending)
                    lvSorter.SortOrder = SortOrder.Descending;
                else
                    lvSorter.SortOrder = SortOrder.Ascending;
            }
            else
            {
                lvSorter.SortColumn = e.Column;
                lvSorter.SortOrder = SortOrder.Ascending;
            }
            listView.Sort();
        }
        public class LVSorter : IComparer
        {
            private Comparer comparer;
            public LVSorter()
            {
                comparer = Comparer.Default;
            }
            public int SortColumnPre;
            public int SortColumn
            { set; get; } = 0;
            public SortOrder SortOrder
            { set; get; } = SortOrder.Ascending;
            public int Compare(object x, object y)
            {
                int result;
                ListViewItem itemX = (ListViewItem)x;
                ListViewItem itemY = (ListViewItem)y;
                if (SortColumn == 0)
                {
                    bool xIsDir = ((FileHiderCore.HidenItemInfo)itemX.Tag).isDir;
                    bool yIsDir = ((FileHiderCore.HidenItemInfo)itemY.Tag).isDir;
                    result = comparer.Compare(
                        (xIsDir ? "  " : "") + itemX.SubItems[SortColumn].Text,
                        (yIsDir ? "  " : "") + itemY.SubItems[SortColumn].Text);
                }
                else if (SortColumn == 1)
                {
                    result = comparer.Compare(itemX.SubItems[SortColumn].Text, itemY.SubItems[SortColumn].Text);
                }
                else if (SortColumn == 2)
                {
                    result = comparer.Compare(
                        ((FileHiderCore.HidenItemInfo)itemX.Tag).fileLength,
                        ((FileHiderCore.HidenItemInfo)itemY.Tag).fileLength);
                }
                else if (SortColumn == 5)
                {
                    result = comparer.Compare(
                        ((FileHiderCore.HidenItemInfo)itemX.Tag).lastWriteTime,
                        ((FileHiderCore.HidenItemInfo)itemY.Tag).lastWriteTime);
                }
                else
                {
                    long xv = (long.Parse(itemX.SubItems[3].Text) * 10000) + long.Parse(itemX.SubItems[4].Text);
                    long yv = (long.Parse(itemY.SubItems[3].Text) * 10000) + long.Parse(itemY.SubItems[4].Text);
                    result = comparer.Compare(xv, yv);
                }
                SortColumnPre = SortColumn;
                if (this.SortOrder == SortOrder.Ascending)
                    return result;
                else if (this.SortOrder == SortOrder.Descending)
                    return (-result);
                else
                    return 0;
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (ListView_JustAdded)
            {
                ListView_JustAddedTime = DateTime.Now;
                ListView_JustAdded = false;
            }
            else if (ListView_JustAddedTime != DateTime.MinValue)
            {
                if ((DateTime.Now - ListView_JustAddedTime).TotalMilliseconds > 300)
                {
                    listView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                    ListView_JustAddedTime = DateTime.MinValue;
                }
            }
        }

        private void Core_VacuumProgress(int curPkg, int maxPkg)
        {
            if (InvokeRequired)
            {
                Delegate_void_int_int callback = new Delegate_void_int_int(Core_VacuumProgress);
                this.Invoke(callback, curPkg, maxPkg);
                return;
            }
            toolStripStatusLabel_prg.Text = "Vcm: " + curPkg.ToString() + "/" + maxPkg.ToString();
            toolStripProgressBar_prg.Maximum = maxPkg;
            toolStripProgressBar_prg.Value = curPkg;
            Update();
        }
        private void Core_VacuumEndPhase(string msg)
        {
            if (InvokeRequired)
            {
                Delegate_void_string callback = new Delegate_void_string(Core_VacuumEndPhase);
                this.Invoke(callback, msg);
                return;
            }
            SetProgressBarVisible(false);
            toolStripStatusLabel_info.Text = msg;
            Update();
        }
        private void Core_VacuumComplete()
        {
            if (InvokeRequired)
            {
                Delegate_void callback = new Delegate_void(Core_VacuumComplete);
                this.Invoke(callback);
                return;
            }
            toolStripStatusLabel_info.Text = "Complete, Closing...";
            Update();
            this.Close();
        }

        #endregion

        #region right click menu, shortcut keys

        private TreeNode rightClickedTreeNode;
        private FileHiderCore rightClickedCore;
        private List<FileHiderCore.HidenItemInfo> rightClickedHII = new List<FileHiderCore.HidenItemInfo>();
        private string[] copiedFilesInCB = null;
        private void contextMenuStrip_treeView_Opening(object sender, CancelEventArgs e)
        {
            Point p = treeView.PointToClient(MousePosition);
            rightClickedTreeNode = treeView.GetNodeAt(p);
            bool haveTN = rightClickedTreeNode != null;
            toolStripMenuItem_openHideout.Visible = haveTN;
            toolStripMenuItem_closeHideout.Visible = haveTN;
            toolStripSeparator_openCloseHideout.Visible = haveTN;
            toolStripMenuItem_treeview_colExp.Enabled = haveTN;
            toolStripMenuItem_treeview_extract.Enabled = false;
            toolStripMenuItem_treeview_delete.Enabled = false;
            toolStripMenuItem_treeview_rename.Enabled = (haveTN && rightClickedTreeNode.Level > 0);
            toolStripMenuItem_treeview_copy.Enabled = false;
            rightClickedHII.Clear();
            if (haveTN)
            {
                if (rightClickedTreeNode.Tag is FileHiderCore.HidenItemInfo)
                {
                    FileHiderCore.HidenItemInfo hii = (FileHiderCore.HidenItemInfo)rightClickedTreeNode.Tag;
                    rightClickedHII.Add(hii);
                    toolStripMenuItem_treeview_extract.Enabled = true;
                    toolStripMenuItem_treeview_delete.Enabled = true;
                    //toolStripMenuItem_treeview_copy.Enabled = true;
                }
                else if (rightClickedTreeNode.Tag is FileHiderCore)
                {
                    rightClickedCore = (FileHiderCore)rightClickedTreeNode.Tag;
                    toolStripMenuItem_closeHideout.Visible = true;
                    toolStripSeparator_openCloseHideout.Visible = true;
                }
            }
            else
            {
                toolStripMenuItem_openHideout.Visible = true;
                toolStripSeparator_openCloseHideout.Visible = true;
            }

            copiedFilesInCB = (string[])Clipboard.GetData(DataFormats.FileDrop);
            toolStripMenuItem_treeview_paste.Enabled = (copiedFilesInCB != null && copiedFilesInCB.Length > 0);
        }
        private void treeView_BeforeLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (e.Node.Level == 0)
                e.CancelEdit = true;
        }
        private void contextMenuStrip_listView_Opening(object sender, CancelEventArgs e)
        {
            bool selectLVItems = listView.SelectedItems.Count > 0;
            toolStripMenuItem_listview_delete.Enabled = selectLVItems;
            toolStripMenuItem_listview_rename.Enabled = (listView.SelectedItems.Count == 1);
            toolStripMenuItem_listview_extract.Enabled = selectLVItems;
            //toolStripMenuItem_listview_copy.Enabled = false; // selectLVItems;
            rightClickedCore = (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag;
            rightClickedHII.Clear();
            foreach (ListViewItem lvi in listView.SelectedItems)
                rightClickedHII.Add((FileHiderCore.HidenItemInfo)lvi.Tag);

            copiedFilesInCB = (string[])Clipboard.GetData(DataFormats.FileDrop);
            toolStripMenuItem_listview_paste.Enabled = (copiedFilesInCB != null && copiedFilesInCB.Length > 0);
        }

        private void toolStripMenuItem_openHideout_Click(object sender, EventArgs e)
        { button_hoOpen_Click(null, null); }

        private void toolStripMenuItem_closeHideout_Click(object sender, EventArgs e)
        { button_hoClose_Click(null, null); }

        private void toolStripMenuItem_treeview_colExp_Click(object sender, EventArgs e)
        {
            if (rightClickedTreeNode.IsExpanded)
                rightClickedTreeNode.Collapse();
            else
                rightClickedTreeNode.Expand();
        }
        private void toolStripMenuItem_treeview_extract_Click(object sender, EventArgs e)
        { ExtractItems_withDialog(rightClickedCore, rightClickedHII); }
        private void toolStripMenuItem_listview_extract_Click(object sender, EventArgs e)
        { ExtractItems_withDialog(rightClickedCore, rightClickedHII); }
        private void ExtractItems_withDialog(FileHiderCore core, List<FileHiderCore.HidenItemInfo> sources)
        {
            if (betterFolderBrowser_ExtractTo.ShowDialog() == DialogResult.OK)
            {
                List<FileHiderCore.RenameStruct> renameList = new List<FileHiderCore.RenameStruct>();
                foreach (FileHiderCore.HidenItemInfo hii in sources)
                    renameList.Add(new FileHiderCore.RenameStruct() { fullName = hii.pathInBase });
                string[] pathesInBase = renameList.Select(a => a.fullName).ToArray();
                if (ExtractPreChecker.CheckHaveAnyExistence(betterFolderBrowser_ExtractTo.SelectedFolder, pathesInBase))
                {
                    switch (MessageBox.Show(this,
                        "Some Files/Dirs already exist:\r\r"
                        + "   Yes - Overwrite\r"
                        + "    No - Rename\r"
                        + "Cancel - Cancel",
                        "Choose a option",
                        MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2))
                    {
                        case DialogResult.Cancel:
                            rightClickedHII.Clear();
                            return;
                        case DialogResult.Yes:
                            //do nothing
                            break;
                        case DialogResult.No:
                            ExtractPreChecker.ReNameExistences(
                                betterFolderBrowser_ExtractTo.SelectedFolder,
                                ref renameList);
                            break;
                    }
                }
                core.Extract_Sync(
                    betterFolderBrowser_ExtractTo.SelectedFolder,
                    renameList.ToArray());
            }
            rightClickedHII.Clear();
        }
        private void toolStripMenuItem_treeview_delete_Click(object sender, EventArgs e)
        {
            FileHiderCore.HidenItemInfo info = (FileHiderCore.HidenItemInfo)rightClickedTreeNode.Tag;
            DeleteItems_withDialog(info.core, rightClickedHII);
        }
        private void toolStripMenuItem_listview_delete_Click(object sender, EventArgs e)
        {
            FileHiderCore.HidenItemInfo info = (FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag;
            DeleteItems_withDialog(info.core, rightClickedHII);
        }
        private void DeleteItems_withDialog(FileHiderCore core, List<FileHiderCore.HidenItemInfo> sources)
        {
            if (MessageBox.Show(this,
                "Selected item(s) will be deleted permanently,\rcontinue?", "Delete items",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)
                == DialogResult.No)
            {
                return;
            }

            core.Delete(rightClickedHII);
            rightClickedHII.Clear();
        }

        private void toolStripMenuItem_treeview_rename_Click(object sender, EventArgs e)
        {
            treeView.LabelEdit = true;
            rightClickedTreeNode.BeginEdit();
        }

        private void toolStripMenuItem_listview_rename_Click(object sender, EventArgs e)
        {
            listView.LabelEdit = true;
            listView.SelectedItems[0].BeginEdit();
        }


        private void treeView_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            string newName = e.Label;
            if (newName == null)
                return;
            e.CancelEdit = true;

            FileHiderCore.HidenItemInfo info = (FileHiderCore.HidenItemInfo)rightClickedTreeNode.Tag;
            info.core.Rename(info.pathInBase, newName);
        }

        private void listView_AfterLabelEdit(object sender, LabelEditEventArgs e)
        {
            string newName = e.Label;
            if (newName == null)
                return;
            e.CancelEdit = true;

            FileHiderCore.HidenItemInfo info = (FileHiderCore.HidenItemInfo)listView.SelectedItems[0].Tag;
            info.core.Rename(info.pathInBase, newName);
            //listView.LabelEdit = false;
        }

        private void listView_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    listView_ActiveItem();
                    break;
                case Keys.Delete:
                    if (listView.SelectedItems.Count > 0)
                    {
                        rightClickedHII.Clear();
                        foreach (ListViewItem lvi in listView.SelectedItems)
                            rightClickedHII.Add((FileHiderCore.HidenItemInfo)lvi.Tag);

                        TreeNode coreTN = treeView_getRootNode(treeView.SelectedNode);
                        DeleteItems_withDialog((FileHiderCore)coreTN.Tag, rightClickedHII);
                    }
                    break;
            }
            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.C:
                        toolStripMenuItem_listview_copy_Click(null, null);
                        break;
                    case Keys.V:
                        toolStripMenuItem_listview_paste_Click(null, null);
                        break;
                }
            }
        }
        private void listView_DoubleClick(object sender, EventArgs e)
        {
            listView_ActiveItem();
        }
        private void listView_ActiveItem()
        {
            if (listView.SelectedItems.Count == 1)
            {
                FileHiderCore.HidenItemInfo hii = (FileHiderCore.HidenItemInfo)listView.SelectedItems[0].Tag;
                if (hii.isDir)
                {
                    if (treeView.SelectedNode == null)
                    {
                        treeView.SelectedNode
                            = treeView.Nodes[FileHiderCore.GetName(hii.pathInBase)];
                    }
                    else
                    {
                        treeView.SelectedNode.Expand();
                        treeView.SelectedNode
                            = treeView.SelectedNode.Nodes[FileHiderCore.GetName(hii.pathInBase)];
                    }
                }
                else
                {
                    List<FileHiderCore.HidenItemInfo> toExtract = new List<FileHiderCore.HidenItemInfo>();
                    toExtract.Add(hii);
                    TreeNode coreTN = treeView_getRootNode(treeView.SelectedNode);
                    ExtractItems_withDialog((FileHiderCore)coreTN.Tag, toExtract);
                }
            }
        }
        private void treeView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete
                && treeView.SelectedNode != null)
            {
                rightClickedCore = (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag;
                rightClickedHII.Add((FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag);
                DeleteItems_withDialog(rightClickedCore, rightClickedHII);
            }
            else if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.C:
                        toolStripMenuItem_treeview_copy_Click(null, null);
                        break;
                    case Keys.V:
                        toolStripMenuItem_treeview_paste_Click(null, null);
                        break;
                }
            }
        }



        private void toolStripMenuItem_listview_copy_Click(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count > 0)
            {
                List<FileHiderCore.HidenItemInfo> sources = new List<FileHiderCore.HidenItemInfo>();
                foreach (ListViewItem lvi in listView.SelectedItems)
                    sources.Add((FileHiderCore.HidenItemInfo)lvi.Tag);

                SetClipBoardOrDrag(sender,
                    (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag,
                    FileHiderCore.GetParentPath(sources[0].pathInBase),
                    false, sources.ToArray());
            }
        }
        private void toolStripMenuItem_treeview_copy_Click(object sender, EventArgs e)
        {
            if (treeView.SelectedNode != null && treeView.SelectedNode.Tag is FileHiderCore.HidenItemInfo)
            {
                FileHiderCore.HidenItemInfo hii = (FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag;
                SetClipBoardOrDrag(sender,
                    (FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag,
                    FileHiderCore.GetParentPath(hii.pathInBase),
                    false, hii);
            }
        }


        private void toolStripMenuItem_listview_paste_Click(object sender, EventArgs e)
        {
            copiedFilesInCB = (string[])Clipboard.GetData(DataFormats.FileDrop);
            if (copiedFilesInCB == null || copiedFilesInCB.Length == 0)
                return;

            InputFiles_withDialog((FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag,
                (treeView.SelectedNode.Tag is FileHiderCore.HidenItemInfo) ?
                    (FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag : null,
                copiedFilesInCB);
        }
        private void toolStripMenuItem_treeview_paste_Click(object sender, EventArgs e)
        {
            copiedFilesInCB = (string[])Clipboard.GetData(DataFormats.FileDrop);
            if (copiedFilesInCB == null || copiedFilesInCB.Length == 0
                || treeView.SelectedNode == null)
                return;

            InputFiles_withDialog((FileHiderCore)treeView_getRootNode(treeView.SelectedNode).Tag,
                (treeView.SelectedNode.Tag is FileHiderCore.HidenItemInfo) ?
                    (FileHiderCore.HidenItemInfo)treeView.SelectedNode.Tag : null,
                copiedFilesInCB);
        }

        #endregion











        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (FileHiderCore core in openedCores)
            {
                if (core.NeedVacuum)
                {
                    SetProgressBarVisible(true);
                    e.Cancel = true;
                    core.Vacuum();
                    core.Dispose();
                }
            }
        }
    }
}
