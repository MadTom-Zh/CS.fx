﻿using MadTomDev.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string testFile = Path.Combine(Application.StartupPath, "tester.data");
            WriteIndex(testFile);
            string[] testing = ReadIndexAllLines(testFile);
        }

        private void WriteIndex(string testFile)
        {


            using (FileStream fsWriter = new FileStream(testFile, FileMode.Create))
            using (EncryptedGZip egz
                = new EncryptedGZip(
                    fsWriter,
                    "abcddddddd",
                    EncryptedGZip.EGZStreamModes.Write_GZipEncrypt))
            {
                byte[] contentBin;
                for (int i = 0; i < 5; i++)
                {
                    contentBin = Encoding.UTF8.GetBytes("testing " + i.ToString() + FileNewLine);
                    egz.RawDataStream.Write(contentBin, 0, contentBin.Length);
                }
                egz.RawDataStream.Flush();
                fsWriter.Flush();
            }
        }

        private string FileNewLine = "\r\n";
        private string[] ReadIndexAllLines(string testFile)
        {
            //EncryptedGZip.UnGZipDecrypt


            using (FileStream fsReader = new FileStream(testFile, FileMode.Open))
            using (EncryptedGZip egz
                = new EncryptedGZip(
                    fsReader,
                    "abcddddddd",
                    EncryptedGZip.EGZStreamModes.Read_DecryptUnGZip))
            using (StreamReader sReader = new StreamReader(egz.RawDataStream))
            {
                return sReader.ReadToEnd().Split(new string[] { FileNewLine }, StringSplitOptions.RemoveEmptyEntries);
            }
        }
    }
}
