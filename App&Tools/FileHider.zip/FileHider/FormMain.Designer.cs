﻿namespace MadTomDev.App
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_adr = new System.Windows.Forms.TextBox();
            this.button_adrGo = new System.Windows.Forms.Button();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.button_hoClose = new System.Windows.Forms.Button();
            this.button_hoOpen = new System.Windows.Forms.Button();
            this.treeView = new System.Windows.Forms.TreeView();
            this.contextMenuStrip_treeView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_openHideout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_closeHideout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator_openCloseHideout = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_treeview_colExp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_treeview_copy = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_treeview_paste = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_treeview_extract = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_treeview_rename = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_treeview_delete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.imageList_State = new System.Windows.Forms.ImageList(this.components);
            this.listView = new System.Windows.Forms.ListView();
            this.ItmName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Suffix = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cLength = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PkgIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ItmIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LastWriteTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip_listView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_listview_copy = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_listview_paste = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_listview_extract = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_listview_rename = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_listview_delete = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_prg = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar_prg = new System.Windows.Forms.ToolStripProgressBar();
            this.betterFolderBrowser_selectHO = new WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.betterFolderBrowser_ExtractTo = new WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.contextMenuStrip_treeView.SuspendLayout();
            this.contextMenuStrip_listView.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hideout:";
            // 
            // textBox_adr
            // 
            this.textBox_adr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_adr.Location = new System.Drawing.Point(0, 6);
            this.textBox_adr.Name = "textBox_adr";
            this.textBox_adr.Size = new System.Drawing.Size(476, 20);
            this.textBox_adr.TabIndex = 1;
            // 
            // button_adrGo
            // 
            this.button_adrGo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_adrGo.Location = new System.Drawing.Point(477, 3);
            this.button_adrGo.Name = "button_adrGo";
            this.button_adrGo.Size = new System.Drawing.Size(35, 26);
            this.button_adrGo.TabIndex = 2;
            this.button_adrGo.Text = "Go";
            this.button_adrGo.UseVisualStyleBackColor = true;
            this.button_adrGo.Click += new System.EventHandler(this.button_adrGo_Click);
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.button_hoClose);
            this.splitContainer.Panel1.Controls.Add(this.button_hoOpen);
            this.splitContainer.Panel1.Controls.Add(this.treeView);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.listView);
            this.splitContainer.Panel2.Controls.Add(this.textBox_adr);
            this.splitContainer.Panel2.Controls.Add(this.button_adrGo);
            this.splitContainer.Size = new System.Drawing.Size(800, 428);
            this.splitContainer.SplitterDistance = 265;
            this.splitContainer.SplitterWidth = 8;
            this.splitContainer.TabIndex = 3;
            // 
            // button_hoClose
            // 
            this.button_hoClose.Location = new System.Drawing.Point(77, 3);
            this.button_hoClose.Name = "button_hoClose";
            this.button_hoClose.Size = new System.Drawing.Size(75, 26);
            this.button_hoClose.TabIndex = 2;
            this.button_hoClose.Text = "Close...";
            this.button_hoClose.UseVisualStyleBackColor = true;
            this.button_hoClose.Click += new System.EventHandler(this.button_hoClose_Click);
            // 
            // button_hoOpen
            // 
            this.button_hoOpen.Location = new System.Drawing.Point(3, 3);
            this.button_hoOpen.Name = "button_hoOpen";
            this.button_hoOpen.Size = new System.Drawing.Size(75, 26);
            this.button_hoOpen.TabIndex = 1;
            this.button_hoOpen.Text = "Open...";
            this.button_hoOpen.UseVisualStyleBackColor = true;
            this.button_hoOpen.Click += new System.EventHandler(this.button_hoOpen_Click);
            // 
            // treeView
            // 
            this.treeView.AllowDrop = true;
            this.treeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView.ContextMenuStrip = this.contextMenuStrip_treeView;
            this.treeView.HideSelection = false;
            this.treeView.ImageIndex = 0;
            this.treeView.ImageList = this.imageList;
            this.treeView.LabelEdit = true;
            this.treeView.Location = new System.Drawing.Point(3, 31);
            this.treeView.Name = "treeView";
            this.treeView.SelectedImageIndex = 0;
            this.treeView.ShowNodeToolTips = true;
            this.treeView.Size = new System.Drawing.Size(262, 397);
            this.treeView.StateImageList = this.imageList_State;
            this.treeView.TabIndex = 0;
            this.treeView.BeforeLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.treeView_BeforeLabelEdit);
            this.treeView.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.treeView_AfterLabelEdit);
            this.treeView.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterCollapse);
            this.treeView.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeExpand);
            this.treeView.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterExpand);
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            this.treeView.DragDrop += new System.Windows.Forms.DragEventHandler(this.TreeView_DragDrop);
            this.treeView.DragEnter += new System.Windows.Forms.DragEventHandler(this.TreeView_DragEnter);
            this.treeView.DragOver += new System.Windows.Forms.DragEventHandler(this.TreeView_DragOver);
            this.treeView.DragLeave += new System.EventHandler(this.TreeView_DragLeave);
            this.treeView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeView_KeyDown);
            this.treeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseDown);
            this.treeView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseMove);
            this.treeView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseUp);
            // 
            // contextMenuStrip_treeView
            // 
            this.contextMenuStrip_treeView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_openHideout,
            this.toolStripMenuItem_closeHideout,
            this.toolStripSeparator_openCloseHideout,
            this.toolStripMenuItem_treeview_colExp,
            this.toolStripSeparator1,
            this.toolStripMenuItem_treeview_copy,
            this.toolStripMenuItem_treeview_paste,
            this.toolStripMenuItem_treeview_extract,
            this.toolStripSeparator2,
            this.toolStripMenuItem_treeview_rename,
            this.toolStripMenuItem_treeview_delete,
            this.toolStripSeparator4});
            this.contextMenuStrip_treeView.Name = "contextMenuStrip_treeView";
            this.contextMenuStrip_treeView.Size = new System.Drawing.Size(189, 204);
            this.contextMenuStrip_treeView.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip_treeView_Opening);
            // 
            // toolStripMenuItem_openHideout
            // 
            this.toolStripMenuItem_openHideout.Name = "toolStripMenuItem_openHideout";
            this.toolStripMenuItem_openHideout.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_openHideout.Text = "Open Hideout...";
            this.toolStripMenuItem_openHideout.Click += new System.EventHandler(this.toolStripMenuItem_openHideout_Click);
            // 
            // toolStripMenuItem_closeHideout
            // 
            this.toolStripMenuItem_closeHideout.Name = "toolStripMenuItem_closeHideout";
            this.toolStripMenuItem_closeHideout.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_closeHideout.Text = "Close Hideout...";
            this.toolStripMenuItem_closeHideout.Click += new System.EventHandler(this.toolStripMenuItem_closeHideout_Click);
            // 
            // toolStripSeparator_openCloseHideout
            // 
            this.toolStripSeparator_openCloseHideout.Name = "toolStripSeparator_openCloseHideout";
            this.toolStripSeparator_openCloseHideout.Size = new System.Drawing.Size(185, 6);
            // 
            // toolStripMenuItem_treeview_colExp
            // 
            this.toolStripMenuItem_treeview_colExp.Name = "toolStripMenuItem_treeview_colExp";
            this.toolStripMenuItem_treeview_colExp.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_treeview_colExp.Text = "Collapse/Expand";
            this.toolStripMenuItem_treeview_colExp.Click += new System.EventHandler(this.toolStripMenuItem_treeview_colExp_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(185, 6);
            // 
            // toolStripMenuItem_treeview_copy
            // 
            this.toolStripMenuItem_treeview_copy.Name = "toolStripMenuItem_treeview_copy";
            this.toolStripMenuItem_treeview_copy.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_treeview_copy.Text = "Copy (not supported)";
            this.toolStripMenuItem_treeview_copy.Click += new System.EventHandler(this.toolStripMenuItem_treeview_copy_Click);
            // 
            // toolStripMenuItem_treeview_paste
            // 
            this.toolStripMenuItem_treeview_paste.Name = "toolStripMenuItem_treeview_paste";
            this.toolStripMenuItem_treeview_paste.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_treeview_paste.Text = "Paste";
            this.toolStripMenuItem_treeview_paste.Click += new System.EventHandler(this.toolStripMenuItem_treeview_paste_Click);
            // 
            // toolStripMenuItem_treeview_extract
            // 
            this.toolStripMenuItem_treeview_extract.Name = "toolStripMenuItem_treeview_extract";
            this.toolStripMenuItem_treeview_extract.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_treeview_extract.Text = "Extract...";
            this.toolStripMenuItem_treeview_extract.Click += new System.EventHandler(this.toolStripMenuItem_treeview_extract_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(185, 6);
            // 
            // toolStripMenuItem_treeview_rename
            // 
            this.toolStripMenuItem_treeview_rename.Name = "toolStripMenuItem_treeview_rename";
            this.toolStripMenuItem_treeview_rename.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_treeview_rename.Text = "Rename";
            this.toolStripMenuItem_treeview_rename.Click += new System.EventHandler(this.toolStripMenuItem_treeview_rename_Click);
            // 
            // toolStripMenuItem_treeview_delete
            // 
            this.toolStripMenuItem_treeview_delete.Name = "toolStripMenuItem_treeview_delete";
            this.toolStripMenuItem_treeview_delete.Size = new System.Drawing.Size(188, 22);
            this.toolStripMenuItem_treeview_delete.Text = "Delete...";
            this.toolStripMenuItem_treeview_delete.Click += new System.EventHandler(this.toolStripMenuItem_treeview_delete_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(185, 6);
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, ".HideOutRoot");
            // 
            // imageList_State
            // 
            this.imageList_State.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList_State.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList_State.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listView
            // 
            this.listView.AllowDrop = true;
            this.listView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ItmName,
            this.Suffix,
            this.cLength,
            this.PkgIndex,
            this.ItmIndex,
            this.LastWriteTime});
            this.listView.ContextMenuStrip = this.contextMenuStrip_listView;
            this.listView.FullRowSelect = true;
            this.listView.HideSelection = false;
            this.listView.LabelEdit = true;
            this.listView.Location = new System.Drawing.Point(0, 30);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(512, 398);
            this.listView.SmallImageList = this.imageList;
            this.listView.StateImageList = this.imageList_State;
            this.listView.TabIndex = 0;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.AfterLabelEdit += new System.Windows.Forms.LabelEditEventHandler(this.listView_AfterLabelEdit);
            this.listView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView_ColumnClick);
            this.listView.DragDrop += new System.Windows.Forms.DragEventHandler(this.ListView_DragDrop);
            this.listView.DragEnter += new System.Windows.Forms.DragEventHandler(this.ListView_DragEnter);
            this.listView.DragOver += new System.Windows.Forms.DragEventHandler(this.ListView_DragOver);
            this.listView.DragLeave += new System.EventHandler(this.ListView_DragLeave);
            this.listView.DoubleClick += new System.EventHandler(this.listView_DoubleClick);
            this.listView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listView_KeyDown);
            this.listView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView_MouseDown);
            this.listView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.listView_MouseMove);
            this.listView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.listView_MouseUp);
            // 
            // ItmName
            // 
            this.ItmName.Text = "ItmName";
            // 
            // Suffix
            // 
            this.Suffix.Text = "Suffix";
            // 
            // cLength
            // 
            this.cLength.Text = "Length";
            this.cLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // PkgIndex
            // 
            this.PkgIndex.Text = "PkgIndex";
            // 
            // ItmIndex
            // 
            this.ItmIndex.Text = "ItmIndex";
            // 
            // LastWriteTime
            // 
            this.LastWriteTime.Text = "LastWriteTime";
            // 
            // contextMenuStrip_listView
            // 
            this.contextMenuStrip_listView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_listview_copy,
            this.toolStripMenuItem_listview_paste,
            this.toolStripMenuItem_listview_extract,
            this.toolStripSeparator3,
            this.toolStripMenuItem_listview_rename,
            this.toolStripMenuItem_listview_delete});
            this.contextMenuStrip_listView.Name = "contextMenuStrip_listView";
            this.contextMenuStrip_listView.Size = new System.Drawing.Size(119, 120);
            this.contextMenuStrip_listView.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip_listView_Opening);
            // 
            // toolStripMenuItem_listview_copy
            // 
            this.toolStripMenuItem_listview_copy.Name = "toolStripMenuItem_listview_copy";
            this.toolStripMenuItem_listview_copy.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem_listview_copy.Text = "Copy";
            this.toolStripMenuItem_listview_copy.Click += new System.EventHandler(this.toolStripMenuItem_listview_copy_Click);
            // 
            // toolStripMenuItem_listview_paste
            // 
            this.toolStripMenuItem_listview_paste.Name = "toolStripMenuItem_listview_paste";
            this.toolStripMenuItem_listview_paste.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem_listview_paste.Text = "Paste";
            this.toolStripMenuItem_listview_paste.Click += new System.EventHandler(this.toolStripMenuItem_listview_paste_Click);
            // 
            // toolStripMenuItem_listview_extract
            // 
            this.toolStripMenuItem_listview_extract.Name = "toolStripMenuItem_listview_extract";
            this.toolStripMenuItem_listview_extract.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem_listview_extract.Text = "Extract...";
            this.toolStripMenuItem_listview_extract.Click += new System.EventHandler(this.toolStripMenuItem_listview_extract_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(115, 6);
            // 
            // toolStripMenuItem_listview_rename
            // 
            this.toolStripMenuItem_listview_rename.Name = "toolStripMenuItem_listview_rename";
            this.toolStripMenuItem_listview_rename.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem_listview_rename.Text = "Rename";
            this.toolStripMenuItem_listview_rename.Click += new System.EventHandler(this.toolStripMenuItem_listview_rename_Click);
            // 
            // toolStripMenuItem_listview_delete
            // 
            this.toolStripMenuItem_listview_delete.Name = "toolStripMenuItem_listview_delete";
            this.toolStripMenuItem_listview_delete.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem_listview_delete.Text = "Delete...";
            this.toolStripMenuItem_listview_delete.Click += new System.EventHandler(this.toolStripMenuItem_listview_delete_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_info,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel_prg,
            this.toolStripProgressBar_prg});
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(59, 17);
            this.toolStripStatusLabel_info.Text = "Loading...";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.AutoSize = false;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(572, 17);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // toolStripStatusLabel_prg
            // 
            this.toolStripStatusLabel_prg.Name = "toolStripStatusLabel_prg";
            this.toolStripStatusLabel_prg.Size = new System.Drawing.Size(52, 17);
            this.toolStripStatusLabel_prg.Text = "Prg(#/#)";
            // 
            // toolStripProgressBar_prg
            // 
            this.toolStripProgressBar_prg.Name = "toolStripProgressBar_prg";
            this.toolStripProgressBar_prg.Size = new System.Drawing.Size(100, 16);
            // 
            // betterFolderBrowser_selectHO
            // 
            this.betterFolderBrowser_selectHO.Multiselect = false;
            this.betterFolderBrowser_selectHO.RootFolder = "C:\\Personal\\Desktop";
            this.betterFolderBrowser_selectHO.Title = "Please select a HideOut...";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // betterFolderBrowser_ExtractTo
            // 
            this.betterFolderBrowser_ExtractTo.Multiselect = false;
            this.betterFolderBrowser_ExtractTo.RootFolder = "C:\\Personal\\Desktop";
            this.betterFolderBrowser_ExtractTo.Title = "Extract to...";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "FileHider by longtombbj 2019 1230";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.contextMenuStrip_treeView.ResumeLayout(false);
            this.contextMenuStrip_listView.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_adr;
        private System.Windows.Forms.Button button_adrGo;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.ColumnHeader ItmName;
        private System.Windows.Forms.ColumnHeader Suffix;
        private System.Windows.Forms.ColumnHeader PkgIndex;
        private System.Windows.Forms.ColumnHeader ItmIndex;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_prg;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar_prg;
        private WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser betterFolderBrowser_selectHO;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ImageList imageList_State;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_treeView;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_treeview_colExp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_treeview_extract;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_treeview_delete;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_listView;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_listview_extract;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_listview_delete;
        private WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser betterFolderBrowser_ExtractTo;
        private System.Windows.Forms.Button button_hoClose;
        private System.Windows.Forms.Button button_hoOpen;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_openHideout;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_closeHideout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator_openCloseHideout;
        private System.Windows.Forms.ColumnHeader cLength;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_treeview_copy;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_listview_copy;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_treeview_paste;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_listview_paste;
        private System.Windows.Forms.ColumnHeader LastWriteTime;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_treeview_rename;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_listview_rename;
    }
}

