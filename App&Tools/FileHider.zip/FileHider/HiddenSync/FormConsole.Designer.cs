﻿namespace MadTomDev.App
{
    partial class FormConsole
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormConsole));
            this.button_exit = new System.Windows.Forms.Button();
            this.button_hide = new System.Windows.Forms.Button();
            this.button_config = new System.Windows.Forms.Button();
            this.button_syncO2H = new System.Windows.Forms.Button();
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip_notify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_console = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_syncO2H = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_syncH2O = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_fullSync = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_config = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_viewLogFiles = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox_states = new System.Windows.Forms.GroupBox();
            this.alphaPanel1 = new MadTomDev.UIs.UserControls.AlphaPanel();
            this.label_lastSyncTime = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_dirsReady = new System.Windows.Forms.CheckBox();
            this.groupBox_backup = new System.Windows.Forms.GroupBox();
            this.alphaPanel2 = new MadTomDev.UIs.UserControls.AlphaPanel();
            this.label_bk_info = new System.Windows.Forms.Label();
            this.checkBox_bk_changed = new System.Windows.Forms.CheckBox();
            this.checkBox_bk_deleted = new System.Windows.Forms.CheckBox();
            this.uC_LogView = new MadTomDev.App.Ctrls.UC_LogView();
            this.button_explorer = new System.Windows.Forms.Button();
            this.button_syncH2O = new System.Windows.Forms.Button();
            this.button_syncBothWay = new System.Windows.Forms.Button();
            this.contextMenuStrip_notify.SuspendLayout();
            this.groupBox_states.SuspendLayout();
            this.groupBox_backup.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_exit
            // 
            this.button_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_exit.ForeColor = System.Drawing.Color.Maroon;
            this.button_exit.Location = new System.Drawing.Point(772, 561);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(94, 48);
            this.button_exit.TabIndex = 10;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_hide
            // 
            this.button_hide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_hide.Location = new System.Drawing.Point(772, 512);
            this.button_hide.Name = "button_hide";
            this.button_hide.Size = new System.Drawing.Size(94, 48);
            this.button_hide.TabIndex = 9;
            this.button_hide.Text = "Hide";
            this.button_hide.UseVisualStyleBackColor = true;
            this.button_hide.Click += new System.EventHandler(this.button_hide_Click);
            // 
            // button_config
            // 
            this.button_config.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_config.Location = new System.Drawing.Point(772, 162);
            this.button_config.Name = "button_config";
            this.button_config.Size = new System.Drawing.Size(94, 48);
            this.button_config.TabIndex = 8;
            this.button_config.Text = "Config...";
            this.button_config.UseVisualStyleBackColor = true;
            this.button_config.Click += new System.EventHandler(this.button_config_Click);
            // 
            // button_syncO2H
            // 
            this.button_syncO2H.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_syncO2H.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button_syncO2H.Location = new System.Drawing.Point(772, 11);
            this.button_syncO2H.Name = "button_syncO2H";
            this.button_syncO2H.Size = new System.Drawing.Size(94, 48);
            this.button_syncO2H.TabIndex = 7;
            this.button_syncO2H.Text = "Sync O->H";
            this.button_syncO2H.UseVisualStyleBackColor = false;
            this.button_syncO2H.Click += new System.EventHandler(this.button_syncO2H_Click);
            // 
            // notifyIcon
            // 
            this.notifyIcon.ContextMenuStrip = this.contextMenuStrip_notify;
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Visible = true;
            this.notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseDoubleClick);
            // 
            // contextMenuStrip_notify
            // 
            this.contextMenuStrip_notify.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.contextMenuStrip_notify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_console,
            this.toolStripMenuItem_syncO2H,
            this.toolStripMenuItem_syncH2O,
            this.toolStripMenuItem_fullSync,
            this.toolStripMenuItem_config,
            this.toolStripSeparator1,
            this.toolStripMenuItem_viewLogFiles,
            this.toolStripSeparator2,
            this.toolStripMenuItem_exit});
            this.contextMenuStrip_notify.Name = "contextMenuStrip_notify";
            this.contextMenuStrip_notify.Size = new System.Drawing.Size(225, 226);
            // 
            // toolStripMenuItem_console
            // 
            this.toolStripMenuItem_console.Name = "toolStripMenuItem_console";
            this.toolStripMenuItem_console.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_console.Text = "Console...";
            this.toolStripMenuItem_console.Click += new System.EventHandler(this.toolStripMenuItem_console_Click);
            // 
            // toolStripMenuItem_syncO2H
            // 
            this.toolStripMenuItem_syncO2H.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toolStripMenuItem_syncO2H.Name = "toolStripMenuItem_syncO2H";
            this.toolStripMenuItem_syncO2H.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_syncO2H.Text = "Sync O->H";
            this.toolStripMenuItem_syncO2H.Click += new System.EventHandler(this.toolStripMenuItem_syncO2H_Click);
            // 
            // toolStripMenuItem_syncH2O
            // 
            this.toolStripMenuItem_syncH2O.ForeColor = System.Drawing.Color.Teal;
            this.toolStripMenuItem_syncH2O.Name = "toolStripMenuItem_syncH2O";
            this.toolStripMenuItem_syncH2O.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_syncH2O.Text = "Sync H->O";
            this.toolStripMenuItem_syncH2O.Click += new System.EventHandler(this.toolStripMenuItem_syncH2O_Click);
            // 
            // toolStripMenuItem_fullSync
            // 
            this.toolStripMenuItem_fullSync.ForeColor = System.Drawing.Color.Green;
            this.toolStripMenuItem_fullSync.Name = "toolStripMenuItem_fullSync";
            this.toolStripMenuItem_fullSync.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_fullSync.Text = "Full Sync";
            this.toolStripMenuItem_fullSync.Click += new System.EventHandler(this.toolStripMenuItem_fullSync_Click);
            // 
            // toolStripMenuItem_config
            // 
            this.toolStripMenuItem_config.Name = "toolStripMenuItem_config";
            this.toolStripMenuItem_config.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_config.Text = "Config...";
            this.toolStripMenuItem_config.Click += new System.EventHandler(this.toolStripMenuItem_config_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(221, 6);
            // 
            // toolStripMenuItem_viewLogFiles
            // 
            this.toolStripMenuItem_viewLogFiles.Name = "toolStripMenuItem_viewLogFiles";
            this.toolStripMenuItem_viewLogFiles.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_viewLogFiles.Text = "View Log Files...";
            this.toolStripMenuItem_viewLogFiles.Click += new System.EventHandler(this.toolStripMenuItem_viewLogFiles_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(221, 6);
            // 
            // toolStripMenuItem_exit
            // 
            this.toolStripMenuItem_exit.ForeColor = System.Drawing.Color.Maroon;
            this.toolStripMenuItem_exit.Name = "toolStripMenuItem_exit";
            this.toolStripMenuItem_exit.Size = new System.Drawing.Size(224, 30);
            this.toolStripMenuItem_exit.Text = "Exit";
            this.toolStripMenuItem_exit.Click += new System.EventHandler(this.toolStripMenuItem_exit_Click);
            // 
            // groupBox_states
            // 
            this.groupBox_states.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_states.Controls.Add(this.alphaPanel1);
            this.groupBox_states.Controls.Add(this.label_lastSyncTime);
            this.groupBox_states.Controls.Add(this.label1);
            this.groupBox_states.Controls.Add(this.checkBox_dirsReady);
            this.groupBox_states.Location = new System.Drawing.Point(772, 211);
            this.groupBox_states.Name = "groupBox_states";
            this.groupBox_states.Size = new System.Drawing.Size(94, 84);
            this.groupBox_states.TabIndex = 11;
            this.groupBox_states.TabStop = false;
            this.groupBox_states.Text = "States";
            // 
            // alphaPanel1
            // 
            this.alphaPanel1.Location = new System.Drawing.Point(4, 17);
            this.alphaPanel1.Name = "alphaPanel1";
            this.alphaPanel1.Size = new System.Drawing.Size(90, 20);
            this.alphaPanel1.TabIndex = 3;
            // 
            // label_lastSyncTime
            // 
            this.label_lastSyncTime.AutoSize = true;
            this.label_lastSyncTime.Location = new System.Drawing.Point(4, 52);
            this.label_lastSyncTime.Name = "label_lastSyncTime";
            this.label_lastSyncTime.Size = new System.Drawing.Size(84, 26);
            this.label_lastSyncTime.TabIndex = 2;
            this.label_lastSyncTime.Text = "yyyy-MM-dd\r\nHH:mm (000.0h)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Last Sync";
            // 
            // checkBox_dirsReady
            // 
            this.checkBox_dirsReady.AutoSize = true;
            this.checkBox_dirsReady.BackColor = System.Drawing.SystemColors.Control;
            this.checkBox_dirsReady.Location = new System.Drawing.Point(7, 20);
            this.checkBox_dirsReady.Name = "checkBox_dirsReady";
            this.checkBox_dirsReady.Size = new System.Drawing.Size(78, 17);
            this.checkBox_dirsReady.TabIndex = 0;
            this.checkBox_dirsReady.TabStop = false;
            this.checkBox_dirsReady.Text = "Dirs Ready";
            this.checkBox_dirsReady.UseVisualStyleBackColor = false;
            // 
            // groupBox_backup
            // 
            this.groupBox_backup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_backup.Controls.Add(this.alphaPanel2);
            this.groupBox_backup.Controls.Add(this.label_bk_info);
            this.groupBox_backup.Controls.Add(this.checkBox_bk_changed);
            this.groupBox_backup.Controls.Add(this.checkBox_bk_deleted);
            this.groupBox_backup.Location = new System.Drawing.Point(772, 301);
            this.groupBox_backup.Name = "groupBox_backup";
            this.groupBox_backup.Size = new System.Drawing.Size(94, 91);
            this.groupBox_backup.TabIndex = 13;
            this.groupBox_backup.TabStop = false;
            this.groupBox_backup.Text = "Backup";
            // 
            // alphaPanel2
            // 
            this.alphaPanel2.Location = new System.Drawing.Point(4, 17);
            this.alphaPanel2.Name = "alphaPanel2";
            this.alphaPanel2.Size = new System.Drawing.Size(90, 37);
            this.alphaPanel2.TabIndex = 3;
            // 
            // label_bk_info
            // 
            this.label_bk_info.AutoSize = true;
            this.label_bk_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bk_info.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label_bk_info.Location = new System.Drawing.Point(6, 57);
            this.label_bk_info.Name = "label_bk_info";
            this.label_bk_info.Size = new System.Drawing.Size(67, 26);
            this.label_bk_info.TabIndex = 3;
            this.label_bk_info.Text = "999.99 GB\r\n999.99 kfs";
            this.label_bk_info.Click += new System.EventHandler(this.label_bk_info_Click);
            // 
            // checkBox_bk_changed
            // 
            this.checkBox_bk_changed.AutoSize = true;
            this.checkBox_bk_changed.BackColor = System.Drawing.SystemColors.Control;
            this.checkBox_bk_changed.Location = new System.Drawing.Point(7, 37);
            this.checkBox_bk_changed.Name = "checkBox_bk_changed";
            this.checkBox_bk_changed.Size = new System.Drawing.Size(82, 17);
            this.checkBox_bk_changed.TabIndex = 2;
            this.checkBox_bk_changed.TabStop = false;
            this.checkBox_bk_changed.Text = "BkChanged";
            this.checkBox_bk_changed.UseVisualStyleBackColor = false;
            // 
            // checkBox_bk_deleted
            // 
            this.checkBox_bk_deleted.AutoSize = true;
            this.checkBox_bk_deleted.BackColor = System.Drawing.SystemColors.Control;
            this.checkBox_bk_deleted.Location = new System.Drawing.Point(7, 19);
            this.checkBox_bk_deleted.Name = "checkBox_bk_deleted";
            this.checkBox_bk_deleted.Size = new System.Drawing.Size(76, 17);
            this.checkBox_bk_deleted.TabIndex = 1;
            this.checkBox_bk_deleted.TabStop = false;
            this.checkBox_bk_deleted.Text = "BkDeleted";
            this.checkBox_bk_deleted.UseVisualStyleBackColor = false;
            // 
            // uC_LogView
            // 
            this.uC_LogView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uC_LogView.IsButtonClearEnabled = true;
            this.uC_LogView.Location = new System.Drawing.Point(12, 12);
            this.uC_LogView.Name = "uC_LogView";
            this.uC_LogView.Size = new System.Drawing.Size(754, 596);
            this.uC_LogView.TabIndex = 0;
            // 
            // button_explorer
            // 
            this.button_explorer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_explorer.Location = new System.Drawing.Point(772, 398);
            this.button_explorer.Name = "button_explorer";
            this.button_explorer.Size = new System.Drawing.Size(94, 22);
            this.button_explorer.TabIndex = 14;
            this.button_explorer.Text = "Explorer";
            this.button_explorer.UseVisualStyleBackColor = true;
            this.button_explorer.Click += new System.EventHandler(this.button_explorer_Click);
            // 
            // button_syncH2O
            // 
            this.button_syncH2O.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_syncH2O.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button_syncH2O.Location = new System.Drawing.Point(772, 60);
            this.button_syncH2O.Name = "button_syncH2O";
            this.button_syncH2O.Size = new System.Drawing.Size(94, 48);
            this.button_syncH2O.TabIndex = 7;
            this.button_syncH2O.Text = "Sync H->O";
            this.button_syncH2O.UseVisualStyleBackColor = false;
            this.button_syncH2O.Click += new System.EventHandler(this.button_syncH2O_Click);
            // 
            // button_syncBothWay
            // 
            this.button_syncBothWay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_syncBothWay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button_syncBothWay.Location = new System.Drawing.Point(772, 109);
            this.button_syncBothWay.Name = "button_syncBothWay";
            this.button_syncBothWay.Size = new System.Drawing.Size(94, 48);
            this.button_syncBothWay.TabIndex = 7;
            this.button_syncBothWay.Text = "Sync BothWay";
            this.button_syncBothWay.UseVisualStyleBackColor = false;
            this.button_syncBothWay.Click += new System.EventHandler(this.button_syncBothWay_Click);
            // 
            // FormConsole
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 620);
            this.Controls.Add(this.button_explorer);
            this.Controls.Add(this.groupBox_backup);
            this.Controls.Add(this.groupBox_states);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_hide);
            this.Controls.Add(this.button_config);
            this.Controls.Add(this.button_syncBothWay);
            this.Controls.Add(this.button_syncH2O);
            this.Controls.Add(this.button_syncO2H);
            this.Controls.Add(this.uC_LogView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormConsole";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HiddenSync by longtombbj 2020 1124";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormConsole_FormClosing);
            this.Load += new System.EventHandler(this.FormConsole_Load);
            this.Shown += new System.EventHandler(this.FormConsole_Shown);
            this.SizeChanged += new System.EventHandler(this.FormConsole_SizeChanged);
            this.contextMenuStrip_notify.ResumeLayout(false);
            this.groupBox_states.ResumeLayout(false);
            this.groupBox_states.PerformLayout();
            this.groupBox_backup.ResumeLayout(false);
            this.groupBox_backup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Ctrls.UC_LogView uC_LogView;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_hide;
        private System.Windows.Forms.Button button_config;
        private System.Windows.Forms.Button button_syncO2H;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_notify;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_console;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_fullSync;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_config;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_viewLogFiles;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_exit;
        private System.Windows.Forms.GroupBox groupBox_states;
        private System.Windows.Forms.CheckBox checkBox_dirsReady;
        private System.Windows.Forms.Label label_lastSyncTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox_backup;
        private System.Windows.Forms.Label label_bk_info;
        private System.Windows.Forms.CheckBox checkBox_bk_changed;
        private System.Windows.Forms.CheckBox checkBox_bk_deleted;
        private System.Windows.Forms.Button button_explorer;
        private UIs.UserControls.AlphaPanel alphaPanel1;
        private UIs.UserControls.AlphaPanel alphaPanel2;
        private System.Windows.Forms.Button button_syncH2O;
        private System.Windows.Forms.Button button_syncBothWay;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_syncO2H;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_syncH2O;
    }
}

