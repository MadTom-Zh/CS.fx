﻿using MadTomDev.App.Classes;
using MadTomDev.CommonClasses;
using MadTomDev.UIs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class FormHExplorer : Form
    {
        public FormHExplorer(Core core)
        {
            InitializeComponent();
            this.core = core;
        }

        private Core core;
        private IOIcons ioIcons;
        private static string iconDirKey = "DIR";
        private static string iconDirKeyNE = "DIR.NE";
        private string tmpDir = Path.Combine(Application.StartupPath, "tmp");
        ListViewSorter lvSorter;
        private void FormHExplorer_Shown(object sender, EventArgs e)
        {
            treeView.Sort();

            lvSorter = new ListViewSorter(listView);
            lvSorter.SetColumnsTypes(
                ListViewSorterCore.ColumnTypes.Custom,
                ListViewSorterCore.ColumnTypes.Custom,
                ListViewSorterCore.ColumnTypes.Text,
                ListViewSorterCore.ColumnTypes.DateTime,
                ListViewSorterCore.ColumnTypes.DateTime,
                ListViewSorterCore.ColumnTypes.DateTime);
            lvSorter.SetCustomComparator(0, new ListViewSorterCore.CustomCompare((a, b) =>
            {
                ListViewItem lviA = (ListViewItem)a, lviB = (ListViewItem)b;
                string strA, strB;
                HFileSystemInfo hi;
                if (lviA.Tag is HFileSystemInfo)
                {
                    hi = (HFileSystemInfo)lviA.Tag;
                    if (!hi.isDirectory)
                        strA = lviA.Text;
                    else
                        strA = "   " + lviA.Text;
                }
                else
                {
                    strA = "   " + lviA.Text;
                }
                if (lviB.Tag is HFileSystemInfo)
                {
                    hi = (HFileSystemInfo)lviB.Tag;
                    if (!hi.isDirectory)
                        strB = lviB.Text;
                    else
                        strB = "   " + lviB.Text;
                }
                else
                {
                    strB = "   " + lviB.Text;
                }
                int i = 0;
                strA = strA.ToLower();
                strB = strB.ToLower();
                char ca, cb;
                while (true)
                {
                    if (strA.Length <= i && strB.Length > i)
                        return -1;
                    else if (strA.Length > i && strB.Length <= i)
                        return 1;
                    ca = strA[i]; cb = strB[i];
                    if (ca < cb)
                        return -1;
                    else if (ca > cb)
                        return 1;
                    i++;
                }
            }));
            lvSorter.SetCustomComparator(1, new ListViewSorterCore.CustomCompare((a, b) =>
            {
                ListViewItem lviA = (ListViewItem)a, lviB = (ListViewItem)b;
                long sizeA = 0, sizeB = 0;
                if (lviA.Tag is HFileSystemInfo)
                    sizeA = ((HFileSystemInfo)lviA.Tag).size;
                if (lviB.Tag is HFileSystemInfo)
                    sizeB = ((HFileSystemInfo)lviB.Tag).size;
                if (sizeA <= sizeB)
                    return -1;
                else
                    return 1;
            }));

            ioIcons = IOIcons.GetInstance();
            imageList_files.Images.Add(iconDirKey, ioIcons.GetDirIcon());
            MakeAlphaIcon(iconDirKey);
            MakeDirNEIcon();
            button_reload_Click(sender, e);
        }
        private string alphaIconKeySuffix = "@alpha50";
        private void MakeAlphaIcon(string iconKey)
        {
            string alphaIconKey = iconKey + alphaIconKeySuffix;
            if (imageList_files.Images.ContainsKey(alphaIconKey))
                return;
            if (imageList_files.Images.ContainsKey(iconKey))
            {
                Image oriImg = imageList_files.Images[iconKey];
                Bitmap alphaImg = new Bitmap(oriImg.Width, oriImg.Height);

                using (Graphics gr = Graphics.FromImage(alphaImg))
                {
                    ColorMatrix colorMatrix = new ColorMatrix();
                    colorMatrix.Matrix33 = 0.5f;

                    ImageAttributes attributes = new ImageAttributes();
                    attributes.SetColorMatrix(colorMatrix,
                        ColorMatrixFlag.Default, ColorAdjustType.Bitmap);

                    Rectangle rect = new Rectangle(0, 0,
                        alphaImg.Width, alphaImg.Height);

                    gr.DrawImage(oriImg, rect,
                        0, 0, oriImg.Width, oriImg.Height,
                        GraphicsUnit.Pixel, attributes);
                }
                imageList_files.Images.Add(alphaIconKey, alphaImg);
            }
        }
        private void MakeDirNEIcon()
        {
            if (imageList_files.Images.ContainsKey(iconDirKeyNE))
                return;
            if (imageList_files.Images.ContainsKey(iconDirKey))
            {
                Image oriImg = imageList_files.Images[iconDirKey];
                Bitmap dirNEImg = new Bitmap(oriImg.Width, oriImg.Height);

                using (Graphics gr = Graphics.FromImage(dirNEImg))
                {
                    gr.DrawImage(oriImg, 0, 0);
                    using (Brush brush = new SolidBrush(Color.OrangeRed))
                    using (Pen pen = new Pen(brush))
                        gr.DrawRectangle(pen, 0.5f, 0.5f, oriImg.Width - 1f, oriImg.Width - 1f);
                }
                imageList_files.Images.Add(iconDirKeyNE, dirNEImg);
            }
        }

        private void FormHExplorer_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Directory.Exists(tmpDir))
                Directory.Delete(tmpDir, true);
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedIndex == 0)
            {
                button_reload_Click(sender, e);
            }
            if (tabControl.SelectedIndex == 1)
            {
                ShowItemPropertiesBlank();
                button_reload_linear_Click(sender, e);
            }
        }
        private void button_reload_Click(object sender, EventArgs e)
        {
            treeView.Nodes[0].Nodes.Clear();
            core.fileOperator.LoadAllHOIndexes();
            LoadTreeViewLevel(treeView.Nodes[0], null);
        }

        #region tree view

        private void LoadTreeViewLevel(TreeNode targetNode, string pathInBase)
        {
            HashSet<string> notExistDirs;
            if (targetNode.Level == 0)
            {
                // root
                foreach (HFileSystemInfo hi in core.fileOperator.GetHFileSystemItems(
                    null, false, true, out notExistDirs))
                    targetNode.Nodes.Add(GenerateTreeNode(hi));
            }
            else
            {
                foreach (HFileSystemInfo hi in core.fileOperator.GetHFileSystemItems(
                    pathInBase, false, true, out notExistDirs))
                    targetNode.Nodes.Add(GenerateTreeNode(hi));
            }
            foreach (string neDir in notExistDirs)
                targetNode.Nodes.Add(GenerateTreeNode(neDir));
        }
        private TreeNode GenerateTreeNode(HFileSystemInfo hiDir)
        {
            TreeNode result = new TreeNode(hiDir.name)
            {
                Tag = hiDir,
                ImageKey = iconDirKey,
                SelectedImageKey = hiDir.isDeleted ? (iconDirKey + alphaIconKeySuffix) : iconDirKey,
            };
            if (core.fileOperator.CheckHaveSubs(hiDir.fullName, true))
                result.Nodes.Add(GenerateTreeNode_Loading());

            return result;
        }
        private TreeNode GenerateTreeNode(string neDir)
        {
            TreeNode result = new TreeNode(Path.GetFileName(neDir))
            {
                Tag = neDir,
                ImageKey = iconDirKeyNE,
                SelectedImageKey = iconDirKeyNE,
            };
            if (core.fileOperator.CheckHaveSubs(neDir, true))
                result.Nodes.Add(GenerateTreeNode_Loading());

            return result;
        }
        private TreeNode GenerateTreeNode_Loading()
        {
            return new TreeNode("Loading...");
        }


        private void treeView_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            e.Node.Nodes.Clear();
            e.Node.Nodes.Add(GenerateTreeNode_Loading());
        }

        private void treeView_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            e.Node.Nodes.Clear();
            string hiDir = e.Node.FullPath.Substring(treeView.Nodes[0].Name.Length);
            if (hiDir.Length > 0)
                hiDir = hiDir.Substring(1);
            HashSet<string> notExistDirs;
            foreach (HFileSystemInfo hi in core.fileOperator.GetHFileSystemItems(
                hiDir, false, true, out notExistDirs))
                e.Node.Nodes.Add(GenerateTreeNode(hi));
            foreach (string neDir in notExistDirs)
                e.Node.Nodes.Add(GenerateTreeNode(neDir));
        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            ReloadListView();
        }
        private void ReloadListView()
        {
            listView.Items.Clear();
            string fullPath = treeView.SelectedNode.FullPath;
            textBox_path.Text = fullPath;
            string hiDir = fullPath.Substring(treeView.Nodes[0].Name.Length);
            if (hiDir.Length > 0)
                hiDir = hiDir.Substring(1);
            object nodeTag = treeView.SelectedNode.Tag;
            ShowItemProperties(nodeTag);

            HashSet<string> notExistDirs;
            foreach (HFileSystemInfo hi in core.fileOperator.GetHFileSystemItems(
                hiDir, false, false, out notExistDirs))
                listView.Items.Add(GenerateListViewItem(hi));
            foreach (string neDir in notExistDirs)
                listView.Items.Add(GenerateListViewItem(neDir));

            lvSorter.Sort(0);
        }
        private void ShowItemProperties(object tag)
        {
            if (tag == null)
                ShowItemPropertiesBlank();
            else if (tag is HFileSystemInfo)
                ShowItemProperties((HFileSystemInfo)tag);
            else
                ShowItemProperties((string)tag);
        }
        private void ShowItemProperties(HFileSystemInfo hi)
        {
            toolStripStatusLabel_fileOrDir.Text = (hi.isDirectory ? "[D]" : "[F]") + hi.name;
            toolStripStatusLabel_size.Text = SimpleStringHelper.UnitsOfMeasure.GetShortString(hi.size, "B", 1024, 2, true);
            toolStripStatusLabel_attri.Text = hi.attributes.ToString();
            toolStripStatusLabel_createTime.Text = "C " + hi.createTime.ToString("yyyy-MM-dd HH:mm:ss");
            toolStripStatusLabel_modifyTime.Text = "M " + hi.modifyTime.ToString("yyyy-MM-dd HH:mm:ss");
        }
        private void ShowItemProperties(string neDir)
        {
            toolStripStatusLabel_fileOrDir.Text = "[D]" + Path.GetFileName(neDir);
            toolStripStatusLabel_size.Text = "0 B";
            toolStripStatusLabel_attri.Text = (FileAttributes.Directory).ToString();
            toolStripStatusLabel_createTime.Text = "----";
            toolStripStatusLabel_modifyTime.Text = "----";
        }
        private void ShowItemPropertiesBlank()
        {
            toolStripStatusLabel_fileOrDir.Text = "[Multiple/Null selection]";
            toolStripStatusLabel_size.Text = "---";
            toolStripStatusLabel_attri.Text = "----";
            toolStripStatusLabel_createTime.Text = "----";
            toolStripStatusLabel_modifyTime.Text = "----";
        }

        private ListViewItem GenerateListViewItem(HFileSystemInfo hi)
        {
            string nameEx = hi.isDirectory ? iconDirKey : hi.nameExtension;
            if (string.IsNullOrWhiteSpace(nameEx))
                nameEx = "f";
            if (!imageList_files.Images.ContainsKey(nameEx))
                imageList_files.Images.Add(nameEx, ioIcons.GetFileIcon_bySuffix(nameEx));
            if (hi.isDeleted)
            {
                MakeAlphaIcon(nameEx);
                nameEx = nameEx + alphaIconKeySuffix;
            }

            return new ListViewItem(new string[]
            {
                hi.name,
                SimpleStringHelper.UnitsOfMeasure.GetShortString( hi.size,"B",1024,2,true),
                hi.attributes.ToString(),
                hi.createTime.ToString("yyyy-MM-dd HH:mm:ss"),
                hi.modifyTime.ToString("yyyy-MM-dd HH:mm:ss"),
                hi.egzFileTime.ToString("yyyy-MM-dd HH:mm:ss"),
            })
            { Tag = hi, ImageKey = nameEx, };
        }
        private ListViewItem GenerateListViewItem(string neDir)
        {
            return new ListViewItem(new string[]
            {
                Path.GetFileName(neDir),
                "0 B",
                FileAttributes.Directory.ToString(),
            })
            { Tag = neDir, ImageKey = iconDirKeyNE, };
        }

        private void button_go_Click(object sender, EventArgs e)
        {
            string path = textBox_path.Text;
            TreeNode foundTN, curTN = treeView.Nodes[0];
            if (string.IsNullOrWhiteSpace(path))
            {
                treeView.SelectedNode = curTN;
                return;
            }
            string[] pathParts
                = path.Split(
                    new string[] { "\\" },
                    StringSplitOptions.RemoveEmptyEntries);
            if (pathParts[0] != curTN.Text)
            {
                MessageBox.Show(this,
                    $"Can't navegate to the root [{pathParts[0]}]",
                    "Not found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            string p;
            for (int i = 1, iv = pathParts.Length; i < iv; i++)
            {
                p = pathParts[i];
                curTN.Expand();
                foundTN = null;
                foreach (TreeNode subTN in curTN.Nodes)
                {
                    if (p == subTN.Text)
                    {
                        foundTN = subTN;
                        break;
                    }
                }
                if (foundTN == null)
                {
                    MessageBox.Show(this,
                        $"Can't navegate to the path given, stoped at [{p}]",
                        "Not found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;
                }
                else
                {
                    curTN = foundTN;
                }
            }
            treeView.SelectedNode = curTN;
        }

        private void listView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 0)
                ShowItemProperties(treeView.SelectedNode.Tag);
            else if (listView.SelectedItems.Count == 1)
                ShowItemProperties(listView.SelectedItems[0].Tag);
            else
                ShowItemPropertiesBlank();
        }
        private void treeView_DoubleClick(object sender, EventArgs e)
        {

        }

        private void textBox_path_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                button_go_Click(sender, e);
        }

        private void listView_ItemActivate(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 1)
            {
                ListViewItem lvi = listView.SelectedItems[0];
                if (lvi.ImageKey == iconDirKey)
                {
                    treeView.SelectedNode.Expand();
                    foreach (TreeNode subTN in treeView.SelectedNode.Nodes)
                    {
                        if (subTN.Text == lvi.Text)
                        {
                            treeView.SelectedNode = subTN;
                            break;
                        }
                    }
                }
                else
                {
                    // write file to tmp
                    if (!Directory.Exists(tmpDir))
                        Directory.CreateDirectory(tmpDir);
                    HFileSystemInfo hi = (HFileSystemInfo)lvi.Tag;
                    string tmpFile = Path.Combine(tmpDir,
                        SimpleStringHelper.ToHexString(DateTime.Now.Ticks)
                            + hi.nameExtension);
                    core.fileOperator.ExtractHFile(hi.fullName, tmpFile);

                    // open file
                    Process.Start(tmpFile);
                }
            }
        }

        private void listView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (listView.SelectedItems.Count > 0
                    && MessageBox.Show(this,
                    "Will Mark selected items as \"deleted\"" + Environment.NewLine + Environment.NewLine +
                    "Are you sure to continue?", "Warning",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2)
                        == DialogResult.Yes)
                {
                    HFileSystemInfo hi;
                    foreach (ListViewItem lvi in listView.SelectedItems)
                    {
                        if (lvi.Tag is HFileSystemInfo)
                            core.fileOperator.DeleteH(((HFileSystemInfo)lvi.Tag).fullName);
                        else
                            core.fileOperator.DeleteH(lvi.Tag.ToString());
                    }
                    core.fileOperator.CommitHIndexes();
                    ReloadListView();
                }
            }
            else if (e.KeyCode == Keys.Insert)
            {
                if (listView.SelectedItems.Count > 0
                    && MessageBox.Show(this,
                    "Will Mark selected items as \"not deleted\"" + Environment.NewLine + Environment.NewLine +
                    "Are you sure to continue?", "Warning",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2)
                        == DialogResult.Yes)
                {
                    HFileSystemInfo hi;
                    foreach (ListViewItem lvi in listView.SelectedItems)
                    {
                        if (lvi.Tag is HFileSystemInfo)
                            core.fileOperator.RestoreH(((HFileSystemInfo)lvi.Tag).fullName);
                        else
                            core.fileOperator.RestoreH(lvi.Tag.ToString());
                    }
                    core.fileOperator.CommitHIndexes();
                    ReloadListView();
                }
            }
        }

        #endregion



        #region linear view
        private void button_reload_linear_Click(object sender, EventArgs e)
        {
            LoadLinearView();
        }
        private void LoadLinearView()
        {
            core.fileOperator.LoadAllHOIndexes();
            //idxHelper = new HOIndexesHelper(allHoIndexes);

            listView_indexList.Items.Clear();
            listView_indexList.Items.Add(new ListViewItem(FileOperator.IndexDirNamePre));
            foreach (string hiIndexKey in core.fileOperator.allHOFileIndexes.Keys)
            {
                listView_indexList.Items.Add(new ListViewItem(hiIndexKey));
            }
        }
        private void listView_indexList_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox_listRawData.Clear();
            if (listView_indexList.SelectedItems.Count == 1)
            {
                listView_indexList_LoadSelectIndexContent(
                    listView_indexList.SelectedItems[0].Text);
            }
        }
        private void listView_indexList_LoadSelectIndexContent(string indexKey)
        {
            List<HFileSystemInfo> selectedHFList;
            if (indexKey == FileOperator.IndexDirNamePre)
            {
                selectedHFList = core.fileOperator.allHODirIndexes;
            }
            else
            {
                selectedHFList = core.fileOperator.allHOFileIndexes[indexKey];
            }
            textBox_listRawData.Text = "[Loading...]";
            textBox_listRawData.Update();
            StringBuilder content = new StringBuilder();
            foreach (HFileSystemInfo hi in selectedHFList)
            {
                content.Append(hi.IOContent);
                content.Append(Environment.NewLine);
            }
            textBox_listRawData.Text = content.ToString();
        }


        private void textBox_search_liner_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                button_search_liner_Click(sender, e);
        }
        private void button_search_liner_clear_Click(object sender, EventArgs e)
        {
            textBox_search_liner.Text = "";
            button_search_liner_Click(sender, e);
        }

        private class SearchResultItem
        {
            public string indexName;
            public int start;
            public int length;
        }
        private string searchCurWord = "";
        private int searchResultCurIndex = -1;
        private List<SearchResultItem> searchResult = new List<SearchResultItem>();
        private void button_search_liner_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox_search_liner.Text))
            {
                searchCurWord = "";
                searchResult.Clear();
                searchResultCurIndex = -1;
                toolStripStatusLabel_fileOrDir.Text = "Input words to search.";
            }
            else
            {
                if (textBox_search_liner.Text != searchCurWord)
                {
                    // new search
                    searchCurWord = textBox_search_liner.Text;
                    string searchWordLower = searchCurWord.ToLower();
                    int searchWordLength = searchCurWord.Length;
                    int searchWordIdx;
                    searchResult.Clear();
                    List<HFileSystemInfo> curIdx;
                    string ioContentLower;
                    int baseStart = 0;
                    foreach (HFileSystemInfo hi in core.fileOperator.allHODirIndexes)
                    {
                        ioContentLower = hi.IOContent.ToLower();
                        searchWordIdx = ioContentLower.IndexOf(searchWordLower);
                        while (searchWordIdx >= 0)
                        {
                            searchResult.Add(new SearchResultItem()
                            {
                                indexName = FileOperator.IndexDirNamePre,
                                start = baseStart + searchWordIdx,
                                length = searchWordLength,
                            });
                            searchWordIdx
                                = ioContentLower.IndexOf(
                                    searchWordLower,
                                    searchWordIdx + searchWordLength);
                        }
                        baseStart += ioContentLower.Length + Environment.NewLine.Length;
                    }
                    foreach (string idxKey in core.fileOperator.allHOFileIndexes.Keys)
                    {
                        baseStart = 0;
                        curIdx = core.fileOperator.allHOFileIndexes[idxKey];
                        foreach (HFileSystemInfo hi in curIdx)
                        {
                            ioContentLower = hi.IOContent.ToLower();
                            searchWordIdx = ioContentLower.IndexOf(searchWordLower);
                            while (searchWordIdx >= 0)
                            {
                                searchResult.Add(new SearchResultItem()
                                {
                                    indexName = idxKey,
                                    start = baseStart + searchWordIdx,
                                    length = searchWordLength,
                                });
                                searchWordIdx
                                    = ioContentLower.IndexOf(
                                        searchWordLower,
                                        searchWordIdx + searchWordLength);
                            }
                            baseStart += ioContentLower.Length + Environment.NewLine.Length;
                        }
                    }

                    NavigateToSearchResult(0);
                }
                else
                {
                    // find next
                    searchResultCurIndex++;
                    if (searchResultCurIndex >= searchResult.Count)
                        searchResultCurIndex = 0;
                    NavigateToSearchResult(searchResultCurIndex);
                }
            }
        }
        private void NavigateToSearchResult(int resultIndex)
        {
            if (searchResult.Count == 0)
            {
                toolStripStatusLabel_fileOrDir.Text = "No result";
                return;
            }

            if (resultIndex < 0) searchResultCurIndex = 0;
            else if (resultIndex >= searchResult.Count) searchResultCurIndex = searchResult.Count - 1;
            else searchResultCurIndex = resultIndex;
            SearchResultItem curSRI = searchResult[searchResultCurIndex];
            if (listView_indexList.SelectedItems.Count != 1
                || curSRI.indexName != listView_indexList.SelectedItems[0].Text)
            {
                foreach (ListViewItem lvi in listView_indexList.Items)
                {
                    if (lvi.Text == curSRI.indexName)
                        lvi.Selected = true;
                }
            }
            textBox_listRawData.SelectionStart = curSRI.start;
            textBox_listRawData.SelectionLength = curSRI.length;
            textBox_listRawData.ScrollToCaret();

            bindingNavigatorPositionItem.Text = (searchResultCurIndex + 1).ToString();
            bindingNavigatorCountItem.Text = $"/ {searchResult.Count}";
        }


        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            searchResultCurIndex = 0;
            NavigateToSearchResult(searchResultCurIndex);
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            searchResultCurIndex--;
            if (searchResultCurIndex < 0)
                searchResultCurIndex = searchResult.Count - 1;
            NavigateToSearchResult(searchResultCurIndex);
        }

        private void bindingNavigatorPositionItem_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                int test = int.Parse(bindingNavigatorPositionItem.Text);
            }
            catch (Exception)
            {
                toolStripStatusLabel_fileOrDir.Text = "Given position is not a number.";
                e.Cancel = true;
            }
        }
        private void bindingNavigatorPositionItem_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                NavigateToSearchResult(int.Parse(bindingNavigatorPositionItem.Text) - 1);
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            searchResultCurIndex++;
            if (searchResultCurIndex >= searchResult.Count)
                searchResultCurIndex = 0;
            NavigateToSearchResult(searchResultCurIndex);
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            searchResultCurIndex = searchResult.Count - 1;
            NavigateToSearchResult(searchResultCurIndex);
        }


        #endregion

        private void contextMenuStrip_treeViewRoot_Opening(object sender, CancelEventArgs e)
        {
            if (treeView.SelectedNode.Level != 0)
                e.Cancel = true;
        }

        private void toolStripMenuItem_vaccum_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this,
                "I will release space from HideOut, marked files will be deleted permanently," + Environment.NewLine + Environment.NewLine +
                "Are you sure to continue?", "Warning",
                MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                core.fileOperator.Vacuum();
            }
        }
    }
}
