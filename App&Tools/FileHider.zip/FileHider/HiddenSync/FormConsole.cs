﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MadTomDev.App.Classes;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using MadTomDev.Resources;
using MadTomDev.UIs.UserControls;

namespace MadTomDev.App
{
    public partial class FormConsole : Form
    {
        public FormConsole()
        {
            InitializeComponent();
        }

        private Classes.Core core;


        private void FormConsole_Load(object sender, EventArgs e)
        {
            LoggerAdv logger = LoggerAdv.GetInstance();
            logger.BaseDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "StartingLogs");
            uC_LogView.Init(logger);
            notifyIcon.Text = this.Text;

            core = new Core(logger);

            core.SyncStartStop += Core_SyncStartStop;
            core.SyncProgressing += Core_SyncProgressing;
            core.SyncDeleting += Core_SyncDeleting;
            core.SyncError += Core_SyncError;

            core.DirStatesChanged += (s1) =>
            { RefreshCoreState(); };

            RefreshCoreState();
            RefreshBkuLogInfo();

            //try load last setting
            //core.TryStartRunning();
        }


        private void FormConsole_Shown(object sender, EventArgs e)
        { /*this.Hide();*/ }


        #region init, logger

        private void Core_SyncStartStop(Core sender, bool isStartedOrStoped)
        {
            RefreshCoreState();
            if (isStartedOrStoped)
            {
                core.loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Warning, null,
                    "Sync started."));
            }
            else
            {
                core.loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Warning, null,
                    "Sync stoped."));
                RefreshBkuLogInfo();
            }
        }
        private void Core_SyncProgressing(Classes.Core sender, string pathInBase, bool isH2O_orO2H)
        {
            if (isH2O_orO2H)
                core.loggerAdv.Log(
                    new LoggerAdv.ItemClass(LoggerAdv.ItemClass.Levels.Warning, null, "Syncing H->O: " + pathInBase));
            else
                core.loggerAdv.Log(
                    new LoggerAdv.ItemClass(LoggerAdv.ItemClass.Levels.Warning, null, "Syncing O->H: " + pathInBase));
        }
        private void Core_SyncDeleting(Core sender, string pathInBase, bool fromH_orO)
        {
            core.loggerAdv.Log(
                new LoggerAdv.ItemClass(LoggerAdv.ItemClass.Levels.Warning, null, $"Deleting from [{ (fromH_orO ? "H" : "O") }]: " + pathInBase));
        }
        private void Core_SyncError(Classes.Core sender, Exception err)
        {
            core.loggerAdv.Log(
                new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Warning, null, "Syncing Err: " + err.Message));
            core.loggerAdv.Log(err);
        }
        private delegate void RefreshCoreStateDelegate();
        private void RefreshCoreState()
        {
            if (InvokeRequired)
            {
                RefreshCoreStateDelegate callback
                    = new RefreshCoreStateDelegate(RefreshCoreState);
                this.Invoke(callback);
            }
            else
            {
                checkBox_dirsReady.Checked
                    = core.fileOperator.HODir != null
                        && core.fileOperator.ODDir != null;

                checkBox_bk_deleted.Checked = core.settings.Backup_Deleted;
                checkBox_bk_changed.Checked = core.settings.Backup_Changed;
            }
        }
        private delegate void RefreshBkuLogInfoDelegate();
        private void RefreshBkuLogInfo()
        {
            if (InvokeRequired)
            {
                RefreshBkuLogInfoDelegate callback = new RefreshBkuLogInfoDelegate(RefreshBkuLogInfo);
                this.Invoke(callback);
            }
            else
            {
                string storeDir = core.fileOperator.GetStorageDir();
                int filesCount = 0;
                long sizeTotal = 0;
                RefreshBkuLogInfo_loop(new DirectoryInfo(storeDir), ref filesCount, ref sizeTotal);

                StringBuilder info = new StringBuilder();
                info.Append(SimpleStringHelper.UnitsOfMeasure.GetShortString(sizeTotal, "B", 1024));
                info.Append(Environment.NewLine);
                info.Append(SimpleStringHelper.UnitsOfMeasure.GetShortString(filesCount, "F", 1024));
                label_bk_info.Text = info.ToString();
            }
        }
        private void RefreshBkuLogInfo_loop(DirectoryInfo baseDir, ref int filesCount, ref long sizeTotal)
        {
            foreach (FileInfo fi in baseDir.GetFiles())
            {
                filesCount++;
                sizeTotal += fi.Length;
            }
            foreach (DirectoryInfo di in baseDir.GetDirectories())
                RefreshBkuLogInfo_loop(di, ref filesCount, ref sizeTotal);
        }
        #endregion


        #region buttongs
        private bool CheckDirReady()
        {
            if (!checkBox_dirsReady.Checked)
            {
                MessageBox.Show(this,
                    "Folders not ready or damaged!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private void button_syncO2H_Click(object sender, EventArgs e)
        {
            if (!CheckDirReady())
                return;
            if (MessageBox.Show(this,
                "I will transfer open files to hiden folder:" + Environment.NewLine + Environment.NewLine +
                "* Files only present within hiden folder will be deleted!" + Environment.NewLine +
                "* Files within hiden folder will be updated, nomatter newer or older!" + Environment.NewLine +
                "* Files only present within open folder will be copy to hiden folder." + Environment.NewLine + Environment.NewLine +
                "Are you sure to continue?", "Note",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                core.loggerAdv.Log("Starting sync(O->H)...");
                core.Sync_ASync(Core.SyncDirection.O2H);
            }
        }

        private void button_syncH2O_Click(object sender, EventArgs e)
        {
            if (!CheckDirReady())
                return;
            if (MessageBox.Show(this,
                "I will transfer hiden files to open folder:" + Environment.NewLine + Environment.NewLine +
                "* Files only present within open folder will be deleted!" + Environment.NewLine +
                "* Files within open folder will be updated, nomatter newer or older!" + Environment.NewLine +
                "* Files only present within hiden folder will be copied to open folder." + Environment.NewLine + Environment.NewLine +
                "Are you sure to continue?", "Note",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                core.loggerAdv.Log("Starting sync(H->O)...");
                core.Sync_ASync(Core.SyncDirection.H2O);
            }
        }
        private void button_syncBothWay_Click(object sender, EventArgs e)
        {
            if (!CheckDirReady())
                return;
            if (MessageBox.Show(this,
                "I will transfer hiden files in both way:" + Environment.NewLine + Environment.NewLine +
                "* Older files will be updated!" + Environment.NewLine +
                "* Files will be copied if not present in opponent folder." + Environment.NewLine + Environment.NewLine +
                "Are you sure to continue?", "Note",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                core.loggerAdv.Log("Starting sync(both way)...");
                core.Sync_ASync(Core.SyncDirection.BothWay);
            }
        }

        private void button_config_Click(object sender, EventArgs e)
        {
            //core.StopFSWatching();

            core.loggerAdv.Log("Configering...");
            FormConfig cfgWin = new FormConfig(core);
            if (cfgWin.ShowDialog() == DialogResult.OK)
            {
                core.settings.Save();
                core.loggerAdv.Log("Cfg saved.");
            }
            else
            {
                core.loggerAdv.Log("Cfg canceled.");
            }
            RefreshBkuLogInfo();

            //core.StartFSWatching();
            RefreshCoreState();
        }


        private void button_hide_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion


        #region notify icon
        private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        { this.Show(); this.WindowState = preNonMinWindowState; this.Focus(); }

        private void toolStripMenuItem_console_Click(object sender, EventArgs e)
        { this.Show(); this.WindowState = preNonMinWindowState; this.Focus(); }

        private void toolStripMenuItem_syncO2H_Click(object sender, EventArgs e)
        { button_syncO2H_Click(null, null); }

        private void toolStripMenuItem_syncH2O_Click(object sender, EventArgs e)
        { button_syncH2O_Click(null, null); }
        private void toolStripMenuItem_fullSync_Click(object sender, EventArgs e)
        { button_syncBothWay_Click(null, null); }

        private void toolStripMenuItem_config_Click(object sender, EventArgs e)
        { button_config_Click(null, null); }

        private void toolStripMenuItem_viewLogFiles_Click(object sender, EventArgs e)
        {
            uC_LogView.ViewLogDir();
        }

        private void toolStripMenuItem_exit_Click(object sender, EventArgs e)
        { button_exit_Click(null, null); }
        #endregion

        private void FormConsole_FormClosing(object sender, FormClosingEventArgs e)
        {
            core.loggerAdv.Log("Exiting...");
            Update();
            core.Dispose();
            core.loggerAdv.Log("Bye Bye.");
        }

        private FormWindowState preNonMinWindowState;
        private void FormConsole_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
            }
            else preNonMinWindowState = this.WindowState;
        }

        private void label_bk_info_Click(object sender, EventArgs e)
        {
            // reload bk-info
            label_bk_info.Text = "Ldin..";
            Update();
            RefreshBkuLogInfo();
        }

        private void button_explorer_Click(object sender, EventArgs e)
        {
            FormHExplorer explorer = new FormHExplorer(core);
            explorer.Show();
        }

    }
}
