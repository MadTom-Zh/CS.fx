﻿using MadTomDev.Data;
using MadTomDev.Resources;
using MadTomDev.UIs;
using MadTomDev.UIs.ExDialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class FormConfig : Form
    {
        //public FormConfig()
        //{
        //    InitializeComponent();
        //}
        private Classes.Core core;
        public FormConfig(Classes.Core core)
        {
            InitializeComponent();
            this.core = core;
        }

        public const long BytesPreMB = 1048576;

        private void FormConfig_Load(object sender, EventArgs e)
        {

        }
        private void FormConfig_Shown(object sender, EventArgs e)
        {
            checkBox_runAtStartup.Checked = CheckIsRunAtStartUp();

            checkBox_skipLargeFiles.Checked = core.settings.Limi_IsSkipLargeFiles;
            numericUpDown_largeFileSizeMB.Value = core.settings.Limi_LargeFileMinSize / 1024 / 1024;

            checkBox_bk_deleted.Checked = core.settings.Backup_Deleted;
            checkBox_bk_changed.Checked = core.settings.Backup_Changed;
            textBox_bkNLog_dir.Text = core.settings.StoreDirRelated_BkuNLog;

            core.fileOperator.GetHODir();
            if (core.fileOperator.HODir == null)
                textBox_HDir.Text = core.settings.HO_Dir;
            else
                textBox_HDir.Text = core.fileOperator.HODir;
            core.fileOperator.GetODDir();
            if (core.fileOperator.ODDir == null)
                textBox_ODir.Text = core.settings.OD_Dir;
            else
                textBox_ODir.Text = core.fileOperator.ODDir;

            //load exculding list
            ExcludingList_toUI(core.excludingList);
        }
        private bool CheckIsRunAtStartUp()
        {
            string appDescript = Application.ProductName + "." + Application.ProductVersion;
            string linkFileName = appDescript + "@" + GetAppFileFullNameStr() + ".lnk";

            return IOUtilities.Other.StartUp_CheckLnkFileExists(linkFileName);
        }
        private void RunAtStartUpEnable(bool isEnableOrDisable)
        {
            string appDescript = Application.ProductName + "." + Application.ProductVersion;
            string linkFileName = appDescript + "@" + GetAppFileFullNameStr() + ".lnk";

            IOUtilities.Other.StartUp_RemoveLnkFile(linkFileName);
            if (isEnableOrDisable)
                IOUtilities.Other.StartUp_GenerateLnkFile(Application.ExecutablePath, linkFileName, appDescript);
        }
        private string GetAppFileFullNameStr()
        {
            string result = Application.StartupPath.Replace("\\", "__");
            return result.Replace(":", "");
        }

        private void ExcludingList_toUI(List<Classes.Core.ExcludingItem> eList)
        {
            int no = 1;
            foreach (Classes.Core.ExcludingItem e in eList)
            {
                dataGridView_excluding.Rows.Add(no++, e.text, e.isRootOnly);
            }
        }
        private List<Classes.Core.ExcludingItem> ExcludingList_fromUI()
        {
            List<Classes.Core.ExcludingItem> result = new List<Classes.Core.ExcludingItem>();
            string tx;
            object isROObj;
            foreach (DataGridViewRow r in dataGridView_excluding.Rows)
            {
                if (r.Cells[1].Value == null)
                    continue;

                tx = r.Cells[1].Value.ToString();
                isROObj = r.Cells[2].Value;
                if (!string.IsNullOrWhiteSpace(tx))
                {
                    result.Add(new Classes.Core.ExcludingItem()
                    { text = tx, isRootOnly = isROObj == null ? false : (bool)isROObj });
                }
            }
            return result;
        }


        private void SetBackToSettings()
        {
            RunAtStartUpEnable(checkBox_runAtStartup.Checked);

            core.settings.Limi_IsSkipLargeFiles = checkBox_skipLargeFiles.Checked;
            core.settings.Limi_LargeFileMinSize = (long)numericUpDown_largeFileSizeMB.Value * 1024 * 1024;


            core.settings.Backup_Deleted = checkBox_bk_deleted.Checked;
            core.settings.Backup_Changed = checkBox_bk_changed.Checked;
            core.settings.StoreDirRelated_BkuNLog = textBox_bkNLog_dir.Text;

            //load exculding list
            StringBuilder eListStr = new StringBuilder();
            core.excludingList = ExcludingList_fromUI();
            foreach (Classes.Core.ExcludingItem e in core.excludingList)
            {
                eListStr.Append(e.IOContent);
                eListStr.Append("|");
            }
            if (eListStr.Length > 0)
                eListStr.Remove(eListStr.Length - 1, 1);
            core.settings.Limi_ExcludingList = eListStr.ToString();
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            SetBackToSettings();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }


        #region set dirs, HO, OD, backupNLog
        private void button_HDirBrowser_Click(object sender, EventArgs e)
        {
            if (betterFolderBrowser.ShowDialog() == DialogResult.OK)
            {
                core.fileOperator.GetODDir();
                //core.fileOperator.GetHODir();

                if (CheckDirRelations(
                    IOUtilities.Other.GetAbsolutePath(Application.StartupPath, textBox_bkNLog_dir.Text),
                     betterFolderBrowser.SelectedFolder,
                    core.fileOperator.ODDir))
                {
                    bool notPass = false;
                    DirectoryInfo hoDi = new DirectoryInfo(betterFolderBrowser.SelectedFolder);
                    if (hoDi.GetFiles(Classes.FileOperator.IndexFileNamePre).Length > 0)
                    {
                        // open
                        PasswordInputBox pwdWin = new PasswordInputBox(
                            "Input the password to unlock this hideout.", "Unlock Hideout", false);
                        if (pwdWin.ShowDialog() == DialogResult.OK)
                        {
                            try
                            {
                                core.fileOperator.SetHideout(betterFolderBrowser.SelectedFolder, pwdWin.Password);
                                object test = core.fileOperator.LoadHOIndex(0);
                                core.settings.HO_PasswordMesh = core.fileOperator.passwordMask;
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("Wrong password!");
                                notPass = true;
                            }
                        }
                    }
                    else if (hoDi.GetFileSystemInfos().Length == 0)
                    {
                        // new
                        PasswordInputBox pwdWin = new PasswordInputBox(
                            "Set a password to init a hideout.", "Init Hideout", true);
                        if (pwdWin.ShowDialog() == DialogResult.OK)
                        {
                            core.fileOperator.SetHideout(betterFolderBrowser.SelectedFolder, pwdWin.Password);
                            core.settings.HO_PasswordMesh = core.fileOperator.passwordMask;
                        }
                    }
                    else
                    {
                        MessageBox.Show(this,
                            "This folder do not contains index file and is Not empty.",
                            "Not a Hideout",
                            MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        notPass = true;
                    }

                    if (notPass)
                        return;

                    textBox_HDir.Text = betterFolderBrowser.SelectedFolder;
                }
            }
        }

        private void button_ODirBrowser_Click(object sender, EventArgs e)
        {
            if (betterFolderBrowser.ShowDialog() == DialogResult.OK)
            {
                //core.fileOperator.GetODDir();
                core.fileOperator.GetHODir();

                if (CheckDirRelations(
                    IOUtilities.Other.GetAbsolutePath(Application.StartupPath, textBox_bkNLog_dir.Text),
                    core.fileOperator.HODir,
                    betterFolderBrowser.SelectedFolder))
                {
                    core.fileOperator.SetOpenDir(betterFolderBrowser.SelectedFolder);
                    textBox_ODir.Text = betterFolderBrowser.SelectedFolder;
                }
            }
        }
        private void button_bkNLog_dir_Click(object sender, EventArgs e)
        {
            if (betterFolderBrowser.ShowDialog() == DialogResult.OK)
            {
                core.fileOperator.GetODDir();
                core.fileOperator.GetHODir();

                if (CheckDirRelations(
                    betterFolderBrowser.SelectedFolder,
                    core.fileOperator.HODir,
                    core.fileOperator.ODDir))
                {
                    core.fileOperator.SetStorageDir(betterFolderBrowser.SelectedFolder);
                    textBox_bkNLog_dir.Text = IOUtilities.Other.GetRelatedPath(Application.StartupPath, betterFolderBrowser.SelectedFolder);
                }
            }
        }
        private bool CheckDirRelations(string bkDir, string hoDir, string odDir)
        {
            if (hoDir != null
                && (bkDir == hoDir || bkDir.StartsWith(hoDir+Path.DirectorySeparatorChar)))
            {
                MessageBox.Show(this,
                    "Can't make Backup-Log folder inside a Hideout.", "Stop",
                    MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            if (odDir != null
                && (bkDir == odDir || bkDir.StartsWith(odDir + Path.DirectorySeparatorChar)))
            {
                MessageBox.Show(this,
                    "Can't make Backup-Log folder inside a Openfolder.", "Stop",
                    MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            if (hoDir != null
            && odDir != null)
            {
                if (hoDir.Contains(odDir))
                {
                    MessageBox.Show(this,
                        "Cant make Hideout inside a Openfolder.", "Stop",
                        MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
                if (odDir.Contains(hoDir))
                {
                    MessageBox.Show(this,
                        "Cant make Openfolder inside a Hideout.", "Stop",
                        MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
            }

            return true;
        }

        #endregion


        #region datagridview
        private void dataGridView_excluding_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        { }
        private void dataGridView_excluding_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        { }

        private void dataGridView_excluding_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                DataGridViewCell cell = dataGridView_excluding.Rows[e.RowIndex].Cells[e.ColumnIndex];
                string tx = (string)cell.Value;
                DataGridViewCellStyle style;
                if (string.IsNullOrWhiteSpace(tx))
                {
                    style = cell.Style;
                    style.BackColor = Color.LightSalmon;
                }
                else
                {
                    style = cell.Style;
                    style.BackColor = SystemColors.Window;
                }
                cell.Style = style;
            }
        }

        private void dataGridView_excluding_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            // add no
            int newRowsCount = dataGridView_excluding.Rows.Count;
            dataGridView_excluding.Rows[newRowsCount - 2].Cells[0].Value = (newRowsCount - 1).ToString();
            e.Row.Cells[0].Value = newRowsCount.ToString();
        }

        private void dataGridView_excluding_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            // reset no s
            for (int i = 0, count = dataGridView_excluding.Rows.Count - 1; i < count; i++)
            {
                dataGridView_excluding.Rows[i].Cells[0].Value = (i + 1).ToString();
            }
        }
        #endregion

    }
}
