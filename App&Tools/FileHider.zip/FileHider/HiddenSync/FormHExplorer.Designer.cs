﻿namespace MadTomDev.App
{
    partial class FormHExplorer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("HideOut");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormHExplorer));
            this.treeView = new System.Windows.Forms.TreeView();
            this.contextMenuStrip_treeViewRoot = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_vaccum = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList_files = new System.Windows.Forms.ImageList(this.components);
            this.listView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_path = new System.Windows.Forms.TextBox();
            this.button_go = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_fileOrDir = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_size = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_attri = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_createTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_modifyTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button_reload = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_search_liner_clear = new System.Windows.Forms.Button();
            this.button_search_liner = new System.Windows.Forms.Button();
            this.bindingNavigatorSearch = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.textBox_search_liner = new System.Windows.Forms.TextBox();
            this.button_reload_linear = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_listRawData = new System.Windows.Forms.TextBox();
            this.listView_indexList = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip_treeViewRoot.SuspendLayout();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSearch)).BeginInit();
            this.bindingNavigatorSearch.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView
            // 
            this.treeView.ContextMenuStrip = this.contextMenuStrip_treeViewRoot;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.HideSelection = false;
            this.treeView.ImageIndex = 0;
            this.treeView.ImageList = this.imageList_files;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            treeNode1.ImageKey = "Root";
            treeNode1.Name = "HideOut";
            treeNode1.SelectedImageKey = "Root";
            treeNode1.Text = "HideOut";
            this.treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.treeView.SelectedImageIndex = 0;
            this.treeView.Size = new System.Drawing.Size(321, 522);
            this.treeView.TabIndex = 0;
            this.treeView.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterCollapse);
            this.treeView.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeExpand);
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            // 
            // contextMenuStrip_treeViewRoot
            // 
            this.contextMenuStrip_treeViewRoot.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_vaccum});
            this.contextMenuStrip_treeViewRoot.Name = "contextMenuStrip_treeViewRoot";
            this.contextMenuStrip_treeViewRoot.Size = new System.Drawing.Size(117, 26);
            this.contextMenuStrip_treeViewRoot.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip_treeViewRoot_Opening);
            // 
            // toolStripMenuItem_vaccum
            // 
            this.toolStripMenuItem_vaccum.Name = "toolStripMenuItem_vaccum";
            this.toolStripMenuItem_vaccum.Size = new System.Drawing.Size(116, 22);
            this.toolStripMenuItem_vaccum.Text = "Vaccum";
            this.toolStripMenuItem_vaccum.Click += new System.EventHandler(this.toolStripMenuItem_vaccum_Click);
            // 
            // imageList_files
            // 
            this.imageList_files.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList_files.ImageStream")));
            this.imageList_files.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList_files.Images.SetKeyName(0, "Root");
            // 
            // listView
            // 
            this.listView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listView.FullRowSelect = true;
            this.listView.HideSelection = false;
            this.listView.Location = new System.Drawing.Point(3, 32);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(868, 470);
            this.listView.SmallImageList = this.imageList_files;
            this.listView.TabIndex = 1;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.ItemActivate += new System.EventHandler(this.listView_ItemActivate);
            this.listView.SelectedIndexChanged += new System.EventHandler(this.listView_SelectedIndexChanged);
            this.listView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listView_KeyDown);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Size";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Attributes";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "CreateTime";
            this.columnHeader4.Width = 115;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "ModifyTime";
            this.columnHeader5.Width = 115;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "FileTime";
            this.columnHeader6.Width = 115;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Path";
            // 
            // textBox_path
            // 
            this.textBox_path.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_path.Location = new System.Drawing.Point(42, 6);
            this.textBox_path.Name = "textBox_path";
            this.textBox_path.Size = new System.Drawing.Size(795, 20);
            this.textBox_path.TabIndex = 3;
            this.textBox_path.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_path_KeyDown);
            // 
            // button_go
            // 
            this.button_go.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_go.Location = new System.Drawing.Point(838, 5);
            this.button_go.Name = "button_go";
            this.button_go.Size = new System.Drawing.Size(33, 22);
            this.button_go.TabIndex = 4;
            this.button_go.Text = "Go";
            this.button_go.UseVisualStyleBackColor = true;
            this.button_go.Click += new System.EventHandler(this.button_go_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_fileOrDir,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel_size,
            this.toolStripStatusLabel_attri,
            this.toolStripStatusLabel_createTime,
            this.toolStripStatusLabel_modifyTime});
            this.statusStrip.Location = new System.Drawing.Point(0, 554);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1219, 24);
            this.statusStrip.TabIndex = 5;
            this.statusStrip.Text = "statusStrip";
            // 
            // toolStripStatusLabel_fileOrDir
            // 
            this.toolStripStatusLabel_fileOrDir.Name = "toolStripStatusLabel_fileOrDir";
            this.toolStripStatusLabel_fileOrDir.Size = new System.Drawing.Size(50, 19);
            this.toolStripStatusLabel_fileOrDir.Text = "[file/dir]";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(916, 19);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // toolStripStatusLabel_size
            // 
            this.toolStripStatusLabel_size.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel_size.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel_size.Name = "toolStripStatusLabel_size";
            this.toolStripStatusLabel_size.Size = new System.Drawing.Size(38, 19);
            this.toolStripStatusLabel_size.Text = "[size]";
            // 
            // toolStripStatusLabel_attri
            // 
            this.toolStripStatusLabel_attri.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel_attri.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel_attri.Name = "toolStripStatusLabel_attri";
            this.toolStripStatusLabel_attri.Size = new System.Drawing.Size(40, 19);
            this.toolStripStatusLabel_attri.Text = "[attri]";
            // 
            // toolStripStatusLabel_createTime
            // 
            this.toolStripStatusLabel_createTime.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel_createTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel_createTime.Name = "toolStripStatusLabel_createTime";
            this.toolStripStatusLabel_createTime.Size = new System.Drawing.Size(77, 19);
            this.toolStripStatusLabel_createTime.Text = "[createTime]";
            // 
            // toolStripStatusLabel_modifyTime
            // 
            this.toolStripStatusLabel_modifyTime.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel_modifyTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel_modifyTime.Name = "toolStripStatusLabel_modifyTime";
            this.toolStripStatusLabel_modifyTime.Size = new System.Drawing.Size(83, 19);
            this.toolStripStatusLabel_modifyTime.Text = "[modifyTime]";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button_reload);
            this.splitContainer1.Panel1.Controls.Add(this.treeView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.listView);
            this.splitContainer1.Panel2.Controls.Add(this.textBox_path);
            this.splitContainer1.Panel2.Controls.Add(this.button_go);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Size = new System.Drawing.Size(1205, 522);
            this.splitContainer1.SplitterDistance = 321;
            this.splitContainer1.SplitterWidth = 8;
            this.splitContainer1.TabIndex = 6;
            // 
            // button_reload
            // 
            this.button_reload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_reload.Location = new System.Drawing.Point(264, 5);
            this.button_reload.Name = "button_reload";
            this.button_reload.Size = new System.Drawing.Size(33, 22);
            this.button_reload.TabIndex = 5;
            this.button_reload.Text = "RL";
            this.button_reload.UseVisualStyleBackColor = true;
            this.button_reload.Click += new System.EventHandler(this.button_reload_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 505);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(267, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "\"Active\" to view; \"Delete\" to delete; \"Insert\" to restore;";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1219, 554);
            this.tabControl.TabIndex = 7;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1211, 528);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Structural View";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_search_liner_clear);
            this.tabPage2.Controls.Add(this.button_search_liner);
            this.tabPage2.Controls.Add(this.bindingNavigatorSearch);
            this.tabPage2.Controls.Add(this.textBox_search_liner);
            this.tabPage2.Controls.Add(this.button_reload_linear);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.textBox_listRawData);
            this.tabPage2.Controls.Add(this.listView_indexList);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1211, 528);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Linear View";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_search_liner_clear
            // 
            this.button_search_liner_clear.Location = new System.Drawing.Point(349, 6);
            this.button_search_liner_clear.Name = "button_search_liner_clear";
            this.button_search_liner_clear.Size = new System.Drawing.Size(33, 22);
            this.button_search_liner_clear.TabIndex = 9;
            this.button_search_liner_clear.Text = "Cl";
            this.button_search_liner_clear.UseVisualStyleBackColor = true;
            this.button_search_liner_clear.Click += new System.EventHandler(this.button_search_liner_clear_Click);
            // 
            // button_search_liner
            // 
            this.button_search_liner.Location = new System.Drawing.Point(310, 6);
            this.button_search_liner.Name = "button_search_liner";
            this.button_search_liner.Size = new System.Drawing.Size(33, 22);
            this.button_search_liner.TabIndex = 9;
            this.button_search_liner.Text = "Sr";
            this.button_search_liner.UseVisualStyleBackColor = true;
            this.button_search_liner.Click += new System.EventHandler(this.button_search_liner_Click);
            // 
            // bindingNavigatorSearch
            // 
            this.bindingNavigatorSearch.AddNewItem = null;
            this.bindingNavigatorSearch.CountItem = null;
            this.bindingNavigatorSearch.DeleteItem = null;
            this.bindingNavigatorSearch.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigatorSearch.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.bindingNavigatorSearch.Location = new System.Drawing.Point(397, 4);
            this.bindingNavigatorSearch.MoveFirstItem = null;
            this.bindingNavigatorSearch.MoveLastItem = null;
            this.bindingNavigatorSearch.MoveNextItem = null;
            this.bindingNavigatorSearch.MovePreviousItem = null;
            this.bindingNavigatorSearch.Name = "bindingNavigatorSearch";
            this.bindingNavigatorSearch.PositionItem = null;
            this.bindingNavigatorSearch.Size = new System.Drawing.Size(184, 25);
            this.bindingNavigatorSearch.TabIndex = 8;
            this.bindingNavigatorSearch.Text = "bindingNavigatorSearch";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(25, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            this.bindingNavigatorPositionItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bindingNavigatorPositionItem_KeyDown);
            this.bindingNavigatorPositionItem.Validating += new System.ComponentModel.CancelEventHandler(this.bindingNavigatorPositionItem_Validating);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // textBox_search_liner
            // 
            this.textBox_search_liner.Location = new System.Drawing.Point(204, 7);
            this.textBox_search_liner.Name = "textBox_search_liner";
            this.textBox_search_liner.Size = new System.Drawing.Size(100, 20);
            this.textBox_search_liner.TabIndex = 7;
            this.textBox_search_liner.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_search_liner_KeyDown);
            // 
            // button_reload_linear
            // 
            this.button_reload_linear.Location = new System.Drawing.Point(79, 6);
            this.button_reload_linear.Name = "button_reload_linear";
            this.button_reload_linear.Size = new System.Drawing.Size(33, 22);
            this.button_reload_linear.TabIndex = 6;
            this.button_reload_linear.Text = "RL";
            this.button_reload_linear.UseVisualStyleBackColor = true;
            this.button_reload_linear.Click += new System.EventHandler(this.button_reload_linear_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "QuickSearch";
            // 
            // textBox_listRawData
            // 
            this.textBox_listRawData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_listRawData.HideSelection = false;
            this.textBox_listRawData.Location = new System.Drawing.Point(116, 30);
            this.textBox_listRawData.Multiline = true;
            this.textBox_listRawData.Name = "textBox_listRawData";
            this.textBox_listRawData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_listRawData.Size = new System.Drawing.Size(1092, 495);
            this.textBox_listRawData.TabIndex = 1;
            this.textBox_listRawData.WordWrap = false;
            // 
            // listView_indexList
            // 
            this.listView_indexList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listView_indexList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7});
            this.listView_indexList.HideSelection = false;
            this.listView_indexList.Location = new System.Drawing.Point(3, 30);
            this.listView_indexList.MultiSelect = false;
            this.listView_indexList.Name = "listView_indexList";
            this.listView_indexList.Size = new System.Drawing.Size(107, 495);
            this.listView_indexList.TabIndex = 0;
            this.listView_indexList.UseCompatibleStateImageBehavior = false;
            this.listView_indexList.View = System.Windows.Forms.View.Details;
            this.listView_indexList.SelectedIndexChanged += new System.EventHandler(this.listView_indexList_SelectedIndexChanged);
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "IndexName";
            this.columnHeader7.Width = 90;
            // 
            // FormHExplorer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 578);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.statusStrip);
            this.Name = "FormHExplorer";
            this.Text = "FormHExplorer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormHExplorer_FormClosing);
            this.Shown += new System.EventHandler(this.FormHExplorer_Shown);
            this.contextMenuStrip_treeViewRoot.ResumeLayout(false);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSearch)).EndInit();
            this.bindingNavigatorSearch.ResumeLayout(false);
            this.bindingNavigatorSearch.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_path;
        private System.Windows.Forms.Button button_go;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_fileOrDir;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_size;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_attri;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_createTime;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_modifyTime;
        private System.Windows.Forms.ImageList imageList_files;
        private System.Windows.Forms.Button button_reload;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button_search_liner_clear;
        private System.Windows.Forms.Button button_search_liner;
        private System.Windows.Forms.BindingNavigator bindingNavigatorSearch;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.TextBox textBox_search_liner;
        private System.Windows.Forms.Button button_reload_linear;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_listRawData;
        private System.Windows.Forms.ListView listView_indexList;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_treeViewRoot;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_vaccum;
    }
}