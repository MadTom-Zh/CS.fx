﻿namespace MadTomDev.App
{
    partial class FormConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormConfig));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox_runAtStartup = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_ODirBrowser = new System.Windows.Forms.Button();
            this.textBox_ODir = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_HDirBrowser = new System.Windows.Forms.Button();
            this.textBox_HDir = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_largeFileSizeMB = new System.Windows.Forms.NumericUpDown();
            this.checkBox_skipLargeFiles = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView_excluding = new System.Windows.Forms.DataGridView();
            this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Text = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_atRoot = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button_ok = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.betterFolderBrowser = new WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser(this.components);
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button_bkNLog_dir = new System.Windows.Forms.Button();
            this.textBox_bkNLog_dir = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox_bk_changed = new System.Windows.Forms.CheckBox();
            this.checkBox_bk_deleted = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_largeFileSizeMB)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_excluding)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox_runAtStartup);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 82);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Application";
            // 
            // checkBox_runAtStartup
            // 
            this.checkBox_runAtStartup.AutoSize = true;
            this.checkBox_runAtStartup.Location = new System.Drawing.Point(6, 19);
            this.checkBox_runAtStartup.Name = "checkBox_runAtStartup";
            this.checkBox_runAtStartup.Size = new System.Drawing.Size(93, 17);
            this.checkBox_runAtStartup.TabIndex = 0;
            this.checkBox_runAtStartup.Text = "Run at startup";
            this.checkBox_runAtStartup.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.button_ODirBrowser);
            this.groupBox2.Controls.Add(this.textBox_ODir);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.button_HDirBrowser);
            this.groupBox2.Controls.Add(this.textBox_HDir);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(218, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(570, 82);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "File sources";
            // 
            // button_ODirBrowser
            // 
            this.button_ODirBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ODirBrowser.Location = new System.Drawing.Point(489, 47);
            this.button_ODirBrowser.Name = "button_ODirBrowser";
            this.button_ODirBrowser.Size = new System.Drawing.Size(75, 22);
            this.button_ODirBrowser.TabIndex = 5;
            this.button_ODirBrowser.Text = "Browser...";
            this.button_ODirBrowser.UseVisualStyleBackColor = true;
            this.button_ODirBrowser.Click += new System.EventHandler(this.button_ODirBrowser_Click);
            // 
            // textBox_ODir
            // 
            this.textBox_ODir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_ODir.Location = new System.Drawing.Point(68, 48);
            this.textBox_ODir.Name = "textBox_ODir";
            this.textBox_ODir.ReadOnly = true;
            this.textBox_ODir.Size = new System.Drawing.Size(415, 20);
            this.textBox_ODir.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "OpenFolder";
            // 
            // button_HDirBrowser
            // 
            this.button_HDirBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_HDirBrowser.Location = new System.Drawing.Point(489, 18);
            this.button_HDirBrowser.Name = "button_HDirBrowser";
            this.button_HDirBrowser.Size = new System.Drawing.Size(75, 22);
            this.button_HDirBrowser.TabIndex = 2;
            this.button_HDirBrowser.Text = "Browser...";
            this.button_HDirBrowser.UseVisualStyleBackColor = true;
            this.button_HDirBrowser.Click += new System.EventHandler(this.button_HDirBrowser_Click);
            // 
            // textBox_HDir
            // 
            this.textBox_HDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_HDir.Location = new System.Drawing.Point(68, 19);
            this.textBox_HDir.Name = "textBox_HDir";
            this.textBox_HDir.ReadOnly = true;
            this.textBox_HDir.Size = new System.Drawing.Size(415, 20);
            this.textBox_HDir.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hideout";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numericUpDown_largeFileSizeMB);
            this.groupBox3.Controls.Add(this.checkBox_skipLargeFiles);
            this.groupBox3.Location = new System.Drawing.Point(12, 100);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 112);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Limiters";
            // 
            // numericUpDown_largeFileSizeMB
            // 
            this.numericUpDown_largeFileSizeMB.Location = new System.Drawing.Point(24, 42);
            this.numericUpDown_largeFileSizeMB.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDown_largeFileSizeMB.Name = "numericUpDown_largeFileSizeMB";
            this.numericUpDown_largeFileSizeMB.Size = new System.Drawing.Size(131, 20);
            this.numericUpDown_largeFileSizeMB.TabIndex = 1;
            this.numericUpDown_largeFileSizeMB.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // checkBox_skipLargeFiles
            // 
            this.checkBox_skipLargeFiles.AutoSize = true;
            this.checkBox_skipLargeFiles.Location = new System.Drawing.Point(6, 19);
            this.checkBox_skipLargeFiles.Name = "checkBox_skipLargeFiles";
            this.checkBox_skipLargeFiles.Size = new System.Drawing.Size(149, 17);
            this.checkBox_skipLargeFiles.TabIndex = 0;
            this.checkBox_skipLargeFiles.Text = "Skip files bigger than (MB)";
            this.checkBox_skipLargeFiles.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.dataGridView_excluding);
            this.groupBox4.Location = new System.Drawing.Point(218, 100);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(570, 309);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Limiters excluding";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 290);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(204, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Use \'?\' for one unknow char, or \'*\' for any;";
            // 
            // dataGridView_excluding
            // 
            this.dataGridView_excluding.AllowUserToOrderColumns = true;
            this.dataGridView_excluding.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_excluding.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_excluding.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.No,
            this.col_Text,
            this.col_atRoot});
            this.dataGridView_excluding.Location = new System.Drawing.Point(9, 19);
            this.dataGridView_excluding.Name = "dataGridView_excluding";
            this.dataGridView_excluding.Size = new System.Drawing.Size(555, 268);
            this.dataGridView_excluding.TabIndex = 0;
            this.dataGridView_excluding.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_excluding_CellEndEdit);
            this.dataGridView_excluding.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dataGridView_excluding_RowsAdded);
            this.dataGridView_excluding.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridView_excluding_RowsRemoved);
            this.dataGridView_excluding.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dataGridView_excluding_UserAddedRow);
            this.dataGridView_excluding.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dataGridView_excluding_UserDeletedRow);
            // 
            // No
            // 
            this.No.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.No.Frozen = true;
            this.No.HeaderText = "No";
            this.No.Name = "No";
            this.No.ReadOnly = true;
            this.No.Width = 21;
            // 
            // col_Text
            // 
            this.col_Text.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.col_Text.FillWeight = 300F;
            this.col_Text.Frozen = true;
            this.col_Text.HeaderText = "Text";
            this.col_Text.Name = "col_Text";
            this.col_Text.Width = 53;
            // 
            // col_atRoot
            // 
            this.col_atRoot.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.col_atRoot.Frozen = true;
            this.col_atRoot.HeaderText = "RootOnly";
            this.col_atRoot.Name = "col_atRoot";
            this.col_atRoot.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.col_atRoot.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.col_atRoot.Width = 76;
            // 
            // button_ok
            // 
            this.button_ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ok.Location = new System.Drawing.Point(626, 415);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(75, 23);
            this.button_ok.TabIndex = 4;
            this.button_ok.Text = "Ok";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cancel.Location = new System.Drawing.Point(707, 415);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(75, 23);
            this.button_cancel.TabIndex = 5;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // betterFolderBrowser
            // 
            this.betterFolderBrowser.Multiselect = false;
            this.betterFolderBrowser.RootFolder = "C:\\Personal\\Desktop";
            this.betterFolderBrowser.Title = "Please select a folder...";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button_bkNLog_dir);
            this.groupBox5.Controls.Add(this.textBox_bkNLog_dir);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.checkBox_bk_changed);
            this.groupBox5.Controls.Add(this.checkBox_bk_deleted);
            this.groupBox5.Location = new System.Drawing.Point(12, 218);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 124);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Backup and Log";
            // 
            // button_bkNLog_dir
            // 
            this.button_bkNLog_dir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_bkNLog_dir.Location = new System.Drawing.Point(114, 61);
            this.button_bkNLog_dir.Name = "button_bkNLog_dir";
            this.button_bkNLog_dir.Size = new System.Drawing.Size(75, 22);
            this.button_bkNLog_dir.TabIndex = 4;
            this.button_bkNLog_dir.Text = "Browser...";
            this.button_bkNLog_dir.UseVisualStyleBackColor = true;
            this.button_bkNLog_dir.Click += new System.EventHandler(this.button_bkNLog_dir_Click);
            // 
            // textBox_bkNLog_dir
            // 
            this.textBox_bkNLog_dir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_bkNLog_dir.Location = new System.Drawing.Point(6, 85);
            this.textBox_bkNLog_dir.Name = "textBox_bkNLog_dir";
            this.textBox_bkNLog_dir.ReadOnly = true;
            this.textBox_bkNLog_dir.Size = new System.Drawing.Size(183, 20);
            this.textBox_bkNLog_dir.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Store Directory";
            // 
            // checkBox_bk_changed
            // 
            this.checkBox_bk_changed.AutoSize = true;
            this.checkBox_bk_changed.Location = new System.Drawing.Point(6, 42);
            this.checkBox_bk_changed.Name = "checkBox_bk_changed";
            this.checkBox_bk_changed.Size = new System.Drawing.Size(109, 17);
            this.checkBox_bk_changed.TabIndex = 1;
            this.checkBox_bk_changed.Text = "Backup Changed";
            this.checkBox_bk_changed.UseVisualStyleBackColor = true;
            // 
            // checkBox_bk_deleted
            // 
            this.checkBox_bk_deleted.AutoSize = true;
            this.checkBox_bk_deleted.Location = new System.Drawing.Point(6, 19);
            this.checkBox_bk_deleted.Name = "checkBox_bk_deleted";
            this.checkBox_bk_deleted.Size = new System.Drawing.Size(103, 17);
            this.checkBox_bk_deleted.TabIndex = 0;
            this.checkBox_bk_deleted.Text = "Backup Deleted";
            this.checkBox_bk_deleted.UseVisualStyleBackColor = true;
            // 
            // FormConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormConfig";
            this.Load += new System.EventHandler(this.FormConfig_Load);
            this.Shown += new System.EventHandler(this.FormConfig_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_largeFileSizeMB)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_excluding)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox_runAtStartup;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_ODirBrowser;
        private System.Windows.Forms.TextBox textBox_ODir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_HDirBrowser;
        private System.Windows.Forms.TextBox textBox_HDir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridView_excluding;
        private System.Windows.Forms.NumericUpDown numericUpDown_largeFileSizeMB;
        private System.Windows.Forms.CheckBox checkBox_skipLargeFiles;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Button button_cancel;
        private WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser betterFolderBrowser;
        private System.Windows.Forms.DataGridViewTextBoxColumn No;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Text;
        private System.Windows.Forms.DataGridViewCheckBoxColumn col_atRoot;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox checkBox_bk_changed;
        private System.Windows.Forms.CheckBox checkBox_bk_deleted;
        private System.Windows.Forms.Button button_bkNLog_dir;
        private System.Windows.Forms.TextBox textBox_bkNLog_dir;
        private System.Windows.Forms.Label label4;
    }
}