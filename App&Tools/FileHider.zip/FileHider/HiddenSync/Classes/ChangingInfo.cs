﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadTomDev.App.Classes
{
    public class ChangingInfo
    {
        public enum ChangeTypeEnum
        { Presence, Vanished, DirRename, }
        public ChangeTypeEnum changeType;
        public string fullNameInPath;
        public string newDirFullNameInPath;
        public string name
        {
            get
            {
                if (fullNameInPath != null)
                {
                    if (fullNameInPath.Contains(Path.DirectorySeparatorChar))
                        return fullNameInPath.Substring(
                            fullNameInPath.LastIndexOf(Path.DirectorySeparatorChar) + 1);
                    else
                        return fullNameInPath;
                }
                return null;
            }
        }
        public long fileLength = 0;

        internal DateTime time;

    }
}
