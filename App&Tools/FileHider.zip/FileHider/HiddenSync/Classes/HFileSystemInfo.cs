﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadTomDev.App.Classes
{
    class HFileSystemInfo
    {
        public long ID;
        public string parentIndexName;
        public string fullName;
        public string name
        {
            get
            {
                if (fullName.Contains(Path.DirectorySeparatorChar))
                    return fullName.Substring(fullName.LastIndexOf(Path.DirectorySeparatorChar) + 1);
                else
                    return fullName;
            }
        }
        public long size;
        public FileAttributes attributes;
        public bool isDirectory
        {
            get
            {
                return (attributes & FileAttributes.Directory)
                    == FileAttributes.Directory;
            }
        }
        public bool isDeleted = false;
        public DateTime createTime;
        public DateTime modifyTime;
        public DateTime egzFileTime;
        public string IOContent
        {
            get
            {
                StringBuilder result = new StringBuilder();
                result.Append(ID);
                result.Append('\t');
                result.Append(fullName);
                result.Append('\t');
                result.Append(size);
                result.Append('\t');
                result.Append(Convert.ToInt32(attributes));
                result.Append('\t');
                result.Append(isDeleted.ToString());
                result.Append('\t');
                result.Append(createTime.ToBinary());
                result.Append('\t');
                result.Append(modifyTime.ToBinary());
                result.Append('\t');
                result.Append(egzFileTime.ToBinary());
                return result.ToString();
            }
            set
            {
                string[] parts = value.Split('\t');
                ID = long.Parse(parts[0]);
                fullName = parts[1];
                size = int.Parse(parts[2]);
                attributes = (FileAttributes)int.Parse(parts[3]);
                isDeleted = bool.Parse(parts[4]);
                createTime = DateTime.FromBinary(long.Parse(parts[5]));
                modifyTime = DateTime.FromBinary(long.Parse(parts[6]));
                egzFileTime = DateTime.FromBinary(long.Parse(parts[7]));
            }
        }

        public string nameExtension
        {
            get
            {
                string result = name;
                if (name.Contains('.'))
                    return name.Substring(name.LastIndexOf('.'));
                else
                    return "";
            }
        }
    }
}
