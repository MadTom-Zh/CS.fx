﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MadTomDev.CommonClasses;

namespace MadTomDev.App.Classes
{
    public class LoggerAdv : Logger
    {
        private LoggerAdv() { }
        private static LoggerAdv instance = null;
        public static LoggerAdv GetInstance()
        {
            if (instance == null)
            {
                instance = new LoggerAdv();
            }
            return instance;
        }
        public bool IsWriteFile { get; set; } = true;

        public class ItemClass
        {
            public ItemClass(Levels level, Exception error = null, string message = null, string details = null)
            {
                _Init(level, error, message, details, DateTime.Now);
            }
            public ItemClass(Levels level, Exception error, string message, string details, DateTime occurTime)
            {
                _Init(level, error, message, details, occurTime);
            }
            private void _Init(Levels level, Exception error, string message, string details, DateTime occurTime)
            {
                _Level = level;
                this.error = error;
                this.msg = message;
                this.details = details;
                OccurTime = occurTime;
            }

            public enum Levels
            {
                None = 0, Info = 1, Warning = 2, Error = 3,
            }
            private Levels _Level = Levels.None;
            public Levels Level { get { return _Level; } }
            public Exception error = null;
            private string msg;
            private string details;

            public DateTime OccurTime;
            public string Message
            {
                get
                {
                    switch (_Level)
                    {
                        case Levels.Error:
                            return error.Message;
                        case Levels.Warning:
                        case Levels.Info:
                        default:
                            return msg;
                    }
                }
            }
            public string Details
            {
                get
                {
                    switch (_Level)
                    {
                        case Levels.Error:
                            return error.ToString();
                        case Levels.Warning:
                        case Levels.Info:
                        default:
                            return details;
                    }
                }
            }
        }

        public List<ItemClass> AllLogList = new List<ItemClass>();
        public List<ItemClass> InfoList
        {
            get
            {
                return AllLogList.FindAll((ItemClass i) => i.Level == ItemClass.Levels.Info);
            }
        }
        public List<ItemClass> WarningList
        {
            get
            {
                return AllLogList.FindAll((ItemClass i) => i.Level == ItemClass.Levels.Warning);
            }
        }
        public List<ItemClass> ErrorList
        {
            get
            {
                return AllLogList.FindAll((ItemClass i) => i.Level == ItemClass.Levels.Error);
            }
        }

        public void Clear()
        {
            AllLogList.Clear();
            LogCleared?.Invoke(this, null);
        }
        public void Remove(IEnumerable<ItemClass> items)
        {
            foreach (ItemClass i in items)
                AllLogList.Remove(i);
        }

        public class NewLogArgs : EventArgs
        {
            public ItemClass newLog;
        }
        public event EventHandler<NewLogArgs> NewLog;
        public event EventHandler LogCleared;

        public const char tabChar = '\t';
        public void Log(ItemClass logItem)
        {
            AllLogList.Add(logItem);
            if (IsWriteFile)
                base.Log(logItem.Level + tabChar.ToString() + logItem.Message + ((logItem.Details == null) ? "" : (tabChar + logItem.Details)));
            NewLog?.Invoke(this, new NewLogArgs() { newLog = logItem, });
        }
        public new virtual void Log(string info)
        { Log(new ItemClass(ItemClass.Levels.Info, null, info)); }
        public void Log(string info, string details = null)
        { Log(new ItemClass(ItemClass.Levels.Info, null, info, details)); }
        public void LogWarning(string message, string details = null)
        { Log(new ItemClass(ItemClass.Levels.Warning, null, message, details)); }
        public new virtual void Log(Exception error)
        { Log(new ItemClass(ItemClass.Levels.Error, error)); }

        /// <summary>
        /// load all log files in a log dir;
        /// </summary>
        /// <param name="logDir"></param>
        /// <returns></returns>
        public static List<ItemClass> LoadLogFiles(string logDir)
        {
            return LoadLogFiles(logDir, DateTime.MinValue, DateTime.MaxValue);
        }
        /// <summary>
        /// load log files, after the time point given, in a log dir;
        /// </summary>
        /// <param name="logDir"></param>
        /// <param name="logFileStartTime"></param>
        /// <returns></returns>
        public static List<ItemClass> LoadLogFiles(string logDir, DateTime logFileStartTime)
        {
            return LoadLogFiles(logDir, logFileStartTime, DateTime.MaxValue);
        }
        /// <summary>
        /// load log files, after the start time, and before the end time, in a log dir;
        /// </summary>
        /// <param name="logDir"></param>
        /// <param name="logFileStartTime"></param>
        /// <param name="logFileEndTime"></param>
        /// <returns></returns>
        public static List<ItemClass> LoadLogFiles(string logDir, DateTime logFileStartTime, DateTime logFileEndTime)
        {
            List<Logger.LogFileInfo> allLogFiles = Logger.GetLogFiles(logDir);

            List<ItemClass> result = new List<ItemClass>();
            Logger.LogFileInfo lgf;
            int allLogFilesCount = allLogFiles.Count;
            for (int i = 0; i < allLogFilesCount; i++)
            {
                lgf = allLogFiles[i];
                if (lgf.timeOnName < logFileStartTime
                    || lgf.timeOnName > logFileEndTime)
                {
                    //allLogFiles.RemoveAt(i);
                }
                else
                {
                    result.AddRange(LoadLog(lgf.fullName));
                }
            }
            return result;
        }
        public static List<ItemClass> LoadLog(string logFileFullName)
        {
            List<ItemClass> result = new List<ItemClass>();

            string newLine = Environment.NewLine;
            string logTxtBlock = null;
            ItemClass newIC;
            foreach (string line in File.ReadAllLines(logFileFullName))
            {
                if (CheckLogLineStart(line))
                {
                    if (logTxtBlock != null)
                    {
                        newIC = MakeLogItem(logTxtBlock);
                        if (newIC != null) result.Add(newIC);
                    }
                    logTxtBlock = line;
                }
                else
                {
                    logTxtBlock += newLine + line;
                }
            }
            if (logTxtBlock != null)
            {
                newIC = MakeLogItem(logTxtBlock);
                if (newIC != null) result.Add(newIC);
            }
            return result;
        }
        private static bool CheckLogLineStart(string logLine)
        {
            if (logLine.Length >= 12)
            {
                char cI2 = logLine[2];
                if (cI2 == logLine[5])
                {
                    if (cI2 == ':')
                    {
                        if (logLine[8] == '.') return true;
                    }
                }
            }
            return false;
        }
        private static ItemClass MakeLogItem(string logTxtBlk)
        {
            int blankIdx = logTxtBlk.IndexOf(' ');
            if (blankIdx == 12)
            {
                string timeStr = logTxtBlk.Substring(0, 12);
                string[] parts = logTxtBlk.Substring(0, 13).Split('t');
                if (parts.Length < 2)
                    return null;

                try
                {
                    return new ItemClass(
                            (ItemClass.Levels)Enum.Parse(typeof(ItemClass.Levels), parts[0]),
                            null,
                            parts[1],
                            (parts.Length > 2 ? parts[2] : null),
                            DateTime.Parse(timeStr)
                            );
                }
                catch (Exception) { }
            }

            return null;
        }
    }
}
