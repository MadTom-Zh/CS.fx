﻿using MadTomDev.CommonClasses;
using MadTomDev.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadTomDev.App.Classes
{
    public class Settings : SettingsTxt
    {
        private bool? _Limi_IsSkipLargeFiles = null;
        public bool Limi_IsSkipLargeFiles
        {
            set
            {
                _Limi_IsSkipLargeFiles = value;
                base["Limi_IsSkipLargeFiles"] = value.ToString();
            }
            get
            {
                if (_Limi_IsSkipLargeFiles != null)
                    return _Limi_IsSkipLargeFiles == true;
                _Limi_IsSkipLargeFiles = SimpleValueHelper.TryGetBool(base["Limi_IsSkipLargeFiles"]);
                if (_Limi_IsSkipLargeFiles == null)
                {
                    _Limi_IsSkipLargeFiles = false;
                    base["Limi_IsSkipLargeFiles"] = false.ToString();
                }
                return _Limi_IsSkipLargeFiles == true;
            }
        }
        private long _Limi_LargeFileMinSize = -1;
        public long Limi_LargeFileMinSize
        {
            set
            {
                _Limi_LargeFileMinSize = -1;
                base["Limi_LargeFileMinSize"] = value.ToString();
            }
            get
            {
                if (_Limi_LargeFileMinSize < 0)
                {
                    _Limi_LargeFileMinSize = SimpleValueHelper.TryGetLong(base["Limi_LargeFileMinSize"]);
                    if (_Limi_LargeFileMinSize <= 0)
                    {
                        base["Limi_LargeFileMinSize"] = "5242880"; // 5m 5242880
                        _Limi_LargeFileMinSize = 5242880;
                    }
                }
                return _Limi_LargeFileMinSize;
            }
        }
        public string Limi_ExcludingList
        {
            set
            {
                base["Limi_ExcludingList"] = value;
            }
            get
            {
                return base["Limi_ExcludingList"];
            }
        }

        private bool? _Backup_Deleted = null;
        public bool Backup_Deleted
        {
            set
            {
                base["Backup_Deleted"] = value.ToString();
                _Backup_Deleted = null;
            }
            get
            {
                if (_Backup_Deleted != null)
                    return _Backup_Deleted == true;
                _Backup_Deleted = SimpleValueHelper.TryGetBool(base["Backup_Deleted"]);
                if (_Backup_Deleted == null)
                {
                    _Backup_Deleted = false;
                    base["Backup_Deleted"] = false.ToString();
                }
                return _Backup_Deleted == true;
            }
        }
        private bool? _Backup_Changed = null;
        public bool Backup_Changed
        {
            set
            {
                base["Backup_Changed"] = value.ToString();
                _Backup_Changed = null;
            }
            get
            {
                if (_Backup_Changed != null)
                    return _Backup_Changed == true;
                switch (SimpleValueHelper.TryGetBool(base["Backup_Changed"]))
                {
                    default:
                    case null:
                        base["Backup_Changed"] = false.ToString();
                        _Backup_Changed = false; break;
                    case true:
                        _Backup_Changed = true; break;
                    case false:
                        _Backup_Changed = false; break;
                }
                return _Backup_Changed == true;
            }
        }
        public string StoreDirRelated_BkuNLog
        {
            set
            {
                base["StoreDirRelated_BkuNLog"] = value.ToString();
            }
            get
            {
                if (base["StoreDirRelated_BkuNLog"] == null)
                    base["StoreDirRelated_BkuNLog"] = "backup";
                return base["StoreDirRelated_BkuNLog"];
            }
        }


        public Guid HO_DevID
        {
            set
            {
                base["HO_DevID"] = value.ToString();
            }
            get
            {
                return SimpleValueHelper.TryGetGuid(base["HO_DevID"]);
            }
        }
        public string HO_Dir
        {
            set
            {
                base["HO_Dir"] = value.ToString();
            }
            get
            {
                return base["HO_Dir"];
            }
        }
        public string HO_PasswordMesh
        {
            set
            {
                base["HO_PasswordMesh"] = value.ToString();
            }
            get
            {
                return base["HO_PasswordMesh"];
            }
        }
        public Guid OD_DevID
        {
            set
            {
                base["OF_DevID"] = value.ToString();
            }
            get
            {
                return SimpleValueHelper.TryGetGuid(base["OF_DevID"]);
            }
        }
        public string OD_Dir
        {
            set
            {
                base["OF_Dir"] = value.ToString();
            }
            get
            {
                return base["OF_Dir"];
            }
        }

    }
}
