﻿using MadTomDev.App.Classes;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using MadTomDev.Math;
using MadTomDev.Resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MadTomDev.App.Classes
{
    public class FileOperator
    {
        public static string FileNewLine = "\r\n";
        internal static string IndexDirNamePre = "fdr";
        internal static string IndexFileNamePre = "idx";
        public static int IndexCapacity = 1000;
        internal static string PackageDirNamePre = "pkg";

        public string HODir { private set; get; }
        public string ODDir { private set; get; }

        private Core core;
        public FileOperator(Core core)
        {
            this.core = core;
            GetHODir();
            if (HODir != null)
                SetHideout(HODir, core.settings.HO_PasswordMesh, false);
            GetODDir();
        }

        internal string GetPathInHODir(string fullPath)
        {
            if (HODir == null)
                throw new MissingFieldException("Hide-out directory has not been set.", "HODir");
            if (fullPath.StartsWith(HODir))
            {
                string test = fullPath.Substring(HODir.Length);
                if (test.Length == 0)
                    return "";
                else if (test.StartsWith(Path.DirectorySeparatorChar.ToString()))
                    return test.Substring(1);
            }
            throw new ArgumentException("Input path is not a sub of the Hide-out", "fullPath");
        }
        private string passwordForCipher;
        private byte confuseLength = 51;

        public string passwordMask
        { private set; get; }


        #region hide-out, open-dir, load and unload

        public bool IsHideoutSet { private set; get; } = false;

        public void SetHideout(string hoDir, string password, bool isPlaintextOrMask = true)
        {
            if (!Directory.Exists(hoDir))
                throw new DirectoryNotFoundException($"Hide-out dir [{hoDir}] is not found.");

            core.settings.HO_DevID
                = core.driveHelper.GetDeviceId(
                    hoDir[0]);
            core.settings.HO_Dir
                = HardwareInfoHelper.Drive.DeviceVolumeLetterUnknow
                + hoDir.Substring(1);

            HODir = hoDir;
            PasswordProtector pp = PasswordProtector.GetInstance(
                "Encry.cer",
                "zFfgsvcUrL0k@cjIvcUAACbCKjqarqqOrJ*HpnxCKdaU$omTI%^gSPFKeIjXWUM*gfE*A8BizOS!HY$0f#7kl8OnD2tA1HWA");
            if (isPlaintextOrMask)
            {
                pp.Password = password;
                passwordMask = pp.Password_Mashed;
            }
            else
            {
                pp.Password_Mashed = password;
                passwordMask = password;
            }
            passwordForCipher = pp.Password_forCipher;
            IsHideoutSet = true;
        }
        public void UnloadHideout()
        {
            HODir = null;
            IsHideoutSet = false;
        }


        internal string GetPathInODDir(string fullPath)
        {
            if (ODDir == null)
                throw new MissingFieldException("Open-dir directory has not been set.", "odDir");
            if (fullPath.StartsWith(ODDir))
            {
                string test = fullPath.Substring(ODDir.Length);
                if (test.Length == 0)
                    return "";
                else if (test.StartsWith(Path.DirectorySeparatorChar.ToString()))
                    return test.Substring(1);
            }
            throw new ArgumentException("Input path is not a sub of the Open-dir", "fullPath");
        }
        public bool IsOpenDirSet { private set; get; } = false;

        public void SetOpenDir(string ofDir)
        {
            if (!Directory.Exists(ofDir))
                throw new DirectoryNotFoundException($"Hide-out dir [{ofDir}] is not found.");

            core.settings.OD_DevID
                = core.driveHelper.GetDeviceId(
                    ofDir[0]);
            core.settings.OD_Dir
                = HardwareInfoHelper.Drive.DeviceVolumeLetterUnknow
                + ofDir.Substring(1);

            ODDir = ofDir;
            IsOpenDirSet = true;

        }
        internal void UnloadOpenDir()
        {
            ODDir = null;
            IsOpenDirSet = false;
        }

        #endregion


        #region loop all items in dir
        internal List<HFileSystemInfo> allHODirIndexes
            = new List<HFileSystemInfo>();
        internal Dictionary<string, List<HFileSystemInfo>> allHOFileIndexes
            = new Dictionary<string, List<HFileSystemInfo>>();


        internal void LoadAllHOIndexes()
        {
            allHODirIndexes.Clear();
            allHOFileIndexes.Clear();
            DirectoryInfo hoDirInfo = new DirectoryInfo(HODir);
            FileInfo[] indexes = hoDirInfo.GetFiles(IndexDirNamePre);
            if (indexes.Length == 1)
                allHODirIndexes = LoadHOIndex(indexes[0].FullName);

            indexes = hoDirInfo.GetFiles(IndexFileNamePre + "*");
            List<HFileSystemInfo> loadedHFList;
            foreach (FileInfo i in indexes)
            {
                loadedHFList = LoadHOIndex(i.FullName);
                allHOFileIndexes.Add(i.Name, loadedHFList);
            }
        }
        private List<HFileSystemInfo> LoadHOIndex(string indexFileFullName)
        {
            List<HFileSystemInfo> result = new List<HFileSystemInfo>();
            string idxName = Path.GetFileName(indexFileFullName);
            foreach (string line in ReadIndexAllLines(indexFileFullName))
            {
                result.Add(new HFileSystemInfo()
                {
                    IOContent = line,
                    parentIndexName = idxName,
                });
            }
            return result;
        }


        /// <summary>
        /// 检查隐藏点H的完整性：
        /// 1.如果H中存在记录，而公开位置O没有这个文件；
        /// 2.或者两个文件的修改时间不一致；
        /// 以上两条满足一条，则返回false，即检查不通过
        /// </summary>
        /// <returns></returns>
        public bool CheckHIntegritness(out string msg)
        {
            msg = "";
            List<HFileSystemInfo> idx;
            string hItem;
            FileInfo hFileInfo;
            foreach (string idxName in allHOFileIndexes.Keys.ToArray())
            {
                idx = allHOFileIndexes[idxName];
                foreach (HFileSystemInfo h in idx)
                {
                    if (!h.isDirectory)
                    {
                        hItem = Path.Combine(
                            HODir,
                            PackageDirNamePre + idxName.Substring(IndexFileNamePre.Length),
                            h.ID.ToString());
                        hFileInfo = new FileInfo(hItem);
                        if (hFileInfo.Exists)
                        {
                            if (hFileInfo.LastWriteTime != h.egzFileTime)
                            {
                                msg = $"HFile record time [{ h.egzFileTime}] not matches with file time [{hFileInfo.LastWriteTime}]!";
                                return false;
                            }
                        }
                        else
                        {
                            msg = $"HFile [{hFileInfo.FullName}] not exists!";
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        private HFileSystemInfo GetHFileSystemItem(string pathInBase)
        {
            List<HFileSystemInfo> idx;
            HFileSystemInfo found;
            foreach (string ik in allHOFileIndexes.Keys.ToArray())
            {
                idx = allHOFileIndexes[ik];
                found = idx.Find(hf => hf.fullName == pathInBase);
                if (found != null)
                {
                    found.parentIndexName = ik;
                    return found;
                }
            }
            return null;
        }
        private HFileSystemInfo GetHRecycleFile()
        {
            List<HFileSystemInfo> idx;
            HFileSystemInfo found;
            foreach (string ik in allHOFileIndexes.Keys.ToArray())
            {
                idx = allHOFileIndexes[ik];
                found = idx.Find(hf => hf.isDeleted);
                if (found != null)
                {
                    return found;
                }
            }
            return null;
        }
        private HFileSystemInfo NewHFileSystemItem()
        {
            HFileSystemInfo result = new HFileSystemInfo()
            { ID = DateTime.Now.Ticks, };

            List<HFileSystemInfo> idx;
            foreach (string idxName in allHOFileIndexes.Keys.ToArray())
            {
                idx = allHOFileIndexes[idxName];
                if (idx.Count < IndexCapacity)
                {
                    result.parentIndexName = idxName;
                    idx.Add(result);
                    changedIndexes.Add(idxName);
                    return result;
                }
            }

            // not return? index dict is empty, or no empty sit available
            idx = new List<HFileSystemInfo>();
            idx.Add(result);
            string newIdxName = IndexFileNamePre;
            if (allHOFileIndexes.Count > 0)
                newIdxName += allHOFileIndexes.Count;
            result.parentIndexName = newIdxName;
            allHOFileIndexes.Add(newIdxName, idx);
            changedIndexes.Add(newIdxName);
            return result;
        }

        internal List<HFileSystemInfo> GetHFileSystemItems(string baseDir, bool fullDeepth, bool onlyDirs, out HashSet<string> notExistDirs)
        {
            List<HFileSystemInfo> result = new List<HFileSystemInfo>();
            notExistDirs = new HashSet<string>();
            bool inRoot = string.IsNullOrWhiteSpace(baseDir);

            if (inRoot)
            {
                if (fullDeepth)
                {
                    result.AddRange(allHODirIndexes.ToArray());
                    if (!onlyDirs)
                    {
                        foreach (List<HFileSystemInfo> idx in allHOFileIndexes.Values)
                            result.AddRange(idx.ToArray());
                    }
                }
                else // !fullDeepth
                {
                    result.AddRange(allHODirIndexes.Where(i =>
                        !i.fullName.Contains(Path.DirectorySeparatorChar)));
                    if (!onlyDirs)
                    {
                        foreach (List<HFileSystemInfo> idx in allHOFileIndexes.Values)
                            result.AddRange(idx.Where(i =>
                                !i.fullName.Contains(Path.DirectorySeparatorChar)));
                    }
                }
            }
            else
            {
                string baseDirPre = baseDir + Path.DirectorySeparatorChar;
                int baseDirPreLength = baseDirPre.Length;
                if (fullDeepth)
                {
                    result.AddRange(allHODirIndexes.Where(i =>
                        i.fullName.StartsWith(baseDirPre)));
                    if (!onlyDirs)
                    {
                        foreach (List<HFileSystemInfo> idx in allHOFileIndexes.Values)
                            result.AddRange(idx.Where(i =>
                                i.fullName.StartsWith(baseDirPre)));
                    }
                }
                else // !fullDeepth
                {
                    result.AddRange(allHODirIndexes.Where(i =>
                        i.fullName.StartsWith(baseDirPre)
                        && i.fullName.IndexOf(Path.DirectorySeparatorChar, baseDirPreLength) < 0));
                    if (!onlyDirs)
                    {
                        foreach (List<HFileSystemInfo> idx in allHOFileIndexes.Values)
                            result.AddRange(idx.Where(i =>
                                i.fullName.StartsWith(baseDirPre)
                                && i.fullName.IndexOf(Path.DirectorySeparatorChar, baseDirPreLength) < 0));
                    }
                }
            }
            foreach (HFileSystemInfo hi in result)
            {
                if (!hi.isDirectory && hi.fullName.Contains(Path.DirectorySeparatorChar))
                    notExistDirs.Add(hi.fullName.Substring(
                        0, hi.fullName.LastIndexOf(Path.DirectorySeparatorChar)));
            }
            foreach (HFileSystemInfo hi in allHODirIndexes)
            {
                if (hi.isDirectory)
                    notExistDirs.Remove(hi.fullName);
            }
            result.Sort((a, b) => a.fullName.CompareTo(b.fullName));
            return result;
        }
        internal bool CheckHaveSubs(string pathInBase, bool dirOnly)
        {
            string startStr = pathInBase + Path.DirectorySeparatorChar;
            if (allHODirIndexes.Any(i => i.fullName.StartsWith(startStr)))
            {
                return true;
            }
            else if (!dirOnly)
            {
                foreach (List<HFileSystemInfo> idx in allHOFileIndexes.Values)
                {
                    if (idx.Any(i => i.fullName.StartsWith(startStr)))
                        return true;
                }
            }
            return false;
        }


        internal List<HFileSystemInfo> LoadHOIndex(int indexOfIndex)
        {
            List<HFileSystemInfo> result = new List<HFileSystemInfo>();
            foreach (string line in
                ReadIndexAllLines(IndexFileNamePre + (indexOfIndex > 0 ? indexOfIndex.ToString() : "")))
            {
                result.Add(new HFileSystemInfo() { IOContent = line, });
            }
            return result;
        }



        internal List<FileSystemInfo> LoadAllODItems()
        {
            List<FileSystemInfo> result = new List<FileSystemInfo>();
            LoadAllODItems_loop(new DirectoryInfo(ODDir), ref result);
            return result;
        }
        private void LoadAllODItems_loop(
            DirectoryInfo baseDirInfo,
            ref List<FileSystemInfo> result,
            bool isRoot = true)
        {
            FileInfo[] subFileInfos = baseDirInfo.GetFiles();
            result.AddRange(subFileInfos);
            DirectoryInfo[] subDirInfos = baseDirInfo.GetDirectories();
            if (!isRoot)// && subFileInfos.Length == 0 && subDirInfos.Length == 0)
                result.Add(baseDirInfo);
            foreach (DirectoryInfo subDI in subDirInfos)
                LoadAllODItems_loop(subDI, ref result, false);
        }

        #endregion

        #region file transfer, and backup

        internal void TransferH2O(string pathInBase)
        {
            HFileSystemInfo hItem = GetHFileSystemItem(pathInBase);
            string oItem = Path.Combine(ODDir, pathInBase);

            if (hItem.isDirectory)
            {
                if (File.Exists(oItem))
                {
                    DeleteO(oItem);
                }
                DirectoryInfo di;
                if (Directory.Exists(oItem))
                    di = Directory.CreateDirectory(oItem);
                else
                    di = new DirectoryInfo(oItem);
                di.Attributes = hItem.attributes;
            }
            else
            {
                if (Directory.Exists(oItem))
                {
                    DeleteO(oItem);
                }
                UnEGZipFile(hItem, oItem);
            }
        }

        private HashSet<string> changedIndexes = new HashSet<string>();
        internal void TransferO2H(string pathInBase)
        {
            string oItem = Path.Combine(ODDir, pathInBase);
            bool oIsFile = File.Exists(oItem);
            DeleteH(pathInBase, true);


            HFileSystemInfo found;
            if (oIsFile)
            {
                found = GetHRecycleFile();
                if (found != null)
                    found.fullName = pathInBase;

                EGZipFile(oItem, found);
            }
            else
            {
                DirectoryInfo oDI = new DirectoryInfo(oItem);
                found = allHODirIndexes.Find(a => a.fullName == pathInBase);
                if (found == null)
                {
                    found = allHODirIndexes.Find(a => a.isDeleted == true);
                    if (found != null)
                    {
                        found.fullName = pathInBase;
                    }
                    else
                    {
                        found = new HFileSystemInfo()
                        { fullName = pathInBase, };
                        allHODirIndexes.Add(found);
                    }
                }
                found.isDeleted = false;
                found.attributes = oDI.Attributes;
                found.createTime = oDI.CreationTime;
                found.modifyTime = oDI.LastWriteTime;
                changedIndexes.Add(IndexDirNamePre);
            }
        }

        public void DeleteH(string pathInBase, bool ignorNotFound = false)
        {
            bool deleted = false;
            bool needBackup = core.settings.Backup_Deleted;

            HashSet<string> neDirs;
            List<HFileSystemInfo> subHiToDel = GetHFileSystemItems(pathInBase, true, false, out neDirs);
            foreach (HFileSystemInfo hi in subHiToDel)
            {
                if (!hi.isDeleted)
                {
                    if (needBackup && !hi.isDirectory)
                        BackHFile(hi);
                    deleted = true;
                    hi.isDeleted = true;
                    changedIndexes.Add(hi.parentIndexName);
                }
            }
            HFileSystemInfo hiToDel = GetHFileSystemItem(pathInBase);
            if (hiToDel != null && !hiToDel.isDeleted)
            {
                if (needBackup && !hiToDel.isDirectory)
                    BackHFile(hiToDel);
                deleted = true;
                hiToDel.isDeleted = true;
                changedIndexes.Add(hiToDel.parentIndexName);
            }
            hiToDel = allHODirIndexes.Find(a => a.fullName == pathInBase);
            if (hiToDel != null && !hiToDel.isDeleted)
            {
                deleted = true;
                hiToDel.isDeleted = true;
                changedIndexes.Add(hiToDel.parentIndexName);
            }

            if (!deleted && !ignorNotFound)
                core.loggerAdv.Log(new FileNotFoundException("Can't find the encrypt file for deleting.", Path.Combine(HODir, "[pkg#]", pathInBase)));
        }
        private void BackHFile(HFileSystemInfo hFile)
        {
            if (core.settings.Backup_Deleted)
            {
                string hItem = Path.Combine(
                    HODir,
                    PackageDirNamePre + hFile.parentIndexName.Substring(IndexFileNamePre.Length),
                    hFile.ID.ToString());

                string description = $"Backup file before delete in HO: {hFile.fullName}";
                string hex = SimpleStringHelper.ToHexString(DateTime.Now.Ticks);
                File.Copy(hItem, Path.Combine(GetStorageDir(), hex));
                description += $"{Environment.NewLine}Copy to file {hex}";
                core.loggerAdv.Log(description);
            }
        }

        /// <summary>
        /// the opposite of "DeleteH", mark isDelete to false;
        /// </summary>
        /// <param name="pathInBase"></param>
        internal void RestoreH(string pathInBase)
        {
            bool restored = false;
            HFileSystemInfo found = GetHFileSystemItem(pathInBase);
            if (found != null && found.isDeleted)
            {
                restored = true;
                found.isDeleted = false;
                changedIndexes.Add(found.parentIndexName);
            }
            HashSet<string> neDirs;
            List<HFileSystemInfo> subHFSIs
                = GetHFileSystemItems(pathInBase, true, false, out neDirs);
            foreach (HFileSystemInfo hi in subHFSIs)
            {
                if (hi.isDeleted)
                {
                    restored = true;
                    hi.isDeleted = false;
                    changedIndexes.Add(hi.parentIndexName);
                }
            }

            if (!restored)
                core.loggerAdv.Log(new FileNotFoundException("Can't find the encrypt file for restoring.", Path.Combine(HODir, "[pkg#]", pathInBase)));
        }

        /// <summary>
        /// delete all physical files that marked as "deleted";
        /// </summary>
        public void Vacuum()
        {
            string hFile, pkgDir;
            string pkgDirPre
                = Path.Combine(HODir, PackageDirNamePre);
            List<HFileSystemInfo> curIndex;
            foreach (string ik in allHOFileIndexes.Keys)
            {
                pkgDir = pkgDirPre + ik.Substring(IndexFileNamePre.Length);
                curIndex = allHOFileIndexes[ik];
                for (int i = curIndex.Count - 1; i >= 0; i--)
                {
                    HFileSystemInfo hi = curIndex[i];
                    if (!hi.isDeleted)
                        continue;
                    hFile = Path.Combine(
                        pkgDir,
                        hi.ID.ToString());
                    if (File.Exists(hFile))
                        File.Delete(hFile);
                    curIndex.RemoveAt(i);
                    changedIndexes.Add(ik);
                }
            }

            bool dirsChanged = false;
            for (int i = allHODirIndexes.Count - 1; i >= 0; i--)
            {
                HFileSystemInfo hi = allHODirIndexes[i];
                if (!hi.isDeleted)
                    continue;
                allHODirIndexes.RemoveAt(i);
                dirsChanged = true;
            }
            if (dirsChanged)
                changedIndexes.Add(IndexDirNamePre);

            CommitHIndexes();
        }

        //internal void RenameHDir(ChangingInfo ci)
        //{
        //    throw new NotImplementedException();
        //}




        public void DeleteO(string itemFullName)
        {
            string pathInBase = GetPathInODDir(itemFullName);
            if (File.Exists(itemFullName))
            {
                if (core.settings.Backup_Deleted)
                {
                    string description = $"Backup file before delete in OD: {pathInBase}";
                    string hex = SimpleStringHelper.ToHexString(DateTime.Now.Ticks);
                    File.Copy(itemFullName, Path.Combine(GetStorageDir(), hex));
                    description += $"{Environment.NewLine}Copy to file {hex}";
                    core.loggerAdv.Log(description);
                }
                File.Delete(itemFullName);
            }
            else if (Directory.Exists(itemFullName))
            {
                if (core.settings.Backup_Deleted)
                {
                    string description = $"Backup dir before delete in OD: {pathInBase}";
                    string hex = SimpleStringHelper.ToHexString(DateTime.Now.Ticks);
                    IOUtilities.CSharpWapper.DirectoyCopy(itemFullName, Path.Combine(GetStorageDir(), hex));
                    description += $"{Environment.NewLine}Copy to dir {hex}";
                    core.loggerAdv.Log(description);
                }
                IOUtilities.CSharpWapper.Delete(itemFullName);
            }
            else
            {
                core.loggerAdv.Log(new FileNotFoundException("File for deleting is not found.", itemFullName));
            }
        }


        private void UnEGZipFile(HFileSystemInfo hItem, string targetFullName)
        {
            if (!core.CheckExcluding(hItem.fullName))
            {
                core.loggerAdv.Log($"Excluding from H2O [{hItem.fullName}]");
                return;
            }
            if (core.settings.Limi_IsSkipLargeFiles
                && hItem.size > core.settings.Limi_LargeFileMinSize)
            {
                core.loggerAdv.Log($"Size limited from H2O [{hItem.fullName}], file size[{SimpleStringHelper.UnitsOfMeasure.GetShortString(hItem.size, "B", 1024, 2)}] greater than [{SimpleStringHelper.UnitsOfMeasure.GetShortString(core.settings.Limi_LargeFileMinSize, "B", 1024, 2)}].");
                return;
            }

            core.loggerAdv.Log($"H2O... [{hItem.fullName}]");
            if (Directory.Exists(targetFullName))
            {
                DeleteO(targetFullName);
            }
            else if (core.settings.Backup_Changed
                && File.Exists(targetFullName))
            {
                string description = $"Backup file before change in OD: {hItem.fullName}";
                string hex = SimpleStringHelper.ToHexString(DateTime.Now.Ticks);
                File.Copy(targetFullName, Path.Combine(GetStorageDir(), hex));
                description += $"{Environment.NewLine}Copy to file {hex}";
                core.loggerAdv.Log(description);
            }

            string gzFileFullName = Path.Combine(HODir,
                PackageDirNamePre + hItem.parentIndexName.Substring(IndexFileNamePre.Length),
                hItem.ID.ToString());
            try
            {
                EncryptedGZip.UnGZipDecryptFile(gzFileFullName, passwordForCipher, targetFullName, confuseLength, true);
            }
            catch (Exception err)
            {
                core.loggerAdv.Log(err);
                return;
            }

            // update last write time
            FileInfo oFile = new FileInfo(targetFullName);
            oFile.LastWriteTime = hItem.modifyTime;
            //if (oFile.CreationTime < oFile.LastWriteTime)
            //    oFile.CreationTime = oFile.LastWriteTime;
            core.loggerAdv.Log($"H2O complete from [{hItem.ID}] to [{hItem.fullName}]");
        }
        public void ExtractHFile(string pathInBase, string targetFullName)
        {
            HFileSystemInfo hi = GetHFileSystemItem(pathInBase);
            if (hi != null)
                UnEGZipFile(hi, targetFullName);
        }


        private void EGZipFile(string sourceFullName, HFileSystemInfo targetHFSI)
        {
            if (!File.Exists(sourceFullName))
                return;

            string pathInBase = GetPathInODDir(sourceFullName);
            if (!core.CheckExcluding(pathInBase))
            {
                core.loggerAdv.Log($"Excluding from O2H [{pathInBase}]");
                return;
            }
            FileInfo oFI = new FileInfo(sourceFullName);
            if (core.settings.Limi_IsSkipLargeFiles
                && oFI.Length > core.settings.Limi_LargeFileMinSize)
            {
                core.loggerAdv.Log($"Size limited from O2H [{pathInBase}], file size[{SimpleStringHelper.UnitsOfMeasure.GetShortString(oFI.Length, "B", 1024, 2)}] greater than [{SimpleStringHelper.UnitsOfMeasure.GetShortString(core.settings.Limi_LargeFileMinSize, "B", 1024, 2)}].");
                return;
            }

            core.loggerAdv.Log($"O2H... [{pathInBase}]");
            if (targetHFSI == null)
            {
                targetHFSI = NewHFileSystemItem();
                targetHFSI.fullName = pathInBase;
            }

            targetHFSI.attributes = oFI.Attributes;
            targetHFSI.createTime = oFI.CreationTime;
            targetHFSI.modifyTime = oFI.LastWriteTime;
            targetHFSI.size = oFI.Length;
            targetHFSI.isDeleted = false;

            string egzFileID = targetHFSI.ID.ToString();
            string egzPkg = PackageDirNamePre + targetHFSI.parentIndexName.Substring(IndexFileNamePre.Length);
            string egzFile = Path.Combine(HODir, egzPkg);
            try
            {
                if (!Directory.Exists(egzFile))
                    Directory.CreateDirectory(egzFile);
                egzFile = Path.Combine(egzFile, egzFileID);

                if (!targetHFSI.isDeleted && File.Exists(egzFile) && core.settings.Backup_Changed)
                {
                    string description = $"Backup file before change in HO: {targetHFSI.fullName}";
                    string hex = SimpleStringHelper.ToHexString(DateTime.Now.Ticks);
                    File.Copy(egzFile, Path.Combine(GetStorageDir(), hex));
                    description += $"{Environment.NewLine}Copy to file {hex}";
                    core.loggerAdv.Log(description);
                }

                EncryptedGZip.EncryptGZipFile(sourceFullName, passwordForCipher, egzFile, confuseLength, true);
                targetHFSI.egzFileTime = new FileInfo(egzFile).LastWriteTime;
            }
            catch (Exception err)
            {
                core.loggerAdv.Log(new LoggerAdv.ItemClass(LoggerAdv.ItemClass.Levels.Error, err));
                DeleteH(targetHFSI.fullName, true);
            }

            changedIndexes.Add(targetHFSI.parentIndexName);
            core.loggerAdv.Log($"O2H complete from [{pathInBase}] to [{egzPkg}\\{egzFileID}]");

        }



        internal void CommitHIndexes()
        {
            foreach (string idx in changedIndexes)
            {
                if (idx == IndexDirNamePre)
                    WriteIndex(idx, allHODirIndexes);
                else
                    WriteIndex(idx, allHOFileIndexes[idx]);
            }
            changedIndexes.Clear();
        }
        #endregion




        #region helper related

        public string GetHODir()
        {
            HODir = null;
            Guid devID = core.settings.HO_DevID;
            if (devID == Guid.Empty)
                return null;
            string result = core.settings.HO_Dir;
            if (string.IsNullOrWhiteSpace(result))
                return null;
            char devLt = core.driveHelper.GetDeviceVolumeLetter(devID);
            if (devLt == HardwareInfoHelper.Drive.DeviceVolumeLetterUnknow)
                return null;
            HODir = devLt + result.Substring(1);
            return HODir;
        }
        public string GetODDir()
        {
            ODDir = null;
            Guid devID = core.settings.OD_DevID;
            if (devID == Guid.Empty)
                return null;
            string result = core.settings.OD_Dir;
            if (string.IsNullOrWhiteSpace(result))
                return null;
            char devLt = core.driveHelper.GetDeviceVolumeLetter(devID);
            if (devLt == HardwareInfoHelper.Drive.DeviceVolumeLetterUnknow)
                return null;
            ODDir = devLt + result.Substring(1);
            return ODDir;
        }

        private void WriteIndex(string indexName, List<HFileSystemInfo> indexContent)
        {
            Stream rawInput;
            using (FileStream fsWriter = new FileStream(
                Path.Combine(HODir, indexName), FileMode.Create))
            {
                EncryptedGZip.EncryptGZip(out rawInput, fsWriter, passwordForCipher, confuseLength);
                byte[] contentBin;
                foreach (HFileSystemInfo hfsi in indexContent)
                {
                    contentBin = Encoding.UTF8.GetBytes(hfsi.IOContent + FileNewLine);
                    rawInput.Write(contentBin, 0, contentBin.Length);
                }

                rawInput.Flush();
                rawInput.Close();
                //fsWriter.Flush();
            }
        }

        private string[] ReadIndexAllLines(string indexFileFullName)
        {
            while (true)
            {
                FileStream tester = null;
                try
                {
                    tester = File.Open(
                        indexFileFullName,
                        FileMode.Open,
                        FileAccess.ReadWrite,
                        FileShare.None);
                    break;
                }
                catch (IOException)
                {
                    Thread.Sleep(500);
                }
                finally
                {
                    tester?.Close();
                }
            }

            using (FileStream fsReader = new FileStream(indexFileFullName, FileMode.Open))
            {
                Stream rawOutput;
                EncryptedGZip.UnGZipDecrypt(fsReader, out rawOutput, passwordForCipher, confuseLength);
                using (StreamReader sReader = new StreamReader(rawOutput))
                {
                    string raw = sReader.ReadToEnd();
                    string key = indexFileFullName.Substring(indexFileFullName.LastIndexOf(Path.DirectorySeparatorChar) + 1);
                    //if (AllHOIndexesRaw.ContainsKey(key))
                    //    AllHOIndexesRaw[key] = raw;
                    //else
                    //    AllHOIndexesRaw.Add(key, raw);
                    return raw.Split(new string[] { FileNewLine }, StringSplitOptions.RemoveEmptyEntries);
                }
            }
        }

        private string _StorageDir = null;
        internal string GetStorageDir()
        {
            if (_StorageDir == null)
            {
                _StorageDir = IOUtilities.Other.GetAbsolutePath(
                    AppDomain.CurrentDomain.BaseDirectory,
                    core.settings.StoreDirRelated_BkuNLog);
            }
            return _StorageDir;
        }
        internal void SetStorageDir(string storageFullPath)
        {
            _StorageDir = storageFullPath;
            core.settings.StoreDirRelated_BkuNLog
                = IOUtilities.Other.GetRelatedPath(
                AppDomain.CurrentDomain.BaseDirectory,
                storageFullPath);
        }





        #endregion
    }
}
