﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MadTomDev.App.Classes;
using MadTomDev.Data;
using MadTomDev.Resources;

namespace MadTomDev.App.Classes
{
    public class Core : IDisposable
    {
        public LoggerAdv loggerAdv;
        public Settings settings;
        public HardwareInfoHelper.Drive driveHelper;
        public FileOperator fileOperator;
        public Core(LoggerAdv loggerAdv)
        {
            this.loggerAdv = loggerAdv;

            loggerAdv.Log("Loading settings...");
            settings = new Settings()
            { SettingsFileFullName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "settings.txt"), };
            settings.ReLoad();

            driveHelper = HardwareInfoHelper.Drive.GetInstance();
            driveHelper.IsWatchingRemovableDrives = true;
            driveHelper.DevicePlugedIn += (s1, e1) =>
            {
                bool dirChanged = false;
                if (e1.plugedDeviceAdvInfo.DeviceId == settings.OD_DevID)
                {
                    if (!string.IsNullOrWhiteSpace(settings.OD_Dir))
                    {
                        fileOperator.SetOpenDir(
                            e1.plugedDeviceAdvInfo.VolumeLetter
                                + settings.OD_Dir.Substring(1));
                        dirChanged = true;
                    }
                }
                if (e1.plugedDeviceAdvInfo.DeviceId == settings.HO_DevID)
                {
                    if (!string.IsNullOrWhiteSpace(settings.HO_Dir))
                    {
                        fileOperator.SetHideout(
                            e1.plugedDeviceAdvInfo.VolumeLetter
                                + settings.HO_Dir.Substring(1),
                            settings.HO_PasswordMesh, false);
                        dirChanged = true;
                    }
                }
                if (dirChanged)
                    DirStatesChanged?.Invoke(this);
            };
            driveHelper.DevicePlugedOut += (s2, e2) =>
            {
                bool dirChanged = false;
                if (e2.plugedDeviceAdvInfo.DeviceId == settings.OD_DevID)
                { fileOperator.UnloadOpenDir(); dirChanged = true; }
                if (e2.plugedDeviceAdvInfo.DeviceId == settings.HO_DevID)
                { fileOperator.UnloadHideout(); dirChanged = true; }
                if (dirChanged)
                    DirStatesChanged?.Invoke(this);
            };

            excludingList.Clear();
            string eListStr = settings.Limi_ExcludingList;
            if (!string.IsNullOrEmpty(eListStr))
            {
                foreach (string eIo in eListStr.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries))
                    excludingList.Add(new ExcludingItem(eIo));
            }

            loggerAdv.Log("Initializing FileOperator...");
            fileOperator = new FileOperator(this);

            loggerAdv.BaseDir = Path.Combine(fileOperator.GetStorageDir(), "Logs");
            loggerAdv.Log("Ready.");

        }

        private bool CheckSyncDir()
        {
            string hDir = fileOperator.GetHODir();
            if (hDir == null)
            {
                loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Warning,
                    null,
                    "Hide-out directory is not ready."));
                return false;
            }
            string oDir = fileOperator.GetODDir();
            if (hDir == null)
            {
                loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Warning,
                    null,
                    "Open-file directory is not ready."));
                return false;
            }
            if (hDir.Contains(oDir))
            {
                loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Error,
                    null,
                    "Open-dir is inside Hide-out!"));
                return false;
            }
            if (oDir.Contains(hDir))
            {
                loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Error,
                    null,
                    "Hide-out is inside Open-dir!"));
                return false;
            }
            return true;
        }


        public enum SyncStatusEnum
        { Idle, Scanning, Syncing, }
        public SyncStatusEnum SyncStatus
        { private set; get; } = SyncStatusEnum.Idle;


        public delegate void SyncStartStopDelegate(Core sender, bool isStartedOrStoped);
        public event SyncStartStopDelegate SyncStartStop;
        public delegate void SyncProgressDelegate(Core sender, string pathInBase, bool isH2O_orO2H);
        public event SyncProgressDelegate SyncProgressing;
        public delegate void SyncDeletingDelegate(Core sender, string pathInBase, bool fromH_orO);
        public event SyncDeletingDelegate SyncDeleting;
        public delegate void SyncErrorDelegate(Core sender, Exception err);
        public event SyncErrorDelegate SyncError;
        public delegate void DirStatesChangedDelegate(Core sender);
        public event DirStatesChangedDelegate DirStatesChanged;


        public void Sync_ASync(SyncDirection syncDirection)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
            { Sync_Sync(syncDirection); }));
        }
        public enum SyncDirection
        { O2H, H2O, BothWay, }
        public void Sync_Sync(SyncDirection syncDirection)
        {
            if (SyncStatus != SyncStatusEnum.Idle)
            {
                loggerAdv.Log(new LoggerAdv.ItemClass(
                    LoggerAdv.ItemClass.Levels.Warning, null,
                    "New sync canceled, only run when idle."));
                return;
            }

            SyncStatus = SyncStatusEnum.Scanning;

            loggerAdv.Log("Start syncin, check dirs...");
            string outHIntegritnessMsg;
            if (!fileOperator.CheckHIntegritness(out outHIntegritnessMsg))
            {
                loggerAdv.Log(
                    new LoggerAdv.ItemClass(
                        LoggerAdv.ItemClass.Levels.Warning, null,
                        $"Hideout integritness imcomplete: [{outHIntegritnessMsg}]"));
            }
            if (!CheckSyncDir())
            {
                SyncStatus = SyncStatusEnum.Idle;
                return;
            }

            // init dirs
            if (!fileOperator.IsHideoutSet)
            {
                fileOperator.SetHideout(
                    fileOperator.HODir,
                    settings.HO_PasswordMesh,
                    false);
            }
            if (!fileOperator.IsOpenDirSet)
            {
                fileOperator.SetOpenDir(
                    fileOperator.ODDir);
            }


            int counterDifference = 0, counterExcludings = 0,
                counterO2H = 0, counterH2O = 0, counterDelete = 0,
                counterError = 0;

            #region load all lists
            loggerAdv.Log("Loading file lists...");
            fileOperator.LoadAllHOIndexes();

            Dictionary<string, HFileSystemInfo> hoDict = new Dictionary<string, HFileSystemInfo>();
            HashSet<string> neDirs;
            foreach (HFileSystemInfo hi in fileOperator.GetHFileSystemItems(null, true, false, out neDirs))
            {
                if (!hi.isDeleted)
                    hoDict.Add(hi.fullName, hi);
            }

            List<FileSystemInfo> ofList = fileOperator.LoadAllODItems();
            Dictionary<string, FileSystemInfo> odDict = new Dictionary<string, FileSystemInfo>();
            int ofDirPathLength = (fileOperator.ODDir + Path.DirectorySeparatorChar).Length;
            foreach (FileSystemInfo fsi in ofList)
                odDict.Add(fsi.FullName.Substring(ofDirPathLength), fsi);

            #endregion

            #region remove non-changed items, and "deleted" items

            loggerAdv.Log("Comparing file times...");
            FileSystemInfo odFSI;
            HFileSystemInfo hoFSI;
            string[] allHoDictKeys = hoDict.Keys.ToArray();
            foreach (string hk in allHoDictKeys)
            {
                hoFSI = hoDict[hk];
                if (hoFSI.isDeleted)
                {
                    hoDict.Remove(hk);
                    continue;
                }
                if (odDict.ContainsKey(hk))
                {
                    odFSI = odDict[hk];
                    if (hoFSI.modifyTime == odFSI.LastWriteTime)
                    {
                        hoDict.Remove(hk);
                        odDict.Remove(hk);
                    }
                    else if (hoFSI.isDirectory && odFSI.Attributes.HasFlag(FileAttributes.Directory)
                        && hoFSI.attributes == odFSI.Attributes)
                    {
                        hoDict.Remove(hk);
                        odDict.Remove(hk);
                    }
                }
            }
            #endregion

            #region remove excludings
            bool excluded;

            foreach (ExcludingItem ei in excludingList)
            {
                excluded = false;
                foreach (string ok in odDict.Keys.ToArray())
                {
                    if (ei.CheckMatch(ok))
                    {
                        if (syncDirection == SyncDirection.O2H
                            || syncDirection == SyncDirection.BothWay)
                            counterExcludings++;
                        odDict.Remove(ok);
                        excluded = true;
                    }
                }
                if (excluded)
                {
                    loggerAdv.Log(new LoggerAdv.ItemClass(
                        LoggerAdv.ItemClass.Levels.Warning, null,
                        $"Found and excluded [{ei.text}] from open-list."));
                }
                excluded = false;
                foreach (string hk in hoDict.Keys.ToArray())
                {
                    if (ei.CheckMatch(hk))
                    {
                        if (syncDirection == SyncDirection.H2O
                            || syncDirection == SyncDirection.BothWay)
                            counterExcludings++;
                        odDict.Remove(hk);
                        excluded = true;
                    }
                }
                if (excluded)
                {
                    loggerAdv.Log(new LoggerAdv.ItemClass(
                        LoggerAdv.ItemClass.Levels.Warning, null,
                        $"Found and excluded [{ei.text}] from hiden-list."));
                }
            }


            #endregion


            SyncStatus = SyncStatusEnum.Syncing;
            SyncStartStop?.Invoke(this, true);
            loggerAdv.Log("Transfering file data...");
            // start sync

            // list task list, send to operator....
            switch (syncDirection)
            {
                case SyncDirection.O2H:
                    {
                        foreach (string ok in odDict.Keys.ToArray())
                        {
                            try
                            {
                                if (hoDict.ContainsKey(ok))
                                    hoDict.Remove(ok);
                                SyncProgressing?.Invoke(this, ok, false);
                                fileOperator.TransferO2H(ok);
                                counterO2H++;
                                counterDifference++;
                            }
                            catch (Exception err)
                            {
                                loggerAdv.Log(err);
                                counterError++;
                            }
                        }
                        foreach (string hk in hoDict.Keys.ToArray())
                        {
                            try
                            {
                                SyncDeleting?.Invoke(this, hk, true);
                                fileOperator.DeleteH(hk);
                                counterDifference++;
                                counterDelete++;
                                loggerAdv.Log($"Delete HidenOut item [{hk}]");
                            }
                            catch (Exception err)
                            {
                                loggerAdv.Log(err);
                                counterError++;
                            }
                        }
                        break;
                    }
                case SyncDirection.H2O:
                    {
                        foreach (string hk in hoDict.Keys.ToArray())
                        {
                            try
                            {
                                if (odDict.ContainsKey(hk))
                                    odDict.Remove(hk);
                                SyncProgressing?.Invoke(this, hk, true);
                                fileOperator.TransferH2O(hk);
                                counterH2O++;
                                counterDifference++;
                            }
                            catch (Exception err)
                            {
                                loggerAdv.Log(err);
                                counterError++;
                            }
                        }
                        foreach (string ok in odDict.Keys.ToArray())
                        {
                            try
                            {
                                SyncDeleting?.Invoke(this, ok, false);
                                fileOperator.DeleteO(ok);
                                counterDifference++;
                                counterDelete++;
                                loggerAdv.Log($"Delete OpenFolder item [{ok}]");
                            }
                            catch (Exception err)
                            {
                                loggerAdv.Log(err);
                                counterError++;
                            }
                        }
                        break;
                    }
                case SyncDirection.BothWay:
                    {
                        foreach (string hk in hoDict.Keys.ToArray())
                        {
                            hoFSI = hoDict[hk];
                            try
                            {
                                if (odDict.ContainsKey(hk))
                                {
                                    odFSI = odDict[hk];
                                    odDict.Remove(hk);
                                    if (hoFSI.modifyTime > odFSI.LastWriteTime)
                                    {
                                        SyncProgressing?.Invoke(this, hk, true);
                                        fileOperator.TransferH2O(hk);
                                        counterH2O++;
                                    }
                                    else
                                    {
                                        SyncProgressing?.Invoke(this, hk, false);
                                        fileOperator.TransferO2H(hk);
                                        counterO2H++;
                                    }
                                }
                                else
                                {
                                    SyncProgressing?.Invoke(this, hk, true);
                                    fileOperator.TransferH2O(hk);
                                }
                                counterDifference++;
                            }
                            catch (Exception err)
                            {
                                loggerAdv.Log(err);
                                counterError++;
                            }
                        }
                        foreach (string ok in odDict.Keys.ToArray())
                        {
                            try
                            {
                                SyncProgressing?.Invoke(this, ok, false);
                                fileOperator.TransferO2H(ok);
                                counterDifference++;
                                // no need to remove dict kvs;
                            }
                            catch (Exception err)
                            {
                                loggerAdv.Log(err);
                                counterError++;
                            }
                        }
                        break;
                    }
            }

            try
            {
                fileOperator.CommitHIndexes();
            }
            catch (Exception err)
            {
                SyncError?.Invoke(this, new Exception("Writing indexes failed.", err));

            }

            StringBuilder report = new StringBuilder();
            SyncStatus = SyncStatusEnum.Idle;
            SyncStartStop?.Invoke(this, false);
            switch (syncDirection)
            {
                case SyncDirection.O2H:
                    report.Append("Sync O->H complete:"); break;
                case SyncDirection.H2O:
                    report.Append("Sync H->O complete:"); break;
                case SyncDirection.BothWay:
                    report.Append("Sync BothWay complete:"); break;
            }
            report.Append(Environment.NewLine);
            report.Append($"Excluding [{counterExcludings}]." + Environment.NewLine);
            report.Append($"Differences handled [{counterDifference}]." + Environment.NewLine);
            report.Append($"O->H [{counterO2H}], H->O [{counterH2O}]." + Environment.NewLine);
            report.Append($"Deleted [{counterDelete}], Errors [{counterError}].");
            loggerAdv.Log(report.ToString());
        }


        public class ExcludingItem
        {
            public ExcludingItem()
            { }
            public ExcludingItem(string ioContent)
            { this.IOContent = ioContent; }

            public string text;
            public bool isRootOnly;
            public string IOContent
            {
                get
                {
                    return text + "/" + (isRootOnly ? "1" : "0");
                }
                set
                {
                    int sIdx = value.IndexOf("/");
                    text = value.Substring(0, sIdx);
                    isRootOnly = value.Substring(sIdx + 1) == "1";
                }
            }
            public bool CheckMatch(string inputPath)
            {
                if (inputPath == null)
                    return false;
                string[] parts = inputPath.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);

                if (isRootOnly)
                    return CheckSingleMatch(text, parts[0]);

                foreach (string p in parts)
                {
                    if (CheckSingleMatch(text, p))
                        return true;
                }
                return false;
            }
            private static bool CheckSingleMatch(string text, string input)
            {
                if (text == null)
                    return false;
                while (text.Contains("*?"))
                    text = text.Replace("*?", "?*");
                while (text.Contains("**"))
                    text = text.Replace("**", "*");
                int cIndex = 0, vIndex = 0;
                int preCS = 2; // 0-*  1-?  2-other
                foreach (char t in text)
                {
                    if (t == '*')
                        preCS = 0;
                    else if (t == '?')
                    {
                        cIndex++;
                        vIndex++;
                        preCS = 1;
                    }
                    else
                    {
                        vIndex = input.IndexOf(t, cIndex);
                        if (vIndex < 0)
                            return false;

                        switch (preCS)
                        {
                            case 0:
                                cIndex = vIndex + 1;
                                break;
                            default:
                            case 1:
                            case 2:
                                if (cIndex != vIndex)
                                    return false;
                                cIndex++;
                                break;
                        }
                        preCS = 2;
                    }
                }
                if (preCS == 0)
                    return true;
                else if (vIndex + 1 < input.Length)
                    return false;
                else
                    return true;
            }
        }
        public List<ExcludingItem> excludingList = new List<ExcludingItem>();


        public void Dispose()
        {
        }



        internal bool CheckExcluding(string pathInBase)
        {
            foreach (ExcludingItem ei in excludingList)
            {
                if (ei.CheckMatch(pathInBase))
                    return false;
            }
            return true;
        }
    }
}
