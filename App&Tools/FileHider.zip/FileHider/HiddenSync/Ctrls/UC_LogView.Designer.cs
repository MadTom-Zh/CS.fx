﻿namespace MadTomDev.App.Ctrls
{
    partial class UC_LogView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.Scu = new System.Windows.Forms.DataGridViewImageColumn();
            this.Message = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Details = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_viewLogFiles = new System.Windows.Forms.Button();
            this.checkBox_info = new System.Windows.Forms.CheckBox();
            this.checkBox_warning = new System.Windows.Forms.CheckBox();
            this.checkBox_error = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList.ImageSize = new System.Drawing.Size(24, 24);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AllowUserToOrderColumns = true;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Scu,
            this.Message,
            this.Details});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.Location = new System.Drawing.Point(0, 31);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.ShowCellErrors = false;
            this.dataGridView.ShowCellToolTips = false;
            this.dataGridView.ShowEditingIcon = false;
            this.dataGridView.ShowRowErrors = false;
            this.dataGridView.Size = new System.Drawing.Size(472, 434);
            this.dataGridView.TabIndex = 11;
            this.dataGridView.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dataGridView_RowsAdded);
            // 
            // Scu
            // 
            this.Scu.FillWeight = 40F;
            this.Scu.Frozen = true;
            this.Scu.HeaderText = "Scu";
            this.Scu.Name = "Scu";
            this.Scu.ReadOnly = true;
            this.Scu.Width = 40;
            // 
            // Message
            // 
            this.Message.FillWeight = 200F;
            this.Message.HeaderText = "Message";
            this.Message.Name = "Message";
            this.Message.ReadOnly = true;
            this.Message.Width = 300;
            // 
            // Details
            // 
            this.Details.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Details.HeaderText = "Details";
            this.Details.Name = "Details";
            this.Details.ReadOnly = true;
            // 
            // button_clear
            // 
            this.button_clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_clear.Location = new System.Drawing.Point(419, -1);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(54, 32);
            this.button_clear.TabIndex = 10;
            this.button_clear.Text = "Clear";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_viewLogFiles
            // 
            this.button_viewLogFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_viewLogFiles.Location = new System.Drawing.Point(324, -1);
            this.button_viewLogFiles.Name = "button_viewLogFiles";
            this.button_viewLogFiles.Size = new System.Drawing.Size(95, 32);
            this.button_viewLogFiles.TabIndex = 9;
            this.button_viewLogFiles.Text = "View Log FIles";
            this.button_viewLogFiles.UseVisualStyleBackColor = true;
            this.button_viewLogFiles.Click += new System.EventHandler(this.button_viewLogFiles_Click);
            // 
            // checkBox_info
            // 
            this.checkBox_info.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_info.Checked = true;
            this.checkBox_info.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_info.ImageList = this.imageList;
            this.checkBox_info.Location = new System.Drawing.Point(189, -1);
            this.checkBox_info.Name = "checkBox_info";
            this.checkBox_info.Size = new System.Drawing.Size(95, 32);
            this.checkBox_info.TabIndex = 8;
            this.checkBox_info.Text = "Info (#)";
            this.checkBox_info.UseVisualStyleBackColor = true;
            this.checkBox_info.CheckedChanged += new System.EventHandler(this.checkBox_info_CheckedChanged);
            // 
            // checkBox_warning
            // 
            this.checkBox_warning.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_warning.Checked = true;
            this.checkBox_warning.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_warning.ImageList = this.imageList;
            this.checkBox_warning.Location = new System.Drawing.Point(94, -1);
            this.checkBox_warning.Name = "checkBox_warning";
            this.checkBox_warning.Size = new System.Drawing.Size(95, 32);
            this.checkBox_warning.TabIndex = 7;
            this.checkBox_warning.Text = "Warning (#)";
            this.checkBox_warning.UseVisualStyleBackColor = true;
            this.checkBox_warning.CheckedChanged += new System.EventHandler(this.checkBox_warning_CheckedChanged);
            // 
            // checkBox_error
            // 
            this.checkBox_error.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_error.Checked = true;
            this.checkBox_error.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_error.ImageList = this.imageList;
            this.checkBox_error.Location = new System.Drawing.Point(-1, -1);
            this.checkBox_error.Name = "checkBox_error";
            this.checkBox_error.Size = new System.Drawing.Size(95, 32);
            this.checkBox_error.TabIndex = 6;
            this.checkBox_error.Text = "Error (#)";
            this.checkBox_error.UseVisualStyleBackColor = true;
            this.checkBox_error.CheckedChanged += new System.EventHandler(this.checkBox_error_CheckedChanged);
            // 
            // UC_LogView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_viewLogFiles);
            this.Controls.Add(this.checkBox_info);
            this.Controls.Add(this.checkBox_warning);
            this.Controls.Add(this.checkBox_error);
            this.Name = "UC_LogView";
            this.Size = new System.Drawing.Size(472, 465);
            this.Load += new System.EventHandler(this.UC_LogView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewImageColumn Scu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Message;
        private System.Windows.Forms.DataGridViewTextBoxColumn Details;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_viewLogFiles;
        private System.Windows.Forms.CheckBox checkBox_info;
        private System.Windows.Forms.CheckBox checkBox_warning;
        private System.Windows.Forms.CheckBox checkBox_error;
    }
}
