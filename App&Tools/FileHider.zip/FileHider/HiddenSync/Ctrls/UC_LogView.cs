﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using MadTomDev.App.Classes;

namespace MadTomDev.App.Ctrls
{
    public partial class UC_LogView : UserControl
    {
        public UC_LogView()
        {
            InitializeComponent();
        }

        private const string ImgKey_Error = "Error";
        private const string ImgKey_Warning = "Warning";
        private const string ImgKey_Information = "Information";

        private string CBtnText_Error = "Error ({0})";
        private string CBtnText_Warning = "Warning ({0})";
        private string CBtnText_Information = "Info ({0})";
        private Timer delayTimer;
        private int delayTimer_coolDown = -1;

        private void LoadImages()
        {
            imageList.Images.Add(ImgKey_Error, SystemIcons.Error);
            imageList.Images.Add(ImgKey_Warning, SystemIcons.Warning);
            imageList.Images.Add(ImgKey_Information, SystemIcons.Information);
        }
        private void UC_LogView_Load(object sender, EventArgs e)
        {
            LoadImages();
            delayTimer = new Timer();
            delayTimer.Interval = 200;
            delayTimer.Tick += DelayTimer_Tick;
        }
        private void DelayTimer_DelayStart(int cd = 2)
        {
            delayTimer.Stop();
            delayTimer_coolDown = cd;
            delayTimer.Start();
        }


        private LoggerAdv _loggerAdv = null;
        /// <summary>
        /// automaticaly load logger new data, and clear if logger raise clear event
        /// </summary>
        /// <param name="logger"></param>
        internal void Init(LoggerAdv logger)
        {
            if (_loggerAdv != null)
            {
                RemoveLoggerHandler();
            }

            if (logger != null)
            {
                _loggerAdv = logger;
                AddLoggerHandler();
            }
            Refresh_CheckBtnTexts();
        }
        private void AddLoggerHandler()
        {
            _loggerAdv.NewLog += _loggerAdv_NewLog;
            _loggerAdv.LogCleared += _loggerAdv_LogCleared;
        }
        private void RemoveLoggerHandler()
        {
            _loggerAdv.NewLog -= _loggerAdv_NewLog;
            _loggerAdv.LogCleared -= _loggerAdv_LogCleared;
        }
        private void _loggerAdv_NewLog(object sender, LoggerAdv.NewLogArgs e)
        {
            AddLogDataToDataGridView(e.newLog);
        }
        private void _loggerAdv_LogCleared(object sender, EventArgs e)
        {
            dataGridView.Rows.Clear();
        }

        private delegate void AddLogDataToDataGridView_CallBack(LoggerAdv.ItemClass logData);
        private void AddLogDataToDataGridView(LoggerAdv.ItemClass logData)
        {
            if (this.InvokeRequired)
            {
                Delegate callBack = new AddLogDataToDataGridView_CallBack(AddLogDataToDataGridView);
                this.Invoke(callBack, logData);
            }
            else
            {
                bool rowVisible;
                string imgKey = null;
                switch (logData.Level)
                {
                    case LoggerAdv.ItemClass.Levels.Error:
                        imgKey = ImgKey_Error;
                        rowVisible = checkBox_error.Checked;
                        break;
                    case LoggerAdv.ItemClass.Levels.Warning:
                        imgKey = ImgKey_Warning;
                        rowVisible = checkBox_warning.Checked;
                        break;
                    case LoggerAdv.ItemClass.Levels.Info:
                    default:
                        imgKey = ImgKey_Information;
                        rowVisible = checkBox_info.Checked;
                        break;
                }
                int nrIdx = dataGridView.Rows.Add(
                    imageList.Images[imgKey],
                    logData.OccurTime.ToString("yyyy-MM-dd HH:mm:ss") + " " + logData.Message,
                    logData.Details);
                dataGridView.Rows[nrIdx].Tag = logData;
                dataGridView.Rows[nrIdx].Visible = rowVisible;


                int rCount = dataGridView.Rows.Count;
                if (rCount > 100)
                {
                    for (int i = rCount - 11; i >= 0; i--)
                        dataGridView.Rows.RemoveAt(i);
                }

                dataGridView.FirstDisplayedScrollingRowIndex = dataGridView.RowCount - 1;
                DelayTimer_DelayStart();
            }
        }
        private void Refresh_CheckBtnTexts()
        {
            LoggerAdv.ItemClass logItem;
            int countInfo = 0, countWarning = 0, countErr = 0;
            foreach (DataGridViewRow dgvRow in dataGridView.Rows)
            {
                logItem = (LoggerAdv.ItemClass)dgvRow.Tag;
                switch (logItem.Level)
                {
                    case LoggerAdv.ItemClass.Levels.Info:
                        countInfo++; break;
                    case LoggerAdv.ItemClass.Levels.Warning:
                        countWarning++; break;
                    case LoggerAdv.ItemClass.Levels.Error:
                        countErr++; break;
                }
            }

            checkBox_info.Text = string.Format(CBtnText_Information, countInfo);
            checkBox_warning.Text = string.Format(CBtnText_Warning, countWarning);
            checkBox_error.Text = string.Format(CBtnText_Error, countErr);
        }
        private void DelayTimer_Tick(object sender, EventArgs e)
        {
            if (--delayTimer_coolDown <= 0)
            {
                Refresh_CheckBtnTexts();
                delayTimer.Stop();
            }
        }

        /// <summary>
        /// used for display logs given;
        /// nothing todo with any logger or something, just display given data
        /// </summary>
        internal void SetLogData(IEnumerable<LoggerAdv.ItemClass> logItemList)
        {
            foreach (LoggerAdv.ItemClass logData in logItemList)
            {
                AddLogDataToDataGridView(logData);
            }
        }


        private void checkBox_error_CheckedChanged(object sender, EventArgs e)
        {
            ShowHideLogItems(LoggerAdv.ItemClass.Levels.Error, checkBox_error.Checked);
        }
        private void checkBox_warning_CheckedChanged(object sender, EventArgs e)
        {
            ShowHideLogItems(LoggerAdv.ItemClass.Levels.Warning, checkBox_warning.Checked);
        }
        private void checkBox_info_CheckedChanged(object sender, EventArgs e)
        {
            ShowHideLogItems(LoggerAdv.ItemClass.Levels.Info, checkBox_info.Checked);
        }
        private void ShowHideLogItems(LoggerAdv.ItemClass.Levels level, bool isShown)
        {
            LoggerAdv.ItemClass tagData;
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Tag is LoggerAdv.ItemClass)
                {
                    tagData = (LoggerAdv.ItemClass)row.Tag;
                    if (tagData.Level == level)
                    {
                        row.Visible = isShown;
                    }
                }
            }
        }

        private void button_viewLogFiles_Click(object sender, EventArgs e)
        {
            ViewLogDir();
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            if (_loggerAdv != null) _loggerAdv.Log("Clearing log list...");
            dataGridView.Rows.Clear();
            if (_loggerAdv != null) _loggerAdv.Clear();
        }
        public void Clear()
        {
            button_clear_Click(null, null);
        }

        public bool IsButtonClearEnabled
        {
            get { return button_clear.Enabled; }
            set
            {
                button_clear.Enabled = value;
            }
        }

        public void ViewLogDir()
        {
            Process.Start(_loggerAdv.BaseDir);
            _loggerAdv.Log("Log dir opened.");
        }

        private void dataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
        }
    }
}
