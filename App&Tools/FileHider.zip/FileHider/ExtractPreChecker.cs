﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MadTomDev.App
{
    class ExtractPreChecker
    {
        public static bool CheckHaveAnyExistence(string targetDir, string[] pathesInBase)
        {
            HashSet<string> existNamesLower = new HashSet<string>();
            foreach (FileSystemInfo fi in new DirectoryInfo(targetDir).GetFileSystemInfos())
                existNamesLower.Add(fi.Name.ToLower());

            foreach (string s in pathesInBase)
                if (existNamesLower.Contains(FileHiderCore.GetName(s.ToLower())))
                    return true;

            return false;
        }

        public static void ReNameExistences(string targetDir,
            ref List<FileHiderCore.RenameStruct> extractItemsToRename)
        {
            HashSet<string> existNamesLower = new HashSet<string>();
            foreach (FileSystemInfo fi in new DirectoryInfo(targetDir).GetFileSystemInfos())
                existNamesLower.Add(fi.Name.ToLower());

            string oriName, curName;
            int addNo, dotIndex;
            FileHiderCore.RenameStruct ei;
            for (int i = extractItemsToRename.Count - 1; i >= 0; i--)
            {
                ei = extractItemsToRename[i];
                oriName = FileHiderCore.GetName(ei.GetNewFullName());
                addNo = 1;
                while (true)
                {
                    curName = FileHiderCore.GetName(ei.GetNewFullName());
                    if (existNamesLower.Contains(curName.ToLower()))
                    {
                        if (oriName.Contains("."))
                        {
                            dotIndex = oriName.LastIndexOf(".");
                            ei.newName = oriName.Substring(0, dotIndex)
                                + " (" + (addNo++).ToString() + ")"
                                + oriName.Substring(dotIndex);
                        }
                        else
                        {
                            ei.newName = oriName + " (" + (addNo++).ToString() + ")";
                        }
                        extractItemsToRename[i] = ei;
                    }
                    else
                    {
                        existNamesLower.Add(curName.ToLower());
                        break;
                    }
                }
            }
        }
    }
}
