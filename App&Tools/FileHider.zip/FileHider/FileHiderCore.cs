﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

using MadTomDev.Data;

namespace MadTomDev.App
{
    public class FileHiderCore : IDisposable
    {
        public const string DBFile_Name = "index";
        private string _DBFile;
        private string _HideoutDir;
        public string HideoutDir { get { return _HideoutDir; } }
        public string Password { private set; get; } = null;
        public FileHiderCore(string hidenDir, string password)
        {
            if (!Directory.Exists(hidenDir))
                Directory.CreateDirectory(hidenDir);
            _DBFile = hidenDir + "\\" + DBFile_Name;
            if (new DirectoryInfo(hidenDir).GetFileSystemInfos().Any() 
                && !File.Exists(_DBFile))
            {
                DirectoryInfo hdi = new DirectoryInfo(hidenDir);
                if (hdi.GetFileSystemInfos().Length > 0)
                    throw new Exception("Can't init HideOut when dir[" + hidenDir + "] is not empty.");
            }
            try
            {
                InitDB(password);
            }
            catch (Exception err)
            {
                throw new Exception("Wrong password.", err);
            }
            _HideoutDir = hidenDir;
            this.Password = password;
        }
        private SQLiteHelper db = null;
        private void InitDB(string password = null)
        {
            if (string.IsNullOrWhiteSpace(password))
                db = new SQLiteHelper(_DBFile, false, "To read the HO index, use " + Password);
            else
                db = new SQLiteHelper(_DBFile, false, "To read the HO index, use " + password);
            if (_DBNotReady) _TryInitDBTable();
        }
        private bool _DBNotReady = true;
        private const string _DBTableName = "Comparisons";
        private const string _DBColumnName_PathInBase = "PathInBase";
        private const string _DBColumnName_IsDir = "IsDir";
        private const string _DBColumnName_Length = "Length";
        private const string _DBColumnName_Pkg = "Pkg";
        private const string _DBColumnName_Itm = "Itm";
        private const string _DBColumnName_LastWriteTime = "LastWriteTime";
        public const byte EncrytConfusionLength = 5;

        private const string _DBTableName_ActionHistory = "ActionHistory";
        private const string _DBColumnName_Act_Time = "Time";
        private const string _DBColumnName_Act_Type = "Type";
        private const string _DBColumnName_Act_PathInBase = "PathInBase";
        private const string _DBColumnName_Act_NewName = "NewName";
        private const string _DBColumnName_Act_FileLength = "FileLength";
        public const byte NewNameHistoryExpirationDays = 15;
        private void _TryInitDBTable()
        {
            if (!db.HaveTable(_DBTableName))
            {
                using (SQLiteCommand cmd = db.GetNewCommand())
                {
                    StringBuilder cmdBdr = new StringBuilder();
                    cmdBdr.Append("CREATE TABLE [");
                    cmdBdr.Append(_DBTableName);
                    cmdBdr.Append("](");
                    cmdBdr.Append("[" + _DBColumnName_PathInBase + "] TEXT PRIMARY KEY NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_IsDir + "] BOOL NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_Length + "] INT64 NOT NULL DEFAULT 0,");
                    cmdBdr.Append("[" + _DBColumnName_Pkg + "] INT NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_Itm + "] INT NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_LastWriteTime + "] INT64 NOT NULL DEFAULT 0");
                    cmdBdr.Append(") WITHOUT ROWID;");
                    cmd.CommandText = cmdBdr.ToString();
                    cmd.ExecuteNonQuery();
                }
            }
            if (!db.HaveTable(_DBTableName_ActionHistory))
            {
                using (SQLiteCommand cmd = db.GetNewCommand())
                {
                    StringBuilder cmdBdr = new StringBuilder();
                    cmdBdr.Append("CREATE TABLE [");
                    cmdBdr.Append(_DBTableName_ActionHistory);
                    cmdBdr.Append("](");
                    cmdBdr.Append("[" + _DBColumnName_Act_Time + "] INT64 PRIMARY KEY NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_Act_Type + "] INT NOT NULL DEFAULT 0,");
                    cmdBdr.Append("[" + _DBColumnName_Act_PathInBase + "] TEXT NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_Act_NewName + "] TEXT NOT NULL,");
                    cmdBdr.Append("[" + _DBColumnName_Act_FileLength + "] INT64 NOT NULL DEFAULT 0");
                    cmdBdr.Append(") WITHOUT ROWID;");
                    cmd.CommandText = cmdBdr.ToString();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public delegate void ItemsAddedDelegate(FileHiderCore core, HidenItemInfo hiInfos);
        public delegate void ItemsRemovedDelegate(FileHiderCore core, string pathesInBase);
        public event ItemsAddedDelegate ItemAdded;
        public event ItemsRemovedDelegate ItemRemoved;

        public delegate void InputOutputStepsCountDelegate(int allSteps);
        public event InputOutputStepsCountDelegate InputStepsCounted, OutputSetpsCounted;
        public delegate void InputOutputPorgressDelegate(string progressingPath);
        public event InputOutputPorgressDelegate InputProgress, OutputProgress;
        public delegate void OutputProgressCompleteDelegate();
        public event OutputProgressCompleteDelegate OutputProgressComplete;

        public Task<Exception> Input_ASync(HidenItemInfo targetHidenDir, params RenameStruct[] filesNDirs)
        {
            return Task<Exception>.Run(() =>
                { return Input_Sync(targetHidenDir, filesNDirs); });
        }
        public Exception Input_Sync(HidenItemInfo targetHidenDir, params RenameStruct[] filesNDirs)
        {
            if (targetHidenDir == null)
                return Input_Sync("", filesNDirs);
            else
                return Input_Sync(targetHidenDir.pathInBase, filesNDirs);
        }

        public Task<Exception> Input_ASync(string dirPathInBase, params RenameStruct[] filesNDirs)
        {
            return Task<Exception>.Run(() =>
                { return Input_Sync(dirPathInBase, filesNDirs); });
        }
        public Exception Input_Sync(string dirPathInBase, params RenameStruct[] filesNDirs)
        {
            Exception result = null;
            if (filesNDirs == null || filesNDirs.Length == 0)
                return result;
            foreach (RenameStruct s in filesNDirs)
            {
                if (s.fullName.Contains(_HideoutDir))
                {
                    result = new Exception("Cant input hideout into itself.");
                    return result;
                }
            }

            // count
            InputStepsCounted?.Invoke(InputCountLoop(filesNDirs));

            HidenItemInfo added;
            using (SQLiteTransaction trans = db.GetNewTransaction())
            {
                try
                {
                    foreach (RenameStruct fOrD in filesNDirs)
                    {
                        added = null;
                        if (File.Exists(fOrD.fullName))
                        {
                            added = Input_file(db, dirPathInBase, fOrD.fullName, fOrD.newName);
                            InputProgress?.Invoke(added.pathInBase);
                        }
                        else
                        {
                            added = Input_dir(db, dirPathInBase, fOrD.fullName, fOrD.newName);
                            InputProgress?.Invoke(added.pathInBase);
                            if (string.IsNullOrWhiteSpace(dirPathInBase))
                                Input_loopDir(db, GetName(fOrD.GetNewFullName()), fOrD.fullName);
                            else
                                Input_loopDir(db, dirPathInBase + "\\" + GetName(fOrD.GetNewFullName()), fOrD.fullName);
                        }
                        ItemAdded?.Invoke(this, added);
                    }
                }
                catch (Exception err)
                {
                    result = err;
                }
                trans.Commit();
            }

            return result;
        }
        public struct RenameStruct
        {
            public string fullName;
            public string newName;
            public string GetNewFullName()
            {
                if (string.IsNullOrWhiteSpace(newName))
                    return fullName;
                else
                    return GetParentPath(fullName) + "\\" + newName;
            }
        }
        private int InputCountLoop(params RenameStruct[] filesNDirs)
        {
            int result = 0;
            foreach (RenameStruct i in filesNDirs)
            {
                result++;
                if (!File.Exists(i.fullName))
                    result += InputCountLoop(new DirectoryInfo(i.fullName));
            }
            return result;
        }
        private int InputCountLoop(DirectoryInfo dir)
        {
            int result = dir.GetFiles().Length;
            foreach (DirectoryInfo di in dir.GetDirectories())
                result += InputCountLoop(di) + 1;
            return result;
        }


        internal bool DB_HaveSubDirs(string dirInBase)
        {
            bool result = false;
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_IsDir);
                cmdBdr.Append("=true and ");
                cmdBdr.Append(_DBColumnName_PathInBase);
                if (string.IsNullOrWhiteSpace(dirInBase))
                    cmdBdr.Append(" not like '%\\%'");
                else
                    cmdBdr.Append(" like '" + dirInBase + "\\%'");
                cmdBdr.Append(" limit 1;");
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    result = reader.HasRows;
                }
            }
            return result;
        }


        private HidenItemInfo Input_file(SQLiteHelper db, string toDirInBase, string fileFullName, string newName = null)
        {
            HidenPosition hp;
            string pathInBase;
            FileInfo fileInfo = new FileInfo(fileFullName);
            StringBuilder cmdBdr = new StringBuilder();
            if (string.IsNullOrWhiteSpace(toDirInBase))
            {
                if (string.IsNullOrWhiteSpace(newName))
                    pathInBase = fileInfo.Name;
                else
                    pathInBase = newName;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(newName))
                    pathInBase = toDirInBase + "\\" + fileInfo.Name;
                else
                    pathInBase = toDirInBase + "\\" + newName;
            }
            hp = _DBGetItmPosition(db, pathInBase);
            if (hp.PkgIndex < 0)
                hp = _DBGetNewItmPosition(db);

            string hoPhyFullPath = GetHideOutPhycalPath(hp);
            if (File.Exists(hoPhyFullPath))
                File.Delete(hoPhyFullPath);
            else if (Directory.Exists(hoPhyFullPath))
                Directory.Delete(hoPhyFullPath);
            EncryptedGZip.EncryptGZipFile(fileFullName, Password,
                hoPhyFullPath, EncrytConfusionLength, true);

            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                cmdBdr.Append("replace into ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" (");
                cmdBdr.Append(_DBColumnName_PathInBase + ",");
                cmdBdr.Append(_DBColumnName_IsDir + ",");
                cmdBdr.Append(_DBColumnName_Length + ",");
                cmdBdr.Append(_DBColumnName_Pkg + ",");
                cmdBdr.Append(_DBColumnName_Itm + ",");
                cmdBdr.Append(_DBColumnName_LastWriteTime);
                cmdBdr.Append(") values (?,?,?,?,?,?);");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@PIB", pathInBase);
                cmd.Parameters.AddWithValue("@D", false);
                cmd.Parameters.AddWithValue("@L", fileInfo.Length);
                cmd.Parameters.AddWithValue("@P", hp.PkgIndex);
                cmd.Parameters.AddWithValue("@I", hp.ItmIndex);
                cmd.Parameters.AddWithValue("@LWT", fileInfo.LastWriteTime.Ticks);
                cmd.ExecuteNonQuery();
            }
            WriteActionHistory(db, DateTime.Now, ActionHistoryItem.Type.Added, pathInBase, "", fileInfo.Length);
            return new HidenItemInfo()
            { core = this, isDir = false, pathInBase = pathInBase, position = hp, };
        }
        private HidenItemInfo Input_dir(SQLiteHelper db, string toDirInBase, string dirFullName, string newName = null)
        {
            HidenPosition hp;
            string pathInBase, hDirPhyFullName;
            StringBuilder cmdBdr = new StringBuilder();
            if (string.IsNullOrWhiteSpace(toDirInBase))
            {
                if (string.IsNullOrWhiteSpace(newName))
                    pathInBase = GetName(dirFullName);
                else
                    pathInBase = newName;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(newName))
                    pathInBase = toDirInBase + "\\" + GetName(dirFullName);
                else
                    pathInBase = toDirInBase + "\\" + newName;
            }
            hp = _DBGetItmPosition(db, pathInBase);
            if (hp.PkgIndex < 0)
                hp = _DBGetNewItmPosition(db);
            hDirPhyFullName = GetHideOutPhycalPath(hp);
            if (File.Exists(hDirPhyFullName))
                File.Delete(hDirPhyFullName);
            else if (!Directory.Exists(hDirPhyFullName))
                Directory.CreateDirectory(hDirPhyFullName, Directory.GetAccessControl(dirFullName));

            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                cmdBdr.Append("replace into ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" (");
                cmdBdr.Append(_DBColumnName_PathInBase + ",");
                cmdBdr.Append(_DBColumnName_IsDir + ",");
                cmdBdr.Append(_DBColumnName_Pkg + ",");
                cmdBdr.Append(_DBColumnName_Itm);
                cmdBdr.Append(") values (?,?,?,?);");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@PIB", pathInBase);
                cmd.Parameters.AddWithValue("@D", true);
                cmd.Parameters.AddWithValue("@P", hp.PkgIndex);
                cmd.Parameters.AddWithValue("@I", hp.ItmIndex);
                cmd.ExecuteNonQuery();
            }
            WriteActionHistory(db, DateTime.Now, ActionHistoryItem.Type.Added, pathInBase);
            return new HidenItemInfo()
            { core = this, isDir = true, pathInBase = pathInBase, position = hp, };
        }
        public HidenItemInfo InputEmptyDir(string pathInBase)
        {
            HidenPosition hp = _DBGetItmPosition(db, pathInBase);
            if (hp.PkgIndex >= 0)
                throw new Exception("Can't create dir in FH, cause [" + pathInBase + "] is already exist.");

            hp = _DBGetNewItmPosition(db);
            Directory.CreateDirectory(GetHideOutPhycalPath(hp));
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("replace into ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" (");
                cmdBdr.Append(_DBColumnName_PathInBase + ",");
                cmdBdr.Append(_DBColumnName_IsDir + ",");
                cmdBdr.Append(_DBColumnName_Pkg + ",");
                cmdBdr.Append(_DBColumnName_Itm);
                cmdBdr.Append(") values (?,?,?,?);");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@PIB", pathInBase);
                cmd.Parameters.AddWithValue("@D", true);
                cmd.Parameters.AddWithValue("@P", hp.PkgIndex);
                cmd.Parameters.AddWithValue("@I", hp.ItmIndex);
                cmd.ExecuteNonQuery();
            }
            WriteActionHistory(db, DateTime.Now, ActionHistoryItem.Type.Added, pathInBase);
            return new HidenItemInfo()
            { core = this, isDir = true, pathInBase = pathInBase, position = hp, };
        }
        private void Input_loopDir(SQLiteHelper db, string toDirInBase, string dirFullName)
        {
            DirectoryInfo di = new DirectoryInfo(dirFullName);
            foreach (FileInfo fi in di.GetFiles())
            {
                Input_file(db, toDirInBase, fi.FullName);
                InputProgress?.Invoke(toDirInBase + "\\" + fi.Name);
            }
            foreach (DirectoryInfo dubDi in di.GetDirectories())
            {
                Input_dir(db, toDirInBase, dubDi.FullName);
                InputProgress?.Invoke(toDirInBase + "\\" + dubDi.Name);
                if (string.IsNullOrWhiteSpace(toDirInBase))
                    Input_loopDir(db, dubDi.Name, dubDi.FullName);
                else
                    Input_loopDir(db, toDirInBase + "\\" + dubDi.Name, dubDi.FullName);

            }
        }




        public static string GetName(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return path;
            if (path.Contains("\\"))
                return path.Substring(path.LastIndexOf("\\") + 1);
            else return path;
        }
        internal static string GetSuffixName(string pathOrName)
        {
            string name = GetName(pathOrName);
            if (name.Contains("."))
                return name.Substring(name.LastIndexOf(".") + 1);
            else return "";
        }
        public static string GetParentPath(string path)
        {
            if (path.Contains("\\"))
                return path.Substring(0, path.LastIndexOf("\\"));
            else
                return "";
        }
        private int _DBCountExistents(SQLiteHelper db, IEnumerable<string> pathesInBase)
        {
            int result = 0;
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select count(*) from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_PathInBase);
                cmdBdr.Append(" in (");
                foreach (string p in pathesInBase)
                {
                    cmd.Parameters.AddWithValue("?", p);
                    cmdBdr.Append("?,");
                }
                cmdBdr.Remove(cmdBdr.Length - 1, 1);
                cmdBdr.Append(");");
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    result = reader.GetInt32(0);
                }
            }
            return result;
        }
        public class HidenPosition
        {
            public int PkgIndex = -1;
            public int ItmIndex = -1;
        }
        private HidenPosition _DBGetItmPosition(SQLiteHelper db, string pathInBase)
        {
            HidenPosition result = new HidenPosition()
            { PkgIndex = -1, ItmIndex = -1, };
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select ");
                cmdBdr.Append(_DBColumnName_Pkg);
                cmdBdr.Append(",");
                cmdBdr.Append(_DBColumnName_Itm);
                cmdBdr.Append(" from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_PathInBase);
                cmdBdr.Append("=? limit 1;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@P", pathInBase);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        result.PkgIndex = reader.GetInt32(0);
                        result.ItmIndex = reader.GetInt32(1);
                    }
                }
            }
            return result;
        }
        private HidenItemInfo _DBGetItm(SQLiteHelper db, string pathInBase)
        {
            HidenItemInfo result = null;
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_PathInBase);
                cmdBdr.Append("=? limit 1;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@P", pathInBase);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        result = new HidenItemInfo()
                        {
                            core = this,
                            pathInBase = reader.GetString(0),
                            isDir = reader.GetBoolean(1),
                            fileLength = reader.GetInt64(2),
                            position = new HidenPosition()
                            { PkgIndex = reader.GetInt32(3), ItmIndex = reader.GetInt32(4) },
                            lastWriteTime = new DateTime(reader.GetInt64(5)),
                        };
                    }
                }
            }
            return result;
        }

        private const int _DB_MaxItms_PerPkg = 500;
        private HidenPosition _DBGetNewItmPosition(SQLiteHelper db)
        {
            HidenPosition result = new HidenPosition()
            { PkgIndex = 0, ItmIndex = 0, };
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                result.PkgIndex = _DBGetMaxPkgIdx(cmd);

                int itmsCount;
                while (true)
                {
                    itmsCount = _DBGetItmsCount_inPkg(cmd, result.PkgIndex);

                    if (itmsCount == 0)
                    {
                        result.ItmIndex = 0;
                        break;
                    }
                    else if (itmsCount >= _DB_MaxItms_PerPkg)
                    {
                        result.PkgIndex++;
                    }
                    else
                    {
                        result.ItmIndex = _DBGetMaxItmIdx(cmd, result.PkgIndex) + 1;
                        break;
                    }
                }
            }
            return result;
        }


        private int _DBGetMaxPkgIdx(SQLiteCommand cmd)
        {
            int result = 0;

            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("select max(");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append(") from ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(";");
            cmd.CommandText = cmdBdr.ToString();
            using (SQLiteDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read() && !reader.IsDBNull(0))
                    result = reader.GetInt32(0);
            }
            return result;
        }
        private int _DBGetMaxItmIdx(SQLiteCommand cmd, int pkgIdx)
        {
            int result = 0;

            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("select max(");
            cmdBdr.Append(_DBColumnName_Itm);
            cmdBdr.Append(") from ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(" where ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append("=?;");
            cmd.CommandText = cmdBdr.ToString();
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PI", pkgIdx);
            using (SQLiteDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                    result = reader.GetInt32(0);
            }
            return result;
        }
        private int _DBGetItmsCount_inPkg(SQLiteCommand cmd, int pkgIdx)
        {
            int result = 0;

            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("select count(*) from ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(" where ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append("=?;");
            cmd.CommandText = cmdBdr.ToString();
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PI", pkgIdx);
            using (SQLiteDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                    result = reader.GetInt32(0);
            }
            return result;
        }
        private int _DBGetItmsCount_inBase(SQLiteCommand cmd, string pathInBase)
        {
            int result = 0;

            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("select count(*) from ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(" where ");
            cmdBdr.Append(_DBColumnName_PathInBase);
            cmdBdr.Append("=? and ");
            cmdBdr.Append(_DBColumnName_PathInBase);
            cmdBdr.Append(" like '");
            cmdBdr.Append(pathInBase + "\\%");
            cmdBdr.Append("';");
            cmd.CommandText = cmdBdr.ToString();
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PI", pathInBase);
            using (SQLiteDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                    result = reader.GetInt32(0);
            }
            return result;
        }
        private static List<HidenItemInfo> _DBGetItms(FileHiderCore core, SQLiteCommand cmd, int pkgIdx)
        {
            List<HidenItemInfo> result = new List<HidenItemInfo>();
            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("select * from ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(" where ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append("=? order by ");
            cmdBdr.Append(_DBColumnName_Itm);
            cmdBdr.Append(" ASC;");
            cmd.CommandText = cmdBdr.ToString();
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@P", pkgIdx);
            using (SQLiteDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    result.Add(new HidenItemInfo()
                    {
                        core = core,
                        pathInBase = reader.GetString(0),
                        isDir = reader.GetBoolean(1),
                        fileLength = reader.GetInt64(2),
                        position = new HidenPosition()
                        { PkgIndex = reader.GetInt32(3), ItmIndex = reader.GetInt32(4), },
                        lastWriteTime = reader.GetDateTime(5),
                    });
                }
            }
            return result;
        }
        private static List<HidenPosition> _DBGetPkgPositions(SQLiteCommand cmd, int pkgIdx)
        {
            List<HidenPosition> result = new List<HidenPosition>();
            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("select ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append(",");
            cmdBdr.Append(_DBColumnName_Itm);
            cmdBdr.Append(" from ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(" where ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append("=? order by ");
            cmdBdr.Append(_DBColumnName_Itm);
            cmdBdr.Append(" ASC;");
            cmd.CommandText = cmdBdr.ToString();
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@P", pkgIdx);
            using (SQLiteDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    result.Add(new HidenPosition()
                    { PkgIndex = reader.GetInt32(0), ItmIndex = reader.GetInt32(1), });
                }
            }
            return result;
        }
        private void _DBUpdatePosition(SQLiteCommand cmd, HidenPosition sourceHP, HidenPosition newHP)
        {
            List<HidenItemInfo> result = new List<HidenItemInfo>();
            StringBuilder cmdBdr = new StringBuilder();
            cmdBdr.Append("update ");
            cmdBdr.Append(_DBTableName);
            cmdBdr.Append(" set ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append("=?, ");
            cmdBdr.Append(_DBColumnName_Itm);
            cmdBdr.Append("=? where ");
            cmdBdr.Append(_DBColumnName_Pkg);
            cmdBdr.Append("=? and ");
            cmdBdr.Append(_DBColumnName_Itm);
            cmdBdr.Append("=?;");
            cmd.CommandText = cmdBdr.ToString();
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NP", newHP.PkgIndex);
            cmd.Parameters.AddWithValue("@NI", newHP.ItmIndex);
            cmd.Parameters.AddWithValue("@OP", sourceHP.PkgIndex);
            cmd.Parameters.AddWithValue("@OI", sourceHP.ItmIndex);
            cmd.ExecuteNonQuery();
        }
        public string GetHideOutPhycalPath(int pkgIdx)
        {
            return _HideoutDir + "\\pkg" + pkgIdx.ToString();
        }
        public static string GetHideOutPhycalPath(string hideoutDir, int pkgIdx)
        {
            return hideoutDir + "\\pkg" + pkgIdx.ToString();
        }
        public string GetHideOutPhycalPath(HidenPosition hp)
        {
            string pkgDir = GetHideOutPhycalPath(hp.PkgIndex);
            if (!Directory.Exists(pkgDir))
                Directory.CreateDirectory(pkgDir);
            return pkgDir + "\\" + hp.ItmIndex.ToString();
        }
        public static string GetHideOutPhycalPath(string hideoutDir, HidenPosition hp)
        {
            string pkgDir = GetHideOutPhycalPath(hideoutDir, hp.PkgIndex);
            if (!Directory.Exists(pkgDir))
                Directory.CreateDirectory(pkgDir);
            return pkgDir + "\\" + hp.ItmIndex.ToString();
        }
        public static FileInfo GetHideOutPhycalItemFileInfo(string hideoutDir, HidenPosition hp)
        {
            string file = GetHideOutPhycalPath(hideoutDir, hp);
            if (File.Exists(file))
                return new FileInfo(file);
            else
                return null;
        }

        public Exception Extract_Sync(string toRealDir, params string[] pathesInBase)
        {
            List<RenameStruct> pib = new List<RenameStruct>();
            foreach (string s in pathesInBase)
                pib.Add(new RenameStruct() { fullName = s, });
            return Extract_Sync(toRealDir, pib.ToArray());
        }
        public Exception Extract_Sync(string toRealDir, params RenameStruct[] pathesInBase)
        {
            Exception result = null;

            HidenPosition hp;
            string hoPhyFullName, realPhyFullName;
            try
            {
                if (OutputSetpsCounted != null)
                {
                    int allStepsCount = 0;
                    using (SQLiteCommand cmd = db.GetNewCommand())
                    {
                        foreach (RenameStruct pInB in pathesInBase)
                            allStepsCount += _DBGetItmsCount_inBase(cmd, pInB.fullName);
                    }
                    OutputSetpsCounted.Invoke(allStepsCount);
                }

                foreach (RenameStruct pInB in pathesInBase)
                {
                    hp = _DBGetItmPosition(db, pInB.fullName);
                    hoPhyFullName = GetHideOutPhycalPath(hp);
                    if (string.IsNullOrWhiteSpace(pInB.newName))
                        realPhyFullName = toRealDir + "\\" + GetName(pInB.fullName);
                    else
                        realPhyFullName = toRealDir + "\\" + pInB.newName;

                    if (File.Exists(realPhyFullName))
                        File.Delete(realPhyFullName);
                    if (Directory.Exists(realPhyFullName))
                        Directory.Delete(realPhyFullName, true);

                    OutputProgress?.Invoke(realPhyFullName);
                    if (File.Exists(hoPhyFullName))
                    {
                        EncryptedGZip.UnGZipDecryptFile(hoPhyFullName, Password,
                            realPhyFullName, EncrytConfusionLength, true);
                    }
                    else
                    {
                        if (!Directory.Exists(realPhyFullName))
                            Directory.CreateDirectory(realPhyFullName, Directory.GetAccessControl(hoPhyFullName));

                        List<HidenItemInfo> subPathesInBase = DB_GetSubItemsInfo(pInB.fullName);
                        _ExtractOrDelete_loop(db, realPhyFullName, false, pInB.fullName, subPathesInBase);
                    }
                }
            }
            catch (Exception err)
            { result = err; }

            OutputProgressComplete?.Invoke();
            return result;
        }
        private void _ExtractOrDelete_loop(SQLiteHelper db, string toCurRealDir, bool isDelete,
            string hideoutCurDirInBase, List<HidenItemInfo> pathesInBase)
        {
            List<HidenItemInfo> curSubInfosInBase = new List<HidenItemInfo>();
            if (string.IsNullOrWhiteSpace(hideoutCurDirInBase))
                hideoutCurDirInBase = "";
            else
                hideoutCurDirInBase = hideoutCurDirInBase + "\\";
            int hideoutCurDirInBaseLength = hideoutCurDirInBase.Length;
            string subPath, hoPhyFullName, realPhyFullName;
            foreach (HidenItemInfo p in pathesInBase)
            {
                if (p.pathInBase.StartsWith(hideoutCurDirInBase))
                {
                    subPath = p.pathInBase.Substring(hideoutCurDirInBaseLength);
                    hoPhyFullName = GetHideOutPhycalPath(p.position);
                    if (!subPath.Contains("\\"))
                    {
                        if (p.isDir)
                        {
                            if (isDelete)
                            {
                                _ExtractOrDelete_loop(db, null, true, p.pathInBase, DB_GetSubItemsInfo(p.pathInBase));

                                Directory.Delete(hoPhyFullName);
                                _DB_DeleteSingle(db, p.position);
                            }
                            else
                            {
                                realPhyFullName = toCurRealDir + "\\" + GetName(p.pathInBase);
                                OutputProgress?.Invoke(realPhyFullName);
                                if (!Directory.Exists(realPhyFullName))
                                    Directory.CreateDirectory(realPhyFullName, Directory.GetAccessControl(hoPhyFullName));

                                _ExtractOrDelete_loop(db, realPhyFullName, isDelete, p.pathInBase, pathesInBase);
                            }
                        }
                        else
                        {
                            if (isDelete)
                            {
                                File.Delete(hoPhyFullName);
                                _DB_DeleteSingle(db, p.position);
                            }
                            else
                            {
                                realPhyFullName = toCurRealDir + "\\" + GetName(p.pathInBase);
                                OutputProgress?.Invoke(realPhyFullName);
                                EncryptedGZip.UnGZipDecryptFile(hoPhyFullName, Password,
                                    realPhyFullName, EncrytConfusionLength, true);
                            }
                        }
                    }
                    // else   this item is not in the current dir, don't process it;
                }
            }
        }

        public Exception Delete(IEnumerable<HidenItemInfo> hiToDel)
        {
            return Delete(hiToDel.Select(a => a.pathInBase).ToArray());
        }
        public Exception Delete(params string[] pathesInBase)
        {
            Exception result = null;

            // remove sub items in dir
            List<string> pibList = new List<string>();
            pibList.AddRange(pathesInBase);
            string p1, p2;
            for (int i = pibList.Count - 1; i > 0; i--)
            {
                p1 = pibList[i];
                for (int j = i - 1; j >= 0; j--)
                {
                    p2 = pibList[j];
                    if (p1.Length > p2.Length)
                    {
                        if (p1.StartsWith(p2 + "\\"))
                        {
                            pibList.RemoveAt(i);
                            break;
                        }
                    }
                    else if (p1.Length < p2.Length)
                    {
                        if (p2.StartsWith(p1 + "\\"))
                        {
                            pibList.RemoveAt(j);
                            i--;
                        }
                    }
                    else
                    {
                        if (p1 == p2)
                        {
                            pibList.RemoveAt(j);
                            i--;
                        }
                    }
                }
            }

            pathesInBase = pibList.ToArray();
            HidenItemInfo hi;
            string hoPhyFullName;
            try
            {
                foreach (string pInB in pathesInBase)
                {
                    hi = _DBGetItm(db, pInB);
                    if (hi.isDir)
                    {
                        //List<HidenItemInfo> subPathesInBase = DB_GetSubItemsInfo(pInB, db, true);
                        List<HidenItemInfo> toDeleteList = new List<HidenItemInfo>();
                        toDeleteList.Add(hi);
                        _ExtractOrDelete_loop(db, null, true, GetParentPath(pInB), toDeleteList);
                    }
                    else
                    {
                        hoPhyFullName = GetHideOutPhycalPath(hi.position);
                        if (File.Exists(hoPhyFullName))
                        {
                            File.Delete(hoPhyFullName);
                        }
                    }

                    _DB_DeleteSingle(db, hi.position);
                    WriteActionHistory(db, DateTime.Now, ActionHistoryItem.Type.Removed, pInB, "", hi.fileLength);
                    ItemRemoved?.Invoke(this, pInB);
                    NeedVacuum = true;
                }
            }
            catch (Exception err)
            { result = err; }

            return result;
        }
        private void _DB_DeleteSingle(SQLiteHelper db, HidenPosition hp)
        {
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("delete from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_Pkg);
                cmdBdr.Append("=? and ");
                cmdBdr.Append(_DBColumnName_Itm);
                cmdBdr.Append("=?;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@P", hp.PkgIndex);
                cmd.Parameters.AddWithValue("@I", hp.ItmIndex);
                cmd.ExecuteNonQuery();
            }
        }


        public Exception Rename(string pathInBase, string newName)
        {
            Exception result = null;

            try
            {
                HidenItemInfo ori = _DBGetItm(db, pathInBase);
                if (ori == null)
                    throw new Exception("Path in DB[" + pathInBase + "] doesn't exist.");

                string newFullName = GetParentPath(pathInBase);
                if (newFullName.Length > 0) newFullName += "\\" + newName;
                else newFullName = newName;
                HidenItemInfo testNew = _DBGetItm(db, newFullName);
                if (testNew != null)
                    throw new Exception("New path[" + newFullName + "] in DB is already existing.");

                StringBuilder cmdBdr = new StringBuilder();
                if (ori.isDir)
                {
                    using (SQLiteCommand cmd = db.GetNewCommand())
                    {
                        cmdBdr.Append("update ");
                        cmdBdr.Append(_DBTableName);
                        cmdBdr.Append(" set ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append("=REPLACE(PathInBase, ?, ?)");
                        cmdBdr.Append(" where ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append("=? or ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append(" like ?;");
                        cmd.CommandText = cmdBdr.ToString();
                        cmd.Parameters.AddWithValue("@O", pathInBase);
                        cmd.Parameters.AddWithValue("@N", newFullName);
                        cmd.Parameters.AddWithValue("@OP", pathInBase);
                        cmd.Parameters.AddWithValue("@OPP", pathInBase + "\\%");
                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    using (SQLiteCommand cmd = db.GetNewCommand())
                    {
                        cmdBdr.Append("update ");
                        cmdBdr.Append(_DBTableName);
                        cmdBdr.Append(" set ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append("=? where ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append("=?;");
                        cmd.CommandText = cmdBdr.ToString();
                        cmd.Parameters.AddWithValue("@N", newFullName);
                        cmd.Parameters.AddWithValue("@O", pathInBase);
                        cmd.ExecuteNonQuery();
                    }
                }

                WriteActionHistory(db, DateTime.Now, ActionHistoryItem.Type.Renamed, pathInBase, newName, ori.fileLength);

                ItemRemoved?.Invoke(this, pathInBase);
                testNew = _DBGetItm(db, newFullName);
                ItemAdded?.Invoke(this, testNew);

            }
            catch (Exception err)
            { result = err; }

            return result;
        }
        private void WriteActionHistory(SQLiteHelper db, DateTime time, ActionHistoryItem.Type actType, string oriPath, string newName = "", long fileLength = 0)
        {
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("insert into ");
                cmdBdr.Append(_DBTableName_ActionHistory);
                cmdBdr.Append("(");
                cmdBdr.Append(_DBColumnName_Act_Time + ",");
                cmdBdr.Append(_DBColumnName_Act_Type + ",");
                cmdBdr.Append(_DBColumnName_Act_PathInBase + ",");
                cmdBdr.Append(_DBColumnName_Act_NewName + ",");
                cmdBdr.Append(_DBColumnName_Act_FileLength);
                cmdBdr.Append(") values (?,?,?,?,?);");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@T", time.Ticks);
                cmd.Parameters.AddWithValue("@TP", (int)actType);
                cmd.Parameters.AddWithValue("@P", oriPath);
                cmd.Parameters.AddWithValue("@N", newName);
                cmd.Parameters.AddWithValue("@L", fileLength);
                cmd.ExecuteNonQuery();
            }
        }

        public class ActionHistoryItem
        {
            public DateTime time;
            public enum Type
            { None = 0, Added = 1, Removed = 2, Renamed = 3 }
            public Type type;
            public string oriPath;
            public string newName;
            public long fileLength = 0;
            public string FinalPath
            {
                get
                {
                    if (type == Type.Renamed)
                    {
                        string result = GetParentPath(oriPath);
                        if (result.Length > 0)
                            result += "\\" + newName;
                        else
                            result = newName;
                        return result;
                    }
                    else
                        return oriPath;
                }
            }
        }
        public List<ActionHistoryItem> GetActionHistory(DateTime startTime)
        {
            List<ActionHistoryItem> result = new List<ActionHistoryItem>();
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("SELECT * FROM ");
                cmdBdr.Append(_DBTableName_ActionHistory);
                cmdBdr.Append(" WHERE ");
                cmdBdr.Append(_DBColumnName_Act_Time);
                cmdBdr.Append(">=?;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@T", startTime.Ticks);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new ActionHistoryItem()
                        {
                            time = new DateTime(reader.GetInt64(0)),
                            type = (ActionHistoryItem.Type)reader.GetInt32(1),
                            oriPath = reader.GetString(2),
                            newName = reader.GetString(3),
                            fileLength = reader.GetInt64(4),
                        });
                    }
                }
            }
            return result;
        }

        // [Serializable]
        public class HidenItemInfoCollection : ISerializable
        {
            public bool? isMoveOrCopy = true;
            public List<HidenItemInfo> collection = new List<HidenItemInfo>();
            public void GetObjectData(SerializationInfo info, StreamingContext context)
            {
                info.AddValue("isMoveOrCopy", isMoveOrCopy.ToString());
                info.AddValue("collection", collection.ToArray());
            }
            public static HidenItemInfoCollection FromObjectData(object data)
            {
                try
                {
                    return (HidenItemInfoCollection)data;
                }
                catch (Exception)
                { return null; }
            }
        }
        public class HidenItemInfo : ISerializable
        {
            public FileHiderCore core;
            public HidenPosition position;
            public string pathInBase;
            public bool isDir;
            public long fileLength;
            public DateTime lastWriteTime;
            public void GetObjectData(SerializationInfo info, StreamingContext context)
            {
                info.AddValue("HidenPosition", position.PkgIndex + "," + position.ItmIndex);
                info.AddValue("isDir", isDir.ToString());
                info.AddValue("fileLength", fileLength.ToString());
                info.AddValue("pathInBase", pathInBase);
            }
        }
        public List<HidenItemInfo> DB_GetSubItemsInfo(string dirInBase, bool fullDepth = false)
        {
            List<HidenItemInfo> result = new List<HidenItemInfo>();
            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_PathInBase);
                cmdBdr.Append(" like '");
                cmdBdr.Append(dirInBase);
                if (string.IsNullOrWhiteSpace(dirInBase))
                {
                    cmdBdr.Append("%'");
                    if (fullDepth)
                    {
                        cmdBdr.Append(";");
                    }
                    else
                    {
                        cmdBdr.Append(" and ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append(" not like '");
                        cmdBdr.Append(dirInBase);
                        cmdBdr.Append("%\\%';");
                    }
                }
                else
                {
                    cmdBdr.Append("\\%'");
                    if (fullDepth)
                    {
                        cmdBdr.Append(";");
                    }
                    else
                    {
                        cmdBdr.Append(" and ");
                        cmdBdr.Append(_DBColumnName_PathInBase);
                        cmdBdr.Append(" not like '");
                        cmdBdr.Append(dirInBase);
                        cmdBdr.Append("\\%\\%';");
                    }
                }
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new HidenItemInfo()
                        {
                            core = this,
                            pathInBase = reader.GetString(0),
                            isDir = reader.GetBoolean(1),
                            fileLength = reader.GetInt64(2),
                            position = new HidenPosition()
                            { PkgIndex = reader.GetInt32(3), ItmIndex = reader.GetInt32(4), },
                            lastWriteTime = new DateTime(reader.GetInt64(5)),
                        });
                    }
                }
            }
            return result;
        }
        public List<HidenItemInfo> DB_GetItemsInfo(params string[] pathesInBase)
        {
            List<HidenItemInfo> result = new List<HidenItemInfo>();
            if (pathesInBase == null || pathesInBase.Length == 0)
                return result;

            using (SQLiteCommand cmd = db.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(_DBTableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(_DBColumnName_PathInBase);
                cmdBdr.Append(" in (?");
                string cmdStart = cmdBdr.ToString();
                string cmdEnd9q = ",?,?,?,?,?,?,?,?,?);";
                int iCount = 0;
                for (int i = 0, l = pathesInBase.Length; i < l; i++)
                {
                    cmd.Parameters.AddWithValue("@p" + i.ToString(), pathesInBase[i]);
                    iCount++;
                    if (iCount >= 10)
                    {
                        cmd.CommandText = cmdStart + cmdEnd9q;
                        using (SQLiteDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                result.Add(new HidenItemInfo()
                                {
                                    core = this,
                                    pathInBase = reader.GetString(0),
                                    isDir = reader.GetBoolean(1),
                                    fileLength = reader.GetInt64(2),
                                    position = new HidenPosition()
                                    { PkgIndex = reader.GetInt32(3), ItmIndex = reader.GetInt32(4), },
                                    lastWriteTime = new DateTime(reader.GetInt64(5)),
                                });
                            }
                        }
                        iCount = 0;
                        cmd.Parameters.Clear();
                    }
                }
                if (iCount > 0)
                {
                    cmdBdr.Clear();
                    for (int i = iCount; i > 1; i--)
                        cmdBdr.Append(",?");
                    cmd.CommandText = cmdStart + cmdBdr.ToString() + ");";
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new HidenItemInfo()
                            {
                                core = this,
                                pathInBase = reader.GetString(0),
                                isDir = reader.GetBoolean(1),
                                fileLength = reader.GetInt64(2),
                                position = new HidenPosition()
                                { PkgIndex = reader.GetInt32(3), ItmIndex = reader.GetInt32(4), },
                                lastWriteTime = new DateTime(reader.GetInt64(5)),
                            });
                        }
                    }
                }
            }

            return result;
        }

        public bool NeedVacuum
        { private set; get; } = false;

        public int Vacuum(bool forceVacuum = false)
        {
            int result = 0;
            if (forceVacuum || NeedVacuum)
            {
                NeedVacuum = false;
                using (SQLiteTransaction trans = db.GetNewTransaction())
                {
                    using (SQLiteCommand cmd = db.GetNewCommand())
                    {
                        int headPKIdx = 0;
                        VacuumPackageKeeper headPK = new VacuumPackageKeeper(cmd, headPKIdx);
                        int maxPkgIdx = _DBGetMaxPkgIdx(cmd);
                        if (maxPkgIdx == 0)
                        {
                            // self vacuum
                            Vacuum_selfPackageVac(cmd, headPK);
                        }
                        else
                        {
                            int tailPKIdx = maxPkgIdx;
                            VacuumPackageKeeper tailPK = new VacuumPackageKeeper(cmd, tailPKIdx);
                            HidenPosition blankHP, lastHP;
                            while (true)
                            {
                                if (tailPK.IsEmpty)
                                {
                                    Directory.Delete(GetHideOutPhycalPath(tailPK.pkgIdx), true);

                                    if (--tailPKIdx == headPKIdx)
                                    {
                                        Vacuum_selfPackageVac(cmd, headPK);
                                        break;
                                    }
                                    tailPK = new VacuumPackageKeeper(cmd, tailPKIdx);
                                    continue;
                                }
                                if (headPK.IsFull)
                                {
                                    Vacuum_selfPackageVac(cmd, headPK);
                                    if (++headPKIdx == tailPKIdx)
                                    {
                                        Vacuum_selfPackageVac(cmd, tailPK);
                                        break;
                                    }
                                    headPK = new VacuumPackageKeeper(cmd, headPKIdx);
                                    continue;
                                }

                                lastHP = tailPK.RemoveLast();
                                blankHP = headPK.GetBlankPosition();
                                Vacuum_singleIOMove(lastHP, blankHP);
                                _DBUpdatePosition(cmd, lastHP, blankHP);
                                headPK.AddPosi(blankHP);
                            }
                        }

                        // remove old rename history
                        StringBuilder cmdBdr = new StringBuilder();
                        cmdBdr.Append("delete from ");
                        cmdBdr.Append(_DBTableName_ActionHistory);
                        cmdBdr.Append(" where ");
                        cmdBdr.Append(_DBColumnName_Act_Time);
                        cmdBdr.Append("<?;");
                        cmd.CommandText = cmdBdr.ToString();
                        cmd.Parameters.Clear();
                        DateTime dt = DateTime.Now.AddDays(-1 * NewNameHistoryExpirationDays);
                        cmd.Parameters.AddWithValue("@T", dt.Ticks);
                        cmd.ExecuteNonQuery();
                    }

                    VacuumEndPhase?.Invoke("DB Commiting...");
                    trans.Commit();
                    VacuumEndPhase?.Invoke("DB Vacuuming main table...");
                    using (SQLiteCommand cmd = db.GetNewCommand())
                    {
                        cmd.CommandText = "vacuum";
                        cmd.ExecuteNonQuery();
                    }
                    VacuumComplete?.Invoke();
                }
            }
            return result;
        }
        private void Vacuum_selfPackageVac(SQLiteCommand cmd, VacuumPackageKeeper pkgKpr)
        {
            if (pkgKpr.IsEmpty)
                return;
            HidenPosition blankHP, lastHP;
            lastHP = pkgKpr.RemoveLast();
            while (lastHP.ItmIndex > pkgKpr.packagePositions.Count)
            {
                blankHP = pkgKpr.GetBlankPosition();
                Vacuum_singleIOMove(lastHP, blankHP);
                _DBUpdatePosition(cmd, lastHP, blankHP);
                pkgKpr.AddPosi(blankHP);

                if (pkgKpr.IsEmpty)
                    return;
                lastHP = pkgKpr.RemoveLast();
            }
        }
        private void Vacuum_singleIOMove(HidenPosition curPosi, HidenPosition targetPosi)
        {
            string curPhy = GetHideOutPhycalPath(curPosi);
            string tarPhy = GetHideOutPhycalPath(targetPosi);

            if (File.Exists(tarPhy))
                File.Delete(tarPhy);
            else if (Directory.Exists(tarPhy))
                Directory.Delete(tarPhy, true);

            if (File.Exists(curPhy))
                File.Move(curPhy, tarPhy);
            else if (Directory.Exists(curPhy))
                Directory.Move(curPhy, tarPhy);
        }
        private class VacuumPackageKeeper
        {
            public int pkgIdx;
            public List<HidenPosition> packagePositions;

            private SQLiteCommand cmd;
            public VacuumPackageKeeper(SQLiteCommand cmd, int pkgIdx)
            {
                this.cmd = cmd;
                this.pkgIdx = pkgIdx;
                packagePositions = _DBGetPkgPositions(cmd, pkgIdx);
                _SortPkgPosis();
            }
            private bool _NeedSortPkgPosis = false;
            private void _SortPkgPosis()
            {
                if (_NeedSortPkgPosis)
                {
                    packagePositions.Sort((x, y) => x.ItmIndex.CompareTo(y.ItmIndex));
                    _NeedSortPkgPosis = false;
                }
            }

            public bool IsFull
            { get { return packagePositions.Count >= _DB_MaxItms_PerPkg; } }

            public bool IsEmpty
            { get { return packagePositions.Count == 0; } }

            private int GetBlankPosition_start = 0;
            public HidenPosition GetBlankPosition(bool fromStart = false)
            {
                _SortPkgPosis();
                int pkgCount = packagePositions.Count;
                HidenPosition curHP, tmpHP;
                int tmpInt;
                while (true)
                {
                    if (packagePositions.Count == 0)
                    {
                        return new HidenPosition()
                        { PkgIndex = pkgIdx, ItmIndex = 0, };
                    }
                    if (GetBlankPosition_start >= packagePositions.Count)
                    {
                        return new HidenPosition()
                        {
                            PkgIndex = pkgIdx,
                            ItmIndex = packagePositions[packagePositions.Count - 1].ItmIndex + 1,
                        };
                    }

                    curHP = packagePositions[GetBlankPosition_start];
                    if (curHP.ItmIndex > GetBlankPosition_start)
                    {
                        // find blank left
                        if (GetBlankPosition_start <= 0)
                        {
                            return new HidenPosition()
                            { PkgIndex = pkgIdx, ItmIndex = 0, };
                        }

                        tmpInt = GetBlankPosition_start - 1;
                        tmpHP = packagePositions[tmpInt];
                        if (tmpHP.ItmIndex == tmpInt)
                        {
                            GetBlankPosition_start = tmpInt + 1;
                            return new HidenPosition()
                            { PkgIndex = pkgIdx, ItmIndex = GetBlankPosition_start, };
                        }
                        else
                        {
                            GetBlankPosition_start--;
                        }

                    }
                    else
                    {
                        // ItmIdx == i  ,  no way on ItmIdx < i
                        tmpInt = GetBlankPosition_start + 1;
                        if (tmpInt >= packagePositions.Count)
                        {
                            return new HidenPosition()
                            { PkgIndex = pkgIdx, ItmIndex = tmpInt, };
                        }

                        tmpHP = packagePositions[tmpInt];
                        if (tmpHP.ItmIndex > tmpInt)
                        {
                            GetBlankPosition_start = tmpInt;
                            return new HidenPosition()
                            { PkgIndex = pkgIdx, ItmIndex = GetBlankPosition_start, };
                        }
                        else
                        {
                            GetBlankPosition_start++;
                        }
                    }
                }
            }

            public void AddPosi(HidenPosition posi)
            {
                if (IsFull)
                    throw new Exception("Package full.");
                if (posi.PkgIndex != pkgIdx)
                    throw new Exception("Different package index.");

                HidenPosition duplicated = packagePositions.Find(x => x.ItmIndex == posi.ItmIndex);
                if (duplicated != null)
                    throw new Exception("Duplicated position.");

                packagePositions.Add(posi);
                _NeedSortPkgPosis = true;
            }
            public void RemovePosi(HidenPosition posi)
            {
                if (posi.PkgIndex != pkgIdx)
                    throw new Exception("Different package index.");

                HidenPosition duplicated = packagePositions.Find(x => x.ItmIndex == posi.ItmIndex);
                if (duplicated.ItmIndex == posi.ItmIndex)
                    packagePositions.Remove(duplicated);
                else
                    throw new Exception("Position not found.");
            }
            public HidenPosition RemoveLast()
            {
                if (IsEmpty)
                    throw new Exception("Package empty.");

                _SortPkgPosis();
                int lastIdx = packagePositions.Count - 1;
                HidenPosition result = packagePositions[lastIdx];
                packagePositions.RemoveAt(lastIdx);
                return result;
            }

        }

        public delegate void VacuumProgressDelegate(int curPkg, int maxPkg);
        public delegate void VacuumEndPhaseDelegate(string msg);
        public delegate void VacuumCompleteDelegate();
        public event VacuumProgressDelegate VacuumProgress;
        public event VacuumEndPhaseDelegate VacuumEndPhase;
        public event VacuumCompleteDelegate VacuumComplete;
        public void Dispose(bool doVacuum)
        {
            if (doVacuum)
                Vacuum();
            Dispose();
        }
        public void Dispose()
        {
            // nothing todo
        }
    }
}
