﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.IO;
using System.Threading;

namespace WFA_NoDuplicateCopy
{
    public class ClassFileHelper
    {
        BackgroundWorker backgroundWorker_fileCopy;
        BackgroundWorker backgroundWorker_state;
        public ClassFileHelper()
        {
            backgroundWorker_fileCopy = new BackgroundWorker();
            backgroundWorker_fileCopy.WorkerReportsProgress = true;
            backgroundWorker_fileCopy.WorkerSupportsCancellation = true;

            backgroundWorker_fileCopy.DoWork += backgroundWorker_fileCopy_DoWork;
            backgroundWorker_fileCopy.ProgressChanged += backgroundWorker_fileCopy_ProgressChanged;
            backgroundWorker_fileCopy.RunWorkerCompleted += backgroundWorker_fileCopy_RunWorkerCompleted;

            backgroundWorker_state = new BackgroundWorker();
            backgroundWorker_state.WorkerReportsProgress = true;
            backgroundWorker_state.WorkerSupportsCancellation = true;

            backgroundWorker_state.DoWork += backgroundWorker_state_DoWork;
            backgroundWorker_state.ProgressChanged += backgroundWorker_state_ProgressChanged;
            backgroundWorker_state.RunWorkerCompleted += backgroundWorker_state_RunWorkerCompleted;
        }

        private FormMain parent;
        public void Start(FormMain parent)
        {
            this.parent = parent;
            parent.button_abort.Enabled = true;
            isWorking = true;
            if (WorkStart != null)
            {
                WorkStart(this, null);
            }
            backgroundWorker_fileCopy.RunWorkerAsync(parent);
            backgroundWorker_state.RunWorkerAsync(parent);
        }
        public void Abort()
        {
            backgroundWorker_fileCopy.CancelAsync();
            backgroundWorker_state.CancelAsync();
        }

        public event EventHandler WorkStart;
        //public event EventHandler WorkProcessing;
        public event EventHandler WorkAbort;
        public event EventHandler WorkComplete;

        public class PendingFileInfo
        {
            public FileInfo sourceFileInfo;
            public FileInfo targetFileInfo;
            // 0 same file name, 1 similar file name
            public TagKeys tag;

            public enum TagKeys
            {
                SameFileName = 0,
                SimilarFileName = 1,
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="sourceFileInfo"></param>
            /// <param name="targetFileInfo"></param>
            /// <param name="tag">0 same file name, 1 similar file name</param>
            public PendingFileInfo(FileInfo sourceFileInfo, FileInfo targetFileInfo, TagKeys tag)
            {
                this.sourceFileInfo = sourceFileInfo;
                this.targetFileInfo = targetFileInfo;
                this.tag = tag;
            }
        }

        public class CopyOperate
        {
            public enum OperateKeys
            {
                Leave = 0,
                Replace = 1,
                Rename = 2,
            }

            public bool isMoveSource = false;
            public OperateKeys operate;
            public List<PendingFileInfo> pendingFileInfoList = new List<PendingFileInfo>();
            public CopyOperate()
            {
            }
            public CopyOperate(OperateKeys operate, List<PendingFileInfo> pendingFileInfoList, bool isMoveSource)
            {
                this.operate = operate;
                this.pendingFileInfoList = pendingFileInfoList;
                this.isMoveSource = isMoveSource;
            }
        }

        public int countAll, countDone, countPending;
        private string rootTargetPath;
        public string copyState = "Idel"; // Idel preparing copying pending 

        public bool isWorking = false;
        private void backgroundWorker_fileCopy_DoWork(object sender, DoWorkEventArgs e)
        {
            copyState = "preparing";
            FormMain win = e.Argument as FormMain;
            BackgroundWorker me = sender as BackgroundWorker;

            List<FileInfo> targets = new List<FileInfo>();
            rootTargetPath = win.textBox_folderPath.Text;
            GetAllFiles(new DirectoryInfo(rootTargetPath), ref targets);

            if (me.CancellationPending == true)
            {
                e.Cancel = true;
                return;
            }

            List<FileInfo> fileSource = win.fileSource;
            List<PendingFileInfo> pendingSource_sameName = new List<PendingFileInfo>();
            List<PendingFileInfo> pendingSource_similarName = new List<PendingFileInfo>();

            countAll = fileSource.Count;
            countDone = 0;
            countPending = 0;

            bool containCheck = win.checkBox_optionContainCheck.Checked;
            bool isMovingFile = win.isMoveFiles;

            FileInfo curSource;
            string targetFileName, sourceFileName;
            bool canCopy = false;

            #region copy and check pendings
            copyState = "copying";
            bool sameFileNameFound = false;
            for (int idx = fileSource.Count - 1; idx >= 0; idx--)
            {
                if (me.CancellationPending == true)
                {
                    e.Cancel = true;
                    break;
                }
                canCopy = true;
                curSource = fileSource[idx];
                sourceFileName = curSource.Name;

                sameFileNameFound = false;
                foreach (FileInfo fi in targets)
                {
                    targetFileName = fi.Name;
                    if (targetFileName == sourceFileName)
                    {
                        pendingSource_sameName.Add(new PendingFileInfo(curSource, fi, PendingFileInfo.TagKeys.SameFileName));
                        countPending++;
                        canCopy = false;
                        sameFileNameFound = true;
                        break;
                    }
                }

                if (containCheck == true && sameFileNameFound == false)
                {
                    foreach (FileInfo fi in targets)
                    {
                        targetFileName = fi.Name;
                        if (targetFileName.Contains(curSource.Name.Substring(0, sourceFileName.Length - curSource.Extension.Length))
                            || sourceFileName.Contains(fi.Name.Substring(0, targetFileName.Length - fi.Extension.Length)))
                        {
                            pendingSource_similarName.Add(new PendingFileInfo(curSource, fi, PendingFileInfo.TagKeys.SimilarFileName));
                            countPending++;
                            canCopy = false;
                            break;
                        }
                    }
                }


                if (canCopy == true)
                {
                    if (isMovingFile == true)
                    {
                        File.Move(curSource.FullName, rootTargetPath + "\\" + curSource.Name);
                        countDone++;
                    }
                    else
                    {
                        File.Copy(curSource.FullName, rootTargetPath + "\\" + curSource.Name);
                        countDone++;
                    }
                }
                //me.ReportProgress(0);
            }
            #endregion

            if (pendingSource_sameName.Count > 0
                || pendingSource_similarName.Count > 0)
            {
                copyState = "pending";

                if (me.CancellationPending == true)
                {
                    e.Cancel = true;
                    return;
                }
                FormPendingFiles formPendingFiles = new FormPendingFiles();
                formPendingFiles.FormClosed += formPendingFiles_FormClosed;

                PendingFileInfo sameFNInfo, similarFNInfo;
                CopyOperate copyOperate;
                while (pendingSource_sameName.Count > 0 || pendingSource_similarName.Count > 0)
                {
                    formPendingFiles.SameFNCount = pendingSource_sameName.Count;
                    formPendingFiles.similarFNCount = pendingSource_similarName.Count;

                    sameFNInfo = (formPendingFiles.SameFNCount > 0) ? pendingSource_sameName[0] : null;
                    similarFNInfo = (formPendingFiles.similarFNCount > 0) ? pendingSource_similarName[0] : null;
                    formPendingFiles.sameFNInfo = sameFNInfo;
                    formPendingFiles.similarFNInfo = similarFNInfo;
                    formPendingFiles.isMovingFile = isMovingFile;

                    formPendingFiles.ShowDialog();
                    if (me.CancellationPending == true)
                    {
                        e.Cancel = true;
                        return;
                    }

                    copyOperate = new CopyOperate();
                    copyOperate.isMoveSource = isMovingFile;
                    switch (formPendingFiles.actionSameFNTag)
                    {
                        case 0: // same, leave
                            copyOperate.operate = CopyOperate.OperateKeys.Leave;
                            if (formPendingFiles.checkBox_SameFNDoTheSame.Checked == true)
                            {
                                copyOperate.pendingFileInfoList = pendingSource_sameName;
                            }
                            else if (pendingSource_sameName.Count > 0)
                            {
                                copyOperate.pendingFileInfoList.Add(pendingSource_sameName[0]);
                                pendingSource_sameName.RemoveAt(0);
                            }
                            break;
                        case 1: // same, replace
                            copyOperate.operate = CopyOperate.OperateKeys.Replace;
                            if (formPendingFiles.checkBox_SameFNDoTheSame.Checked == true)
                            {
                                copyOperate.pendingFileInfoList = pendingSource_sameName;
                            }
                            else if (pendingSource_sameName.Count > 0)
                            {
                                copyOperate.pendingFileInfoList.Add(pendingSource_sameName[0]);
                                pendingSource_sameName.RemoveAt(0);
                            }
                            break;
                        case 2: // same, rename
                            copyOperate.operate = CopyOperate.OperateKeys.Rename;
                            if (formPendingFiles.checkBox_SameFNDoTheSame.Checked == true)
                            {
                                copyOperate.pendingFileInfoList = pendingSource_sameName;
                            }
                            else if (pendingSource_sameName.Count > 0)
                            {
                                copyOperate.pendingFileInfoList.Add(pendingSource_sameName[0]);
                                pendingSource_sameName.RemoveAt(0);
                            }
                            break;

                        case 3: // similar, leave
                            copyOperate.operate = CopyOperate.OperateKeys.Leave;
                            if (formPendingFiles.checkBox_SameFNDoTheSame.Checked == true)
                            {
                                copyOperate.pendingFileInfoList = pendingSource_similarName;
                            }
                            else if (pendingSource_similarName.Count > 0)
                            {
                                copyOperate.pendingFileInfoList.Add(pendingSource_similarName[0]);
                                pendingSource_similarName.RemoveAt(0);
                            }
                            break;
                        case 4: // similar, replace
                            copyOperate.operate = CopyOperate.OperateKeys.Replace;
                            if (formPendingFiles.checkBox_SameFNDoTheSame.Checked == true)
                            {
                                copyOperate.pendingFileInfoList = pendingSource_similarName;
                            }
                            else if (pendingSource_similarName.Count > 0)
                            {
                                copyOperate.pendingFileInfoList.Add(pendingSource_similarName[0]);
                                pendingSource_similarName.RemoveAt(0);
                            }
                            break;
                        case 5: // similar, rename
                            copyOperate.operate = CopyOperate.OperateKeys.Rename;
                            if (formPendingFiles.checkBox_SameFNDoTheSame.Checked == true)
                            {
                                copyOperate.pendingFileInfoList = pendingSource_similarName;
                            }
                            else if (pendingSource_similarName.Count > 0)
                            {
                                copyOperate.pendingFileInfoList.Add(pendingSource_similarName[0]);
                                pendingSource_similarName.RemoveAt(0);
                            }
                            break;
                    }
                    FileOperate(ref copyOperate);
                }
            }
        }

        private void FileOperate(ref CopyOperate copyOperate)
        {
            switch (copyOperate.operate)
            {
                case CopyOperate.OperateKeys.Leave:
                    countPending -= copyOperate.pendingFileInfoList.Count;
                    countDone += copyOperate.pendingFileInfoList.Count;
                    break;
                case CopyOperate.OperateKeys.Replace:
                    foreach (PendingFileInfo pfi in copyOperate.pendingFileInfoList)
                    {
                        File.Delete(pfi.targetFileInfo.FullName);
                        if (copyOperate.isMoveSource == true)
                        {
                            //File.Move(pfi.sourceFileInfo.FullName, rootTargetPath + "\\" + pfi.targetFileInfo.Name);
                            File.Move(pfi.sourceFileInfo.FullName, pfi.targetFileInfo.FullName);
                        }
                        else
                        {
                            //File.Copy(pfi.sourceFileInfo.FullName, rootTargetPath + "\\" + pfi.targetFileInfo.Name);
                            File.Copy(pfi.sourceFileInfo.FullName, pfi.targetFileInfo.FullName);
                        }
                    }
                    countPending -= copyOperate.pendingFileInfoList.Count;
                    countDone += copyOperate.pendingFileInfoList.Count;
                    break;
                case CopyOperate.OperateKeys.Rename:
                    foreach (PendingFileInfo pfi in copyOperate.pendingFileInfoList)
                    {
                        if (copyOperate.isMoveSource == true)
                        {
                            File.Move(pfi.sourceFileInfo.FullName,
                                rootTargetPath + "\\" + GetNextRename(pfi.sourceFileInfo, pfi.targetFileInfo));
                        }
                        else
                        {
                            File.Copy(pfi.sourceFileInfo.FullName,
                                rootTargetPath + "\\" + GetNextRename(pfi.sourceFileInfo, pfi.targetFileInfo));
                        }
                        break;
                    }
                    countPending -= copyOperate.pendingFileInfoList.Count;
                    countDone += copyOperate.pendingFileInfoList.Count;
                    break;
            }
        }

        private string GetNextRename(FileInfo sourceFile, FileInfo targetFile)
        {
            string sourceFPre = sourceFile.Name;
            string targetFPre = targetFile.Name;
            //if (sourceFPre != targetFPre)
            //{
            //    return sourceFPre;
            //}
            string sourceFEx = sourceFile.Extension;
            string targetFEx = targetFile.Extension;
            sourceFPre = sourceFPre.Substring(0, sourceFPre.Length - sourceFEx.Length);
            targetFPre = targetFPre.Substring(0, targetFPre.Length - targetFEx.Length);

            //check xxxx(#)
            int lPareIdx = sourceFPre.LastIndexOf('(');
            int rPareIdx = sourceFPre.LastIndexOf(')');
            if (lPareIdx >= 0 && lPareIdx < rPareIdx)
            {
                bool isContainNum = false;
                try
                {
                    string tmp = sourceFPre.Substring(lPareIdx + 1, (rPareIdx - lPareIdx - 1)).Trim();
                    int tmpInt = int.Parse(tmp);
                    isContainNum = true;
                }
                catch (Exception ex)
                {
                }
                if (isContainNum)
                {
                    sourceFPre = sourceFPre.Substring(0, lPareIdx);
                }
            }

            string newTargetName;
            int ct = 1;
            while (true)
            {
                newTargetName = sourceFPre
                    + " (" + ct + ")";
                if (newTargetName.Trim() != targetFPre.Trim()
                    && File.Exists(targetFile.DirectoryName + "\\" + newTargetName + sourceFEx) == false)
                {
                    return newTargetName + sourceFEx;
                }
                ct++;
            }
        }





        void formPendingFiles_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            if (isWorking == true)
            {
                isWorking = false;
                if (WorkAbort != null)
                {
                    WorkAbort(this, null);
                }
            }
            backgroundWorker_fileCopy.CancelAsync();
            backgroundWorker_state.CancelAsync();
        }

        private void GetAllFiles(DirectoryInfo rootDir, ref List<FileInfo> record)
        {
            record.AddRange(rootDir.GetFiles());
            foreach (DirectoryInfo di in rootDir.GetDirectories())
            {
                GetAllFiles(di, ref record);
            }
        }

        private void backgroundWorker_fileCopy_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }

        private void backgroundWorker_fileCopy_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            isWorking = false;
            if (WorkComplete != null)
            {
                WorkComplete(this, null);
            }
            parent.button_abort.Enabled = false;
        }



        private void backgroundWorker_state_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker me = sender as BackgroundWorker;
            while (isWorking)
            {
                if (me.CancellationPending == true)
                {
                    e.Cancel = true;
                    break;
                }
                me.ReportProgress(0);
                Thread.Sleep(100);
            }
        }

        private void backgroundWorker_state_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            switch (copyState)
            {
                case "Idel":
                    parent.label_copyState.Text = "Idel";
                    break;
                case "preparing":
                    parent.label_copyState.Text = "preparing";
                    break;
                case "copying":
                    parent.label_copyState.Text = "Working (" + countDone + "/" + countAll + "), pending (" + countPending + ")";
                    break;
                case "pending":
                    parent.label_copyState.Text = "Solving pending, remaining (" + countPending + "), overall (" + countDone + "/" + countAll + ")";
                    break;
            }
        }

        private void backgroundWorker_state_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            parent.label_copyState.Text = "Idel";
        }
    }
}
