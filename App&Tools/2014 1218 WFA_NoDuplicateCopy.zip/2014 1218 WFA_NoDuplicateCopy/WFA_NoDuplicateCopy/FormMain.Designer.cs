﻿namespace WFA_NoDuplicateCopy
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_targetPath = new System.Windows.Forms.GroupBox();
            this.button_about = new System.Windows.Forms.Button();
            this.button_folderPathBrowse = new System.Windows.Forms.Button();
            this.textBox_folderPath = new System.Windows.Forms.TextBox();
            this.groupBox_options = new System.Windows.Forms.GroupBox();
            this.checkBox_optionContainCheck = new System.Windows.Forms.CheckBox();
            this.groupBox_dropZone = new System.Windows.Forms.GroupBox();
            this.button_abort = new System.Windows.Forms.Button();
            this.label_copyState = new System.Windows.Forms.Label();
            this.textBox_dropZone = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.groupBox_targetPath.SuspendLayout();
            this.groupBox_options.SuspendLayout();
            this.groupBox_dropZone.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_targetPath
            // 
            this.groupBox_targetPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_targetPath.Controls.Add(this.button_about);
            this.groupBox_targetPath.Controls.Add(this.button_folderPathBrowse);
            this.groupBox_targetPath.Controls.Add(this.textBox_folderPath);
            this.groupBox_targetPath.Location = new System.Drawing.Point(12, 12);
            this.groupBox_targetPath.Name = "groupBox_targetPath";
            this.groupBox_targetPath.Size = new System.Drawing.Size(468, 100);
            this.groupBox_targetPath.TabIndex = 0;
            this.groupBox_targetPath.TabStop = false;
            this.groupBox_targetPath.Text = "Target Path";
            // 
            // button_about
            // 
            this.button_about.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_about.Location = new System.Drawing.Point(351, 71);
            this.button_about.Name = "button_about";
            this.button_about.Size = new System.Drawing.Size(30, 23);
            this.button_about.TabIndex = 2;
            this.button_about.Text = "?";
            this.button_about.UseVisualStyleBackColor = true;
            this.button_about.Click += new System.EventHandler(this.button_about_Click);
            // 
            // button_folderPathBrowse
            // 
            this.button_folderPathBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_folderPathBrowse.Location = new System.Drawing.Point(387, 71);
            this.button_folderPathBrowse.Name = "button_folderPathBrowse";
            this.button_folderPathBrowse.Size = new System.Drawing.Size(75, 23);
            this.button_folderPathBrowse.TabIndex = 1;
            this.button_folderPathBrowse.Text = "Browse...";
            this.button_folderPathBrowse.UseVisualStyleBackColor = true;
            this.button_folderPathBrowse.Click += new System.EventHandler(this.button_folderPathBrowse_Click);
            // 
            // textBox_folderPath
            // 
            this.textBox_folderPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_folderPath.Location = new System.Drawing.Point(6, 20);
            this.textBox_folderPath.Multiline = true;
            this.textBox_folderPath.Name = "textBox_folderPath";
            this.textBox_folderPath.ReadOnly = true;
            this.textBox_folderPath.Size = new System.Drawing.Size(456, 45);
            this.textBox_folderPath.TabIndex = 0;
            // 
            // groupBox_options
            // 
            this.groupBox_options.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_options.Controls.Add(this.checkBox_optionContainCheck);
            this.groupBox_options.Location = new System.Drawing.Point(12, 118);
            this.groupBox_options.Name = "groupBox_options";
            this.groupBox_options.Size = new System.Drawing.Size(468, 75);
            this.groupBox_options.TabIndex = 1;
            this.groupBox_options.TabStop = false;
            this.groupBox_options.Text = "Options";
            // 
            // checkBox_optionContainCheck
            // 
            this.checkBox_optionContainCheck.AutoSize = true;
            this.checkBox_optionContainCheck.Location = new System.Drawing.Point(6, 20);
            this.checkBox_optionContainCheck.Name = "checkBox_optionContainCheck";
            this.checkBox_optionContainCheck.Size = new System.Drawing.Size(102, 16);
            this.checkBox_optionContainCheck.TabIndex = 0;
            this.checkBox_optionContainCheck.Text = "Contain Check";
            this.checkBox_optionContainCheck.UseVisualStyleBackColor = true;
            // 
            // groupBox_dropZone
            // 
            this.groupBox_dropZone.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_dropZone.Controls.Add(this.button_abort);
            this.groupBox_dropZone.Controls.Add(this.label_copyState);
            this.groupBox_dropZone.Controls.Add(this.textBox_dropZone);
            this.groupBox_dropZone.Location = new System.Drawing.Point(12, 199);
            this.groupBox_dropZone.Name = "groupBox_dropZone";
            this.groupBox_dropZone.Size = new System.Drawing.Size(468, 225);
            this.groupBox_dropZone.TabIndex = 2;
            this.groupBox_dropZone.TabStop = false;
            this.groupBox_dropZone.Text = "Drop Zone";
            // 
            // button_abort
            // 
            this.button_abort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_abort.Enabled = false;
            this.button_abort.Location = new System.Drawing.Point(386, 195);
            this.button_abort.Name = "button_abort";
            this.button_abort.Size = new System.Drawing.Size(75, 23);
            this.button_abort.TabIndex = 2;
            this.button_abort.Text = "Abort";
            this.button_abort.UseVisualStyleBackColor = true;
            this.button_abort.Click += new System.EventHandler(this.button_abort_Click);
            // 
            // label_copyState
            // 
            this.label_copyState.AutoSize = true;
            this.label_copyState.Location = new System.Drawing.Point(6, 200);
            this.label_copyState.Name = "label_copyState";
            this.label_copyState.Size = new System.Drawing.Size(29, 12);
            this.label_copyState.TabIndex = 1;
            this.label_copyState.Text = "Idel";
            // 
            // textBox_dropZone
            // 
            this.textBox_dropZone.AllowDrop = true;
            this.textBox_dropZone.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_dropZone.Font = new System.Drawing.Font("微软雅黑", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_dropZone.Location = new System.Drawing.Point(8, 20);
            this.textBox_dropZone.Multiline = true;
            this.textBox_dropZone.Name = "textBox_dropZone";
            this.textBox_dropZone.ReadOnly = true;
            this.textBox_dropZone.Size = new System.Drawing.Size(454, 169);
            this.textBox_dropZone.TabIndex = 0;
            this.textBox_dropZone.Text = "\r\nDrag and Drop your files\r\nHere!!";
            this.textBox_dropZone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_dropZone.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_dropZone_DragDrop);
            this.textBox_dropZone.DragOver += new System.Windows.Forms.DragEventHandler(this.textBox_dropZone_DragOver);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 436);
            this.Controls.Add(this.groupBox_dropZone);
            this.Controls.Add(this.groupBox_options);
            this.Controls.Add(this.groupBox_targetPath);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "No Duplicate Copy 2014 1221 1201";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.groupBox_targetPath.ResumeLayout(false);
            this.groupBox_targetPath.PerformLayout();
            this.groupBox_options.ResumeLayout(false);
            this.groupBox_options.PerformLayout();
            this.groupBox_dropZone.ResumeLayout(false);
            this.groupBox_dropZone.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_targetPath;
        private System.Windows.Forms.Button button_about;
        private System.Windows.Forms.Button button_folderPathBrowse;
        public System.Windows.Forms.TextBox textBox_folderPath;
        private System.Windows.Forms.GroupBox groupBox_options;
        public System.Windows.Forms.CheckBox checkBox_optionContainCheck;
        private System.Windows.Forms.GroupBox groupBox_dropZone;
        private System.Windows.Forms.TextBox textBox_dropZone;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        public System.Windows.Forms.Button button_abort;
        public System.Windows.Forms.Label label_copyState;
    }
}

