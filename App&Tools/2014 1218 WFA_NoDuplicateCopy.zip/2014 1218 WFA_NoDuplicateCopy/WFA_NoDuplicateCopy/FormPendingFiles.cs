﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WFA_NoDuplicateCopy
{
    public partial class FormPendingFiles : Form
    {
        public FormPendingFiles()
        {
            InitializeComponent();
        }

        public int SameFNCount, similarFNCount;
        public ClassFileHelper.PendingFileInfo sameFNInfo = null;
        public ClassFileHelper.PendingFileInfo similarFNInfo = null;
        public bool isMovingFile;

        private void FormPendingFiles_Shown(object sender, EventArgs e)
        {
            groupBox_SameFN.Enabled = (SameFNCount > 0) ? true : false;
            groupBox_SimilarFN.Enabled = (similarFNCount > 0) ? true : false;

            checkBox_SameFNDoTheSame.Text = "Do the same for the rest " + SameFNCount + " items.";
            checkBox_SimilarFNDoTheSame.Text = "Do the same for the rest " + similarFNCount + " items.";

            label_SameFNSourceIsBigger.Visible
                = label_sameFN_sourceFileName.Visible
                = (groupBox_SameFN.Enabled && sameFNInfo.sourceFileInfo.Length > sameFNInfo.targetFileInfo.Length) ? true : false;
            if (label_SameFNSourceIsBigger.Visible == true)
            {
                label_SameFNSourceIsBigger.Text = "This Source is Bigger! (" + _GetSizeText(sameFNInfo.sourceFileInfo.Length) + " > " + _GetSizeText(sameFNInfo.targetFileInfo.Length) + ")";
                label_sameFN_sourceFileName.Text
                    = "About to " + (isMovingFile ? "Moving " : "Copying")
                    + "Source File: " + sameFNInfo.sourceFileInfo.Name;
            }
            label_SimilarFNSourceIsBigger.Visible
                = label_similarFN_sourceFileName.Visible
                = (groupBox_SimilarFN.Enabled == true && similarFNInfo.sourceFileInfo.Length > similarFNInfo.targetFileInfo.Length) ? true : false;
            if (label_SimilarFNSourceIsBigger.Visible == true)
            {
                label_SimilarFNSourceIsBigger.Text = "This Source is Bigger! (" + _GetSizeText(similarFNInfo.sourceFileInfo.Length) + " > " + _GetSizeText(similarFNInfo.targetFileInfo.Length) + ")";
                label_similarFN_sourceFileName.Text
                    = "About to " + (isMovingFile ? "Move " : "Copy ")
                    + "Source File: " + similarFNInfo.sourceFileInfo.Name;
            }

            this.Text = isMovingFile ? "Move Files" : "Copy Files";
        }
        private string _GetSizeText(long size)
        {
            int exp = 0;
            double tmp = (double)size;
            while (tmp >= 1024)
            {
                tmp /= 1024;
                exp++;
            }
            switch (exp)
            {
                case 0:
                    return tmp.ToString("#,##0") + " B";
                case 1:
                    return tmp.ToString("#,##0.00") + " KB";
                case 2:
                    return tmp.ToString("#,##0.00") + " MB";
                case 3:
                    return tmp.ToString("#,##0.00") + " GB";
                case 4:
                    return tmp.ToString("#,##0.00") + " TB";
                case 5:
                    return tmp.ToString("#,##0.00") + " JB";
                default:
                    return "Unknow Size !";
            }
        }

        private void label_MouseEnter(object sender, EventArgs e)
        {
            Label me = sender as Label;
            me.BackColor = SystemColors.ActiveCaption;
            me.ForeColor = SystemColors.ActiveCaptionText;
        }

        private void label_MouseLeave(object sender, EventArgs e)
        {
            Label me = sender as Label;
            me.BackColor = SystemColors.Control;
            me.ForeColor = SystemColors.ControlText;
            me.BorderStyle = BorderStyle.FixedSingle;
        }

        private void label_MouseDown(object sender, MouseEventArgs e)
        {
            Label me = sender as Label;
            me.BorderStyle = BorderStyle.Fixed3D;
        }
        /// <summary>
        /// SameFN 0leave 1replace 2rename; SimilarFN 3leave 4replace 5rename
        /// </summary>
        public int actionSameFNTag = 0;
        private void label_MouseUp(object sender, MouseEventArgs e)
        {
            Label me = sender as Label;
            string labelName = me.Name;
            if (me.BorderStyle == BorderStyle.Fixed3D)
            {
                switch (labelName.ToLower())
                {
                    case "label_samefnreplace":
                        actionSameFNTag = 1;
                        break;
                    case "label_samefnleave":
                        actionSameFNTag = 0;
                        break;
                    case "label_samefnrename":
                        actionSameFNTag = 2;
                        break;
                    case "label_similarfnreplace":
                        actionSameFNTag = 4;
                        break;
                    case "label_similarfnleave":
                        actionSameFNTag = 3;
                        break;
                    case "label_similarfnrename":
                        actionSameFNTag = 5;
                        break;
                }
            }
            me.BorderStyle = BorderStyle.FixedSingle;
            this.Hide();
        }
    }
}
