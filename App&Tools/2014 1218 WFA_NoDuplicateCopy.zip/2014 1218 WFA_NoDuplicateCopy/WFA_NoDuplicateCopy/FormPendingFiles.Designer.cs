﻿namespace WFA_NoDuplicateCopy
{
    partial class FormPendingFiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_SameFN = new System.Windows.Forms.GroupBox();
            this.checkBox_SameFNDoTheSame = new System.Windows.Forms.CheckBox();
            this.label_SameFNRename = new System.Windows.Forms.Label();
            this.label_SameFNLeave = new System.Windows.Forms.Label();
            this.label_SameFNReplace = new System.Windows.Forms.Label();
            this.groupBox_SimilarFN = new System.Windows.Forms.GroupBox();
            this.checkBox_SimilarFNDoTheSame = new System.Windows.Forms.CheckBox();
            this.label_SimilarFNRename = new System.Windows.Forms.Label();
            this.label_SimilarFNLeave = new System.Windows.Forms.Label();
            this.label_SimilarFNReplace = new System.Windows.Forms.Label();
            this.label_SameFNSourceIsBigger = new System.Windows.Forms.Label();
            this.label_SimilarFNSourceIsBigger = new System.Windows.Forms.Label();
            this.label_sameFN_sourceFileName = new System.Windows.Forms.Label();
            this.label_similarFN_sourceFileName = new System.Windows.Forms.Label();
            this.groupBox_SameFN.SuspendLayout();
            this.groupBox_SimilarFN.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_SameFN
            // 
            this.groupBox_SameFN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_SameFN.Controls.Add(this.label_sameFN_sourceFileName);
            this.groupBox_SameFN.Controls.Add(this.label_SameFNSourceIsBigger);
            this.groupBox_SameFN.Controls.Add(this.checkBox_SameFNDoTheSame);
            this.groupBox_SameFN.Controls.Add(this.label_SameFNRename);
            this.groupBox_SameFN.Controls.Add(this.label_SameFNLeave);
            this.groupBox_SameFN.Controls.Add(this.label_SameFNReplace);
            this.groupBox_SameFN.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox_SameFN.Location = new System.Drawing.Point(12, 12);
            this.groupBox_SameFN.Name = "groupBox_SameFN";
            this.groupBox_SameFN.Size = new System.Drawing.Size(638, 234);
            this.groupBox_SameFN.TabIndex = 0;
            this.groupBox_SameFN.TabStop = false;
            this.groupBox_SameFN.Text = "Same File Name";
            // 
            // checkBox_SameFNDoTheSame
            // 
            this.checkBox_SameFNDoTheSame.AutoSize = true;
            this.checkBox_SameFNDoTheSame.Location = new System.Drawing.Point(6, 189);
            this.checkBox_SameFNDoTheSame.Name = "checkBox_SameFNDoTheSame";
            this.checkBox_SameFNDoTheSame.Size = new System.Drawing.Size(384, 31);
            this.checkBox_SameFNDoTheSame.TabIndex = 1;
            this.checkBox_SameFNDoTheSame.Text = "Do the same for the rest ### items";
            this.checkBox_SameFNDoTheSame.UseVisualStyleBackColor = true;
            // 
            // label_SameFNRename
            // 
            this.label_SameFNRename.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SameFNRename.Location = new System.Drawing.Point(418, 57);
            this.label_SameFNRename.Name = "label_SameFNRename";
            this.label_SameFNRename.Size = new System.Drawing.Size(200, 100);
            this.label_SameFNRename.TabIndex = 0;
            this.label_SameFNRename.Text = "ReName it";
            this.label_SameFNRename.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_SameFNRename.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_MouseDown);
            this.label_SameFNRename.MouseEnter += new System.EventHandler(this.label_MouseEnter);
            this.label_SameFNRename.MouseLeave += new System.EventHandler(this.label_MouseLeave);
            this.label_SameFNRename.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_MouseUp);
            // 
            // label_SameFNLeave
            // 
            this.label_SameFNLeave.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SameFNLeave.Location = new System.Drawing.Point(212, 57);
            this.label_SameFNLeave.Name = "label_SameFNLeave";
            this.label_SameFNLeave.Size = new System.Drawing.Size(200, 100);
            this.label_SameFNLeave.TabIndex = 0;
            this.label_SameFNLeave.Text = "Leave it";
            this.label_SameFNLeave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_SameFNLeave.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_MouseDown);
            this.label_SameFNLeave.MouseEnter += new System.EventHandler(this.label_MouseEnter);
            this.label_SameFNLeave.MouseLeave += new System.EventHandler(this.label_MouseLeave);
            this.label_SameFNLeave.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_MouseUp);
            // 
            // label_SameFNReplace
            // 
            this.label_SameFNReplace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SameFNReplace.Location = new System.Drawing.Point(6, 57);
            this.label_SameFNReplace.Name = "label_SameFNReplace";
            this.label_SameFNReplace.Size = new System.Drawing.Size(200, 100);
            this.label_SameFNReplace.TabIndex = 0;
            this.label_SameFNReplace.Text = "Replace it";
            this.label_SameFNReplace.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_SameFNReplace.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_MouseDown);
            this.label_SameFNReplace.MouseEnter += new System.EventHandler(this.label_MouseEnter);
            this.label_SameFNReplace.MouseLeave += new System.EventHandler(this.label_MouseLeave);
            this.label_SameFNReplace.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_MouseUp);
            // 
            // groupBox_SimilarFN
            // 
            this.groupBox_SimilarFN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_SimilarFN.Controls.Add(this.label_similarFN_sourceFileName);
            this.groupBox_SimilarFN.Controls.Add(this.label_SimilarFNSourceIsBigger);
            this.groupBox_SimilarFN.Controls.Add(this.checkBox_SimilarFNDoTheSame);
            this.groupBox_SimilarFN.Controls.Add(this.label_SimilarFNRename);
            this.groupBox_SimilarFN.Controls.Add(this.label_SimilarFNLeave);
            this.groupBox_SimilarFN.Controls.Add(this.label_SimilarFNReplace);
            this.groupBox_SimilarFN.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox_SimilarFN.Location = new System.Drawing.Point(12, 252);
            this.groupBox_SimilarFN.Name = "groupBox_SimilarFN";
            this.groupBox_SimilarFN.Size = new System.Drawing.Size(638, 234);
            this.groupBox_SimilarFN.TabIndex = 2;
            this.groupBox_SimilarFN.TabStop = false;
            this.groupBox_SimilarFN.Text = "Similar File Name";
            // 
            // checkBox_SimilarFNDoTheSame
            // 
            this.checkBox_SimilarFNDoTheSame.AutoSize = true;
            this.checkBox_SimilarFNDoTheSame.Location = new System.Drawing.Point(6, 189);
            this.checkBox_SimilarFNDoTheSame.Name = "checkBox_SimilarFNDoTheSame";
            this.checkBox_SimilarFNDoTheSame.Size = new System.Drawing.Size(384, 31);
            this.checkBox_SimilarFNDoTheSame.TabIndex = 1;
            this.checkBox_SimilarFNDoTheSame.Text = "Do the same for the rest ### items";
            this.checkBox_SimilarFNDoTheSame.UseVisualStyleBackColor = true;
            // 
            // label_SimilarFNRename
            // 
            this.label_SimilarFNRename.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SimilarFNRename.Location = new System.Drawing.Point(418, 57);
            this.label_SimilarFNRename.Name = "label_SimilarFNRename";
            this.label_SimilarFNRename.Size = new System.Drawing.Size(200, 100);
            this.label_SimilarFNRename.TabIndex = 0;
            this.label_SimilarFNRename.Text = "ReName it";
            this.label_SimilarFNRename.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_SimilarFNRename.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_MouseDown);
            this.label_SimilarFNRename.MouseEnter += new System.EventHandler(this.label_MouseEnter);
            this.label_SimilarFNRename.MouseLeave += new System.EventHandler(this.label_MouseLeave);
            this.label_SimilarFNRename.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_MouseUp);
            // 
            // label_SimilarFNLeave
            // 
            this.label_SimilarFNLeave.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SimilarFNLeave.Location = new System.Drawing.Point(212, 57);
            this.label_SimilarFNLeave.Name = "label_SimilarFNLeave";
            this.label_SimilarFNLeave.Size = new System.Drawing.Size(200, 100);
            this.label_SimilarFNLeave.TabIndex = 0;
            this.label_SimilarFNLeave.Text = "Leave it";
            this.label_SimilarFNLeave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_SimilarFNLeave.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_MouseDown);
            this.label_SimilarFNLeave.MouseEnter += new System.EventHandler(this.label_MouseEnter);
            this.label_SimilarFNLeave.MouseLeave += new System.EventHandler(this.label_MouseLeave);
            this.label_SimilarFNLeave.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_MouseUp);
            // 
            // label_SimilarFNReplace
            // 
            this.label_SimilarFNReplace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SimilarFNReplace.Location = new System.Drawing.Point(6, 57);
            this.label_SimilarFNReplace.Name = "label_SimilarFNReplace";
            this.label_SimilarFNReplace.Size = new System.Drawing.Size(200, 100);
            this.label_SimilarFNReplace.TabIndex = 0;
            this.label_SimilarFNReplace.Text = "Replace it";
            this.label_SimilarFNReplace.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_SimilarFNReplace.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_MouseDown);
            this.label_SimilarFNReplace.MouseEnter += new System.EventHandler(this.label_MouseEnter);
            this.label_SimilarFNReplace.MouseLeave += new System.EventHandler(this.label_MouseLeave);
            this.label_SimilarFNReplace.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_MouseUp);
            // 
            // label_SameFNSourceIsBigger
            // 
            this.label_SameFNSourceIsBigger.AutoSize = true;
            this.label_SameFNSourceIsBigger.Location = new System.Drawing.Point(6, 30);
            this.label_SameFNSourceIsBigger.Name = "label_SameFNSourceIsBigger";
            this.label_SameFNSourceIsBigger.Size = new System.Drawing.Size(73, 27);
            this.label_SameFNSourceIsBigger.TabIndex = 2;
            this.label_SameFNSourceIsBigger.Text = "label1";
            // 
            // label_SimilarFNSourceIsBigger
            // 
            this.label_SimilarFNSourceIsBigger.AutoSize = true;
            this.label_SimilarFNSourceIsBigger.Location = new System.Drawing.Point(6, 30);
            this.label_SimilarFNSourceIsBigger.Name = "label_SimilarFNSourceIsBigger";
            this.label_SimilarFNSourceIsBigger.Size = new System.Drawing.Size(73, 27);
            this.label_SimilarFNSourceIsBigger.TabIndex = 2;
            this.label_SimilarFNSourceIsBigger.Text = "label1";
            // 
            // label_sameFN_sourceFileName
            // 
            this.label_sameFN_sourceFileName.AutoSize = true;
            this.label_sameFN_sourceFileName.Font = new System.Drawing.Font("微软雅黑", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_sameFN_sourceFileName.Location = new System.Drawing.Point(6, 167);
            this.label_sameFN_sourceFileName.Name = "label_sameFN_sourceFileName";
            this.label_sameFN_sourceFileName.Size = new System.Drawing.Size(54, 19);
            this.label_sameFN_sourceFileName.TabIndex = 3;
            this.label_sameFN_sourceFileName.Text = "label1";
            // 
            // label_similarFN_sourceFileName
            // 
            this.label_similarFN_sourceFileName.AutoSize = true;
            this.label_similarFN_sourceFileName.Font = new System.Drawing.Font("微软雅黑", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_similarFN_sourceFileName.Location = new System.Drawing.Point(6, 167);
            this.label_similarFN_sourceFileName.Name = "label_similarFN_sourceFileName";
            this.label_similarFN_sourceFileName.Size = new System.Drawing.Size(54, 19);
            this.label_similarFN_sourceFileName.TabIndex = 3;
            this.label_similarFN_sourceFileName.Text = "label2";
            // 
            // FormPendingFiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 514);
            this.Controls.Add(this.groupBox_SimilarFN);
            this.Controls.Add(this.groupBox_SameFN);
            this.Name = "FormPendingFiles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormPendingFiles";
            this.Shown += new System.EventHandler(this.FormPendingFiles_Shown);
            this.groupBox_SameFN.ResumeLayout(false);
            this.groupBox_SameFN.PerformLayout();
            this.groupBox_SimilarFN.ResumeLayout(false);
            this.groupBox_SimilarFN.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_SameFN;
        private System.Windows.Forms.Label label_SameFNRename;
        private System.Windows.Forms.Label label_SameFNLeave;
        private System.Windows.Forms.Label label_SameFNReplace;
        public System.Windows.Forms.CheckBox checkBox_SameFNDoTheSame;
        private System.Windows.Forms.GroupBox groupBox_SimilarFN;
        public System.Windows.Forms.CheckBox checkBox_SimilarFNDoTheSame;
        private System.Windows.Forms.Label label_SimilarFNRename;
        private System.Windows.Forms.Label label_SimilarFNLeave;
        private System.Windows.Forms.Label label_SimilarFNReplace;
        private System.Windows.Forms.Label label_sameFN_sourceFileName;
        private System.Windows.Forms.Label label_SameFNSourceIsBigger;
        private System.Windows.Forms.Label label_similarFN_sourceFileName;
        private System.Windows.Forms.Label label_SimilarFNSourceIsBigger;
    }
}