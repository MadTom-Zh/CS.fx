﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Threading;

namespace WFA_NoDuplicateCopy
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private static string INIFileName = Application.StartupPath + "\\" + "userData.ini";
        private static string INISectionLastRecord = "LastRecord";
        private static string INISectionLastRecord_KeyFolderPath = "FolderPath";
        private static string INISectionLastRecord_KeyIsCheckContain = "IsCheckContain";
        private void SettingLoad()
        {
            if (File.Exists(INIFileName))
            {
                string[] keys;
                string[] values;
                ClassINIHelper.GetAllKeyValues(INISectionLastRecord, out keys, out values, INIFileName);
                string key, value;
                for (int idx = keys.Length - 1; idx >= 0; idx--)
                {
                    key = keys[idx];
                    if (key == INISectionLastRecord_KeyFolderPath)
                    {
                        value = values[idx];
                        if (Directory.Exists(value))
                        {
                            textBox_folderPath.Text = value;
                            folderBrowserDialog.SelectedPath = value;
                        }
                    }
                    else if (key == INISectionLastRecord_KeyIsCheckContain)
                    {
                        checkBox_optionContainCheck.Checked = bool.Parse(values[idx]);
                    }
                }
            }
        }
        private void SettingSave()
        {
            ClassINIHelper.Write(INISectionLastRecord,
                INISectionLastRecord_KeyFolderPath,
                textBox_folderPath.Text,
                INIFileName);
            ClassINIHelper.Write(INISectionLastRecord,
                INISectionLastRecord_KeyIsCheckContain,
                checkBox_optionContainCheck.Checked.ToString(),
                INIFileName);
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            SettingLoad();
        }
        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            SettingSave();
        }

        private void button_about_Click(object sender, EventArgs e)
        {
            FormAbout aboutForm = new FormAbout();
            aboutForm.ShowDialog(this);
        }

        private void button_folderPathBrowse_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == folderBrowserDialog.ShowDialog(this))
            {
                textBox_folderPath.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void textBox_dropZone_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop) == false)
            {
                e.Effect = DragDropEffects.None;
                return;
            }
            //[Bit  键]
            //1  鼠标左按钮。
            //2  鼠标右按钮。
            //4  Shift 键。
            //8  CTL 键。
            //16  鼠标中键。
            //32  Alt 键。 
            if ((e.KeyState & 4) == 4)
            {
                e.Effect = DragDropEffects.Move;
            }
            else if ((e.KeyState & 8) == 8)
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                string[] fileObj = e.Data.GetData(DataFormats.FileDrop, true) as string[];
                string targetFolderPath = textBox_folderPath.Text;
                string firstFileFullName = fileObj[0];
                if (firstFileFullName.Substring(0, firstFileFullName.IndexOf(':'))
                    == targetFolderPath.Substring(0, targetFolderPath.IndexOf(':')))
                {
                    e.Effect = DragDropEffects.Move;
                }
                else
                {
                    e.Effect = DragDropEffects.Copy;
                }
            }
        }

        ClassFileHelper fileHelper = new ClassFileHelper();
        public List<FileInfo> fileSource;
        public bool isMoveFiles = false;
        private void textBox_dropZone_DragDrop(object sender, DragEventArgs e)
        {
            fileSource = new List<FileInfo>();
            fileSource.Clear();
            foreach (string str in e.Data.GetData("FileDrop") as string[])
            {
                fileSource.Add(new FileInfo(str));
            }

            if (e.Effect == DragDropEffects.Move)
            {
                isMoveFiles = true;
                fileHelper.Start(this);
            }
            else if (e.Effect == DragDropEffects.Copy)
            {
                isMoveFiles = false;
                fileHelper.Start(this);
            }
        }

        private void button_abort_Click(object sender, EventArgs e)
        {
            fileHelper.Abort();
        }
    }
}
