﻿namespace MadTomDev.App.Ctrls
{
    partial class ColorButton
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_clr = new System.Windows.Forms.PictureBox();
            this.textBox_clrName = new System.Windows.Forms.TextBox();
            this.textBox_clrCode = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_clr)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_clr
            // 
            this.pictureBox_clr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox_clr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_clr.Location = new System.Drawing.Point(8, 8);
            this.pictureBox_clr.Name = "pictureBox_clr";
            this.pictureBox_clr.Size = new System.Drawing.Size(90, 58);
            this.pictureBox_clr.TabIndex = 0;
            this.pictureBox_clr.TabStop = false;
            this.pictureBox_clr.Click += new System.EventHandler(this.pictureBox_clr_Click);
            // 
            // textBox_clrName
            // 
            this.textBox_clrName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_clrName.BackColor = System.Drawing.SystemColors.Control;
            this.textBox_clrName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_clrName.Location = new System.Drawing.Point(109, 18);
            this.textBox_clrName.Name = "textBox_clrName";
            this.textBox_clrName.Size = new System.Drawing.Size(132, 13);
            this.textBox_clrName.TabIndex = 1;
            this.textBox_clrName.Click += new System.EventHandler(this.textBox_clrName_Click);
            // 
            // textBox_clrCode
            // 
            this.textBox_clrCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_clrCode.BackColor = System.Drawing.SystemColors.Control;
            this.textBox_clrCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_clrCode.Location = new System.Drawing.Point(109, 39);
            this.textBox_clrCode.Name = "textBox_clrCode";
            this.textBox_clrCode.Size = new System.Drawing.Size(132, 13);
            this.textBox_clrCode.TabIndex = 2;
            this.textBox_clrCode.Click += new System.EventHandler(this.textBox_clrCode_Click);
            // 
            // ColorButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textBox_clrCode);
            this.Controls.Add(this.textBox_clrName);
            this.Controls.Add(this.pictureBox_clr);
            this.Name = "ColorButton";
            this.Size = new System.Drawing.Size(244, 74);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ColorButton_MouseClick);
            this.MouseEnter += new System.EventHandler(this.ColorButton_MouseEnter);
            this.MouseLeave += new System.EventHandler(this.ColorButton_MouseLeave);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_clr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_clr;
        private System.Windows.Forms.TextBox textBox_clrName;
        private System.Windows.Forms.TextBox textBox_clrCode;
    }
}
