﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.Ctrls
{
    public partial class ColorButton : UserControl
    {
        public ColorButton()
        {
            InitializeComponent();
        }

        public string ColorName
        {
            get => textBox_clrName.Text;
            set => textBox_clrName.Text = value;
        }
        private Color _Color;
        public Color Color
        {
            get => _Color;
            set
            {
                _Color = value;
                pictureBox_clr.BackColor = value;
                textBox_clrCode.Text = value.ToString();
            }
        }


        #region 

        private void ColorButton_MouseEnter(object sender, EventArgs e)
        {
            if (!_IsChecked)
                this.BorderStyle = BorderStyle.FixedSingle;
        }

        private void ColorButton_MouseLeave(object sender, EventArgs e)
        {
            if (!_IsChecked)
            {
                Point mp = this.PointToClient(MousePosition);
                if (mp.X <= 0 || this.Width - 2 <= mp.X
                    || mp.Y <= 0 || this.Height - 2 <= mp.Y)
                    this.BorderStyle = BorderStyle.None;
            }
        }
        private bool _IsChecked = false;
        public bool IsChecked
        {
            get => _IsChecked;
            set
            {
                _IsChecked = value;
                if (_IsChecked)
                    this.BorderStyle = BorderStyle.Fixed3D;
                else
                    this.BorderStyle = BorderStyle.None;
            }
        }

        public event Action<ColorButton> Clicked;
        private void ColorButton_MouseClick(object sender, MouseEventArgs e)
        {
            Clicked?.Invoke(this);
        }
        private void pictureBox_clr_Click(object sender, EventArgs e)
        {
            Clicked?.Invoke(this);
        }
        private void textBox_clrName_Click(object sender, EventArgs e)
        {
            Clicked?.Invoke(this);
        }
        private void textBox_clrCode_Click(object sender, EventArgs e)
        {
            Clicked?.Invoke(this);
        }

        #endregion

    }
}
