﻿namespace MadTomDev.App
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.flowLayoutPanel_curtainRBtns = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButton_templete = new System.Windows.Forms.RadioButton();
            this.button_addStd = new System.Windows.Forms.Button();
            this.button_addWnd = new System.Windows.Forms.Button();
            this.groupBox_properties = new System.Windows.Forms.GroupBox();
            this.button_closeRemove = new System.Windows.Forms.Button();
            this.label_curtainName = new System.Windows.Forms.Label();
            this.textBox_opacity = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_isMinimized = new System.Windows.Forms.CheckBox();
            this.checkBox_topMost = new System.Windows.Forms.CheckBox();
            this.trackBar_opacity = new System.Windows.Forms.TrackBar();
            this.label_about = new System.Windows.Forms.Label();
            this.timerMain = new System.Windows.Forms.Timer(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.flowLayoutPanel_curtainRBtns.SuspendLayout();
            this.groupBox_properties.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_opacity)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel_curtainRBtns
            // 
            this.flowLayoutPanel_curtainRBtns.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel_curtainRBtns.AutoSize = true;
            this.flowLayoutPanel_curtainRBtns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel_curtainRBtns.Controls.Add(this.radioButton_templete);
            this.flowLayoutPanel_curtainRBtns.Location = new System.Drawing.Point(12, 67);
            this.flowLayoutPanel_curtainRBtns.Name = "flowLayoutPanel_curtainRBtns";
            this.flowLayoutPanel_curtainRBtns.Size = new System.Drawing.Size(608, 371);
            this.flowLayoutPanel_curtainRBtns.TabIndex = 0;
            // 
            // radioButton_templete
            // 
            this.radioButton_templete.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton_templete.AutoSize = true;
            this.radioButton_templete.Image = ((System.Drawing.Image)(resources.GetObject("radioButton_templete.Image")));
            this.radioButton_templete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.radioButton_templete.Location = new System.Drawing.Point(3, 3);
            this.radioButton_templete.Name = "radioButton_templete";
            this.radioButton_templete.Size = new System.Drawing.Size(84, 38);
            this.radioButton_templete.TabIndex = 0;
            this.radioButton_templete.TabStop = true;
            this.radioButton_templete.Text = "BC 001";
            this.radioButton_templete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.radioButton_templete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.radioButton_templete.UseVisualStyleBackColor = true;
            // 
            // button_addStd
            // 
            this.button_addStd.Location = new System.Drawing.Point(12, 12);
            this.button_addStd.Name = "button_addStd";
            this.button_addStd.Size = new System.Drawing.Size(119, 49);
            this.button_addStd.TabIndex = 1;
            this.button_addStd.Text = "Add Standard";
            this.button_addStd.UseVisualStyleBackColor = true;
            this.button_addStd.Click += new System.EventHandler(this.button_addStd_Click);
            // 
            // button_addWnd
            // 
            this.button_addWnd.Location = new System.Drawing.Point(137, 12);
            this.button_addWnd.Name = "button_addWnd";
            this.button_addWnd.Size = new System.Drawing.Size(119, 49);
            this.button_addWnd.TabIndex = 1;
            this.button_addWnd.Text = "Add Window...";
            this.button_addWnd.UseVisualStyleBackColor = true;
            this.button_addWnd.Click += new System.EventHandler(this.button_addWnd_Click);
            // 
            // groupBox_properties
            // 
            this.groupBox_properties.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_properties.Controls.Add(this.button_closeRemove);
            this.groupBox_properties.Controls.Add(this.label_curtainName);
            this.groupBox_properties.Controls.Add(this.textBox_opacity);
            this.groupBox_properties.Controls.Add(this.label1);
            this.groupBox_properties.Controls.Add(this.checkBox_isMinimized);
            this.groupBox_properties.Controls.Add(this.checkBox_topMost);
            this.groupBox_properties.Controls.Add(this.trackBar_opacity);
            this.groupBox_properties.Enabled = false;
            this.groupBox_properties.Location = new System.Drawing.Point(626, 67);
            this.groupBox_properties.Name = "groupBox_properties";
            this.groupBox_properties.Size = new System.Drawing.Size(162, 371);
            this.groupBox_properties.TabIndex = 2;
            this.groupBox_properties.TabStop = false;
            this.groupBox_properties.Text = "Curtain Properties";
            // 
            // button_closeRemove
            // 
            this.button_closeRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_closeRemove.Location = new System.Drawing.Point(73, 321);
            this.button_closeRemove.Name = "button_closeRemove";
            this.button_closeRemove.Size = new System.Drawing.Size(83, 42);
            this.button_closeRemove.TabIndex = 6;
            this.button_closeRemove.Text = "Close or\r\nRemove";
            this.button_closeRemove.UseVisualStyleBackColor = true;
            this.button_closeRemove.Click += new System.EventHandler(this.button_closeRemove_Click);
            // 
            // label_curtainName
            // 
            this.label_curtainName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_curtainName.AutoEllipsis = true;
            this.label_curtainName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_curtainName.Location = new System.Drawing.Point(6, 21);
            this.label_curtainName.Name = "label_curtainName";
            this.label_curtainName.Size = new System.Drawing.Size(150, 11);
            this.label_curtainName.TabIndex = 5;
            this.label_curtainName.Text = "curtain name sdag  asgaseg  sgsag";
            // 
            // textBox_opacity
            // 
            this.textBox_opacity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_opacity.Location = new System.Drawing.Point(73, 87);
            this.textBox_opacity.Name = "textBox_opacity";
            this.textBox_opacity.Size = new System.Drawing.Size(83, 20);
            this.textBox_opacity.TabIndex = 4;
            this.textBox_opacity.TextChanged += new System.EventHandler(this.textBox_opacity_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Opacity %";
            // 
            // checkBox_isMinimized
            // 
            this.checkBox_isMinimized.AutoSize = true;
            this.checkBox_isMinimized.Location = new System.Drawing.Point(6, 64);
            this.checkBox_isMinimized.Name = "checkBox_isMinimized";
            this.checkBox_isMinimized.Size = new System.Drawing.Size(83, 17);
            this.checkBox_isMinimized.TabIndex = 2;
            this.checkBox_isMinimized.Text = "Is Minimized";
            this.checkBox_isMinimized.UseVisualStyleBackColor = true;
            this.checkBox_isMinimized.CheckedChanged += new System.EventHandler(this.checkBox_isMinimized_CheckedChanged);
            // 
            // checkBox_topMost
            // 
            this.checkBox_topMost.AutoSize = true;
            this.checkBox_topMost.Location = new System.Drawing.Point(6, 41);
            this.checkBox_topMost.Name = "checkBox_topMost";
            this.checkBox_topMost.Size = new System.Drawing.Size(82, 17);
            this.checkBox_topMost.TabIndex = 1;
            this.checkBox_topMost.Text = "Is Top Most";
            this.checkBox_topMost.UseVisualStyleBackColor = true;
            this.checkBox_topMost.CheckedChanged += new System.EventHandler(this.checkBox_topMost_CheckedChanged);
            // 
            // trackBar_opacity
            // 
            this.trackBar_opacity.Location = new System.Drawing.Point(9, 115);
            this.trackBar_opacity.Maximum = 100;
            this.trackBar_opacity.Name = "trackBar_opacity";
            this.trackBar_opacity.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar_opacity.Size = new System.Drawing.Size(45, 250);
            this.trackBar_opacity.TabIndex = 0;
            this.trackBar_opacity.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_opacity.Value = 100;
            this.trackBar_opacity.Scroll += new System.EventHandler(this.trackBar_opacity_Scroll);
            // 
            // label_about
            // 
            this.label_about.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_about.AutoSize = true;
            this.label_about.Location = new System.Drawing.Point(650, 9);
            this.label_about.Name = "label_about";
            this.label_about.Size = new System.Drawing.Size(138, 26);
            this.label_about.TabIndex = 3;
            this.label_about.Text = "Create by longtombbj\r\nEmail: 357716599@qq.com";
            this.label_about.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // timerMain
            // 
            this.timerMain.Enabled = true;
            this.timerMain.Interval = 500;
            this.timerMain.Tick += new System.EventHandler(this.timerMain_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_about);
            this.Controls.Add(this.groupBox_properties);
            this.Controls.Add(this.button_addWnd);
            this.Controls.Add(this.button_addStd);
            this.Controls.Add(this.flowLayoutPanel_curtainRBtns);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "BlackCurtains  by MadTom 2023 0522";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.flowLayoutPanel_curtainRBtns.ResumeLayout(false);
            this.flowLayoutPanel_curtainRBtns.PerformLayout();
            this.groupBox_properties.ResumeLayout(false);
            this.groupBox_properties.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_opacity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_curtainRBtns;
        private System.Windows.Forms.Button button_addStd;
        private System.Windows.Forms.Button button_addWnd;
        private System.Windows.Forms.GroupBox groupBox_properties;
        private System.Windows.Forms.Label label_about;
        private System.Windows.Forms.RadioButton radioButton_templete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox_isMinimized;
        private System.Windows.Forms.CheckBox checkBox_topMost;
        private System.Windows.Forms.TrackBar trackBar_opacity;
        private System.Windows.Forms.TextBox textBox_opacity;
        private System.Windows.Forms.Label label_curtainName;
        private System.Windows.Forms.Button button_closeRemove;
        private System.Windows.Forms.Timer timerMain;
        private System.Windows.Forms.ToolTip toolTip;
    }
}