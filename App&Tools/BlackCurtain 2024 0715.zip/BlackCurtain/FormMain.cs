﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation;
using System.Windows.Forms;

using MadTomDev.Resources;

namespace MadTomDev.App
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        public string Tx_toolTip_CloseBCRemoveOW = "Close a standard BlackCurtain,\r\nor remove the control of the outer window.";
        public string Tx_toolTip_CantTopMost = "Can't toggle, this window auto restore the TopMost property.";

        private RadioButton standardBCRBtnTemplete;
        private void FormMain_Load(object sender, EventArgs e)
        {
            standardBCRBtnTemplete = (RadioButton)flowLayoutPanel_curtainRBtns.Controls[0];
            flowLayoutPanel_curtainRBtns.Controls.Clear();

            string shellIconFileFullName = Application.StartupPath + "Polish-Cloth-shell.ico";
            if (File.Exists(shellIconFileFullName))
            {
                iconShell = new Icon(shellIconFileFullName);
            }

            toolTip.SetToolTip(button_closeRemove, Tx_toolTip_CloseBCRemoveOW);
        }

        private void FormMain_Shown(object sender, EventArgs e)
        {
            //button_addStd_Click(null, null);
        }

        private class RBtnTagData
        {
            public FormCurtain standardBC;
            public IntPtr outerWndHandle;
            public bool outerWndRestoreTopMost = false;
            public DateTime outerWndTopMost_setTime = DateTime.MinValue;
            public bool outerWndTopMost_setValue;
        }
        private static Icon iconShell = null;
        private static int curtainNo = 1;
        private void button_addStd_Click(object sender, EventArgs e)
        {
            FormCurtain newBC = MakeFromBlackCurtain();
            RadioButton rb = MakeRBtn_Standard(newBC);
            flowLayoutPanel_curtainRBtns.Controls.Add(rb);
            newBC.Show();
            rb.Checked = true;
        }
        private FormCurtain MakeFromBlackCurtain()
        {
            FormCurtain result = new FormCurtain();
            result.titleOrigin = "BC " + (curtainNo++).ToString();
            if (iconShell != null) result.iconShell = iconShell;
            result.CallNewOne += (s1, e1) =>
            {
                button_addStd_Click(null, null);
            };
            result.FormClosed += (s2, e2) =>
            {
                FormCurtain curFC = (FormCurtain)s2;
                if (curFC == curSelectedRBT.standardBC)
                {
                    curSelectedRBT.standardBC = null;
                    LoadSelectedStandardBCInfo();
                }
                RadioButton rBtn = (RadioButton)curFC.Tag;
                flowLayoutPanel_curtainRBtns.Controls.Remove(rBtn);
                if (flowLayoutPanel_curtainRBtns.Controls.Count == 0)
                {
                    if (WindowState == FormWindowState.Minimized)
                        WindowState = FormWindowState.Normal;
                    this.Focus();
                }
            };
            return result;
        }
        private RadioButton MakeRBtn_Standard(FormCurtain formBC)
        {
            RadioButton result = UIs.ControlCloner.CloneControlGeneral(standardBCRBtnTemplete);
            RBtnTagData rbTag = new RBtnTagData()
            { standardBC = formBC };
            result.Tag = rbTag;
            formBC.Tag = result;
            result.Image = formBC.Icon.ToBitmap();
            result.Text = formBC.titleOrigin;
            result.CheckedChanged += (s3, e3) =>
            {
                curSelectedRB = (RadioButton)s3;
                curSelectedRBT = (RBtnTagData)curSelectedRB.Tag;
                LoadSelectedStandardBCInfo();
            };
            result.MouseDown += (s4, e4) =>
            {
                RadioButton targetRB = (RadioButton)s4;
                if (targetRB.Checked)
                {
                    if (e4.Button == MouseButtons.Right)
                    {
                        checkBox_isMinimized.Checked = false;
                        curSelectedRBT.standardBC.Focus();
                    }
                    label_curtainName.Text = curSelectedRBT.standardBC.Text;
                }
            };
            return result;
        }
        private RadioButton MakeRBtn_outerWindow(IntPtr hWnd)
        {
            RadioButton result = UIs.ControlCloner.CloneControlGeneral(standardBCRBtnTemplete);
            RBtnTagData rbTag = new RBtnTagData()
            { outerWndHandle = hWnd };
            result.Tag = rbTag;
            result.Image = CSharpUser32.OuterWindow.GetWindowIcon32(hWnd);
            result.Text = CSharpUser32.OuterWindow.GetWindowText(hWnd);
            result.CheckedChanged += (s3, e3) =>
            {
                curSelectedRB = (RadioButton)s3;
                curSelectedRBT = (RBtnTagData)curSelectedRB.Tag;
                LoadSelectedStandardBCInfo();
            };
            result.MouseDown += (s4, e4) =>
            {
                RadioButton targetRB = (RadioButton)s4;
                if (targetRB.Checked)
                {
                    if (e4.Button == MouseButtons.Right)
                    {
                        checkBox_isMinimized.Checked = false;
                        CSharpUser32.OuterWindow.ShowWindow(curSelectedRBT.outerWndHandle);
                    }
                }
            };
            return result;
        }

        private RadioButton curSelectedRB;
        private RBtnTagData curSelectedRBT;
        private void LoadSelectedStandardBCInfo()
        {
            if (curSelectedRBT.standardBC == null && curSelectedRBT.outerWndHandle == IntPtr.Zero)
            {
                groupBox_properties.Enabled = false;
                return;
            }

            checkBox_topMost.Enabled = true;
            groupBox_properties.Enabled = true;
            ignorePropertiesUIChanging = true;
            if (curSelectedRBT.standardBC != null)
            {
                label_curtainName.Text = curSelectedRBT.standardBC.Text;
                checkBox_topMost.Checked = curSelectedRBT.standardBC.TopMost;
                checkBox_isMinimized.Checked = curSelectedRBT.standardBC.WindowState == FormWindowState.Minimized;
                trackBar_opacity.Value = (int)(curSelectedRBT.standardBC.Opacity * 100);
            }
            else if (curSelectedRBT.outerWndHandle != IntPtr.Zero)
            {
                checkBox_topMost.Enabled = !curSelectedRBT.outerWndRestoreTopMost;
                if (curSelectedRBT.outerWndRestoreTopMost)
                    toolTip.SetToolTip(checkBox_topMost, Tx_toolTip_CantTopMost);
                else
                    toolTip.SetToolTip(checkBox_topMost, null);
                label_curtainName.Text = CSharpUser32.OuterWindow.GetWindowText(curSelectedRBT.outerWndHandle);
                checkBox_topMost.Checked = CSharpUser32.OuterWindow.CheckWindowIsTopMost(curSelectedRBT.outerWndHandle);
                checkBox_isMinimized.Checked = CSharpUser32.OuterWindow.GetWindowState(curSelectedRBT.outerWndHandle) == FormWindowState.Minimized;
                double alpha;
                CSharpUser32.OuterWindow.GetWindowOpacity(curSelectedRBT.outerWndHandle, out alpha);
                trackBar_opacity.Value = (int)(alpha * 100);
            }
            textBox_opacity.Text = trackBar_opacity.Value.ToString();

            ignorePropertiesUIChanging = false;
        }

        private void button_addWnd_Click(object sender, EventArgs e)
        {
            using (FormWindowSelector ws = new FormWindowSelector())
            {
                if (ws.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        InitOuterCurtain(ws.SelectedWindowHandle);
                        RadioButton newRB = MakeRBtn_outerWindow(ws.SelectedWindowHandle);
                        flowLayoutPanel_curtainRBtns.Controls.Add(newRB);
                        newRB.Checked = true;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(this, err.Message, "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void InitOuterCurtain(IntPtr hWnd)
        {
            var element = AutomationElement.FromHandle(hWnd);
            Automation.AddAutomationEventHandler(
                WindowPattern.WindowClosedEvent, element,
                TreeScope.Subtree, (s1, e1) =>
                {
                    this.Invoke(new Action(() =>
                    {
                        RBtnTagData rbTag;
                        RadioButton rb;
                        for (int i = 0, iMax = flowLayoutPanel_curtainRBtns.Controls.Count; i < iMax; i++)
                        {
                            rb = (RadioButton)flowLayoutPanel_curtainRBtns.Controls[i];
                            rbTag = (RBtnTagData)rb.Tag;
                            if (rbTag.outerWndHandle == hWnd)
                            {
                                flowLayoutPanel_curtainRBtns.Controls.Remove(rb);
                                break;
                            }
                        }
                    }));
                });
            CSharpUser32.OuterWindow.SetWindowTopMost(hWnd, true);
        }

        #region change curtain properties


        private bool ignorePropertiesUIChanging = false;
        private void checkBox_topMost_CheckedChanged(object sender, EventArgs e)
        {
            if (ignorePropertiesUIChanging)
                return;

            if (curSelectedRBT.standardBC != null)
            {
                curSelectedRBT.standardBC.TopMost = checkBox_topMost.Checked;
            }
            else if (curSelectedRBT.outerWndHandle != IntPtr.Zero)
            {
                CSharpUser32.OuterWindow.SetWindowTopMost(
                    curSelectedRBT.outerWndHandle,
                    checkBox_topMost.Checked);
                curSelectedRBT.outerWndTopMost_setTime = DateTime.Now;
                curSelectedRBT.outerWndTopMost_setValue = checkBox_topMost.Checked;
            }
        }

        private void checkBox_isMinimized_CheckedChanged(object sender, EventArgs e)
        {
            if (ignorePropertiesUIChanging)
                return;

            if (curSelectedRBT.standardBC != null)
            {
                if (checkBox_isMinimized.Checked)
                {
                    curSelectedRBT.standardBC.WindowState = FormWindowState.Minimized;
                    //curSelectedBC.Hide();
                }
                else
                {
                    //curSelectedBC.Show();
                    curSelectedRBT.standardBC.WindowState = FormWindowState.Normal;
                }
            }
            else if (curSelectedRBT.outerWndHandle != IntPtr.Zero)
            {
                if (checkBox_isMinimized.Checked)
                {
                    CSharpUser32.OuterWindow.SetWindowState(curSelectedRBT.outerWndHandle, FormWindowState.Minimized);
                }
                else
                {
                    CSharpUser32.OuterWindow.SetWindowState(curSelectedRBT.outerWndHandle, FormWindowState.Normal);
                }
            }
        }

        private void textBox_opacity_TextChanged(object sender, EventArgs e)
        {
            if (ignorePropertiesUIChanging)
                return;

            ignorePropertiesUIChanging = true;
            try
            {
                double text2double = double.Parse(textBox_opacity.Text);
                double alpha = text2double / 100;
                if (curSelectedRBT.standardBC != null)
                {
                    curSelectedRBT.standardBC.Opacity = alpha;
                }
                else if (curSelectedRBT.outerWndHandle != IntPtr.Zero)
                {
                    // debug
                    byte oldAlpha;
                    CSharpUser32.OuterWindow.GetWindowOpacityByte(curSelectedRBT.outerWndHandle, out oldAlpha);
                    double oldDAlpha = 0;
                    CSharpUser32.OuterWindow.GetWindowOpacity(curSelectedRBT.outerWndHandle, out oldDAlpha);


                    CSharpUser32.OuterWindow.SetWindowOpacity(curSelectedRBT.outerWndHandle, alpha);
                }
                trackBar_opacity.Value = (int)text2double;
            }
            catch (Exception) { }
            ignorePropertiesUIChanging = false;
        }

        private void trackBar_opacity_Scroll(object sender, EventArgs e)
        {
            if (ignorePropertiesUIChanging)
                return;

            ignorePropertiesUIChanging = true;

            double newOpac = (double)trackBar_opacity.Value / 100;
            if (curSelectedRBT.standardBC != null)
            {
                curSelectedRBT.standardBC.Opacity = newOpac;
            }
            else if (curSelectedRBT.outerWndHandle != IntPtr.Zero)
            {
                CSharpUser32.OuterWindow.SetWindowOpacity(curSelectedRBT.outerWndHandle, newOpac);
            }
            textBox_opacity.Text = trackBar_opacity.Value.ToString();

            ignorePropertiesUIChanging = false;
        }


        private void button_closeRemove_Click(object sender, EventArgs e)
        {
            if (curSelectedRBT.standardBC != null)
            {
                curSelectedRBT.standardBC.Close();
            }
            else if (curSelectedRBT.outerWndHandle != IntPtr.Zero)
            {
                flowLayoutPanel_curtainRBtns.Controls.Remove(curSelectedRB);
                curSelectedRB.Dispose();
            }




        }

        #endregion

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            RBtnTagData tagData;
            foreach (Control ctrl in flowLayoutPanel_curtainRBtns.Controls)
            {
                if (ctrl is RadioButton)
                {
                    tagData = (RBtnTagData)((RadioButton)ctrl).Tag;
                    if (tagData.outerWndHandle != IntPtr.Zero)
                    {
                        CSharpUser32.OuterWindow.SetWindowTopMost(tagData.outerWndHandle, false);
                        CSharpUser32.OuterWindow.SetWindowOpacityByte(tagData.outerWndHandle, 255);
                    }
                }
            }
        }

        private void timerMain_Tick(object sender, EventArgs e)
        {
            if (curSelectedRBT != null
                && curSelectedRBT.outerWndTopMost_setTime != DateTime.MinValue)
            {
                TimeSpan ts = DateTime.Now - curSelectedRBT.outerWndTopMost_setTime;
                if (ts.TotalMilliseconds > 800)
                {
                    bool curTM = CSharpUser32.OuterWindow.CheckWindowIsTopMost(curSelectedRBT.outerWndHandle);
                    if (curTM != curSelectedRBT.outerWndTopMost_setValue)
                    {
                        curSelectedRBT.outerWndRestoreTopMost = true;
                        curSelectedRBT.outerWndTopMost_setTime = DateTime.MinValue;
                        checkBox_topMost.Enabled = false;
                        toolTip.SetToolTip(checkBox_topMost, Tx_toolTip_CantTopMost);
                    }
                }
            }
        }
    }
}
