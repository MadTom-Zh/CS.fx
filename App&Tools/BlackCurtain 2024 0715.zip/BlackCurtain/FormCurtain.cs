﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class FormCurtain : Form
    {
        public FormCurtain()
        {
            InitializeComponent();
            iconOrigin = this.Icon;
            titleOrigin = this.Text;
        }
        private Icon iconOrigin;
        private string _titleOrigin;
        public string titleOrigin
        {
            get { return _titleOrigin; }
            set
            {
                _titleOrigin = value;
                ReSetFormText();
            }
        }
        public Icon iconShell = null;

        public event EventHandler CallNewOne;
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CallNewOne?.Invoke(this, e);
        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        #region invisible on key down, restore on key up

        private Keys key_V_pre = Keys.None;
        private double opacityPre = 2;
        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.V:
                    if (key_V_pre == Keys.V) return;
                    key_V_pre = Keys.V;
                    opacityPre = this.Opacity;
                    this.Opacity = 0.01;
                    break;
                case Keys.Subtract:
                case Keys.OemMinus:
                    if (this.Opacity - 0.01 > 0.01)
                    {
                        this.Opacity -= 0.01;
                    }
                    break;
                case Keys.Add:
                case Keys.Oemplus:
                    this.Opacity += 0.01;
                    break;
                case Keys.OemOpenBrackets:
                    if (this.Opacity - 0.1 > 0.01)
                    {
                        this.Opacity -= 0.1;
                    }
                    break;
                case Keys.Oem6:
                    this.Opacity += 0.1;
                    break;
            }
        }
        private void Form_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.V:
                    key_V_pre = Keys.None;
                    this.Opacity = opacityPre;
                    break;
            }
        }

        #endregion


        #region change curtain size

        Point mouseStartPoint;
        Point formStartPosition;
        Size formStartSize;
        // 0 right, 1 buttom, 2 left, 3 top
        // 4 Buttom-right, 5 buttom-left, 6 top-left, 7 top-right
        int moveVectorIndex = -1;
        private void panel_MouseDown(object sender, MouseEventArgs e)
        {
            formStartPosition = this.Location;
            formStartSize = this.Size;

            mouseStartPoint = MousePosition;

            Panel target = (Panel)sender;
            string targetName = target.Name.ToLower();
            if (targetName.EndsWith("_right")) moveVectorIndex = 0;
            else if (targetName.EndsWith("_btm")) moveVectorIndex = 1;
            else if (targetName.EndsWith("_left")) moveVectorIndex = 2;
            else if (targetName.EndsWith("_top")) moveVectorIndex = 3;
            else if (targetName.EndsWith("_btmright")) moveVectorIndex = 4;
            else if (targetName.EndsWith("_btmleft")) moveVectorIndex = 5;
            else if (targetName.EndsWith("_topleft")) moveVectorIndex = 6;
            else if (targetName.EndsWith("_topright")) moveVectorIndex = 7;
            else moveVectorIndex = -1;
        }

        private void panel_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePosition = MousePosition;
            if (moveVectorIndex == 0) this.Width = formStartSize.Width + mousePosition.X - mouseStartPoint.X;
            else if (moveVectorIndex == 1) this.Height = formStartSize.Height + mousePosition.Y - mouseStartPoint.Y;
            else if (moveVectorIndex == 2)
            {
                this.Width = formStartSize.Width - mousePosition.X + mouseStartPoint.X;

                Point newFormLocation = formStartPosition;
                newFormLocation.Offset(mousePosition.X - mouseStartPoint.X, 0);
                this.Location = newFormLocation;
            }
            else if (moveVectorIndex == 3)
            {
                this.Height = formStartSize.Height - mousePosition.Y + mouseStartPoint.Y;

                Point newFormLocation = formStartPosition;
                newFormLocation.Offset(0, mousePosition.Y - mouseStartPoint.Y);
                this.Location = newFormLocation;
            }
            else if (moveVectorIndex == 4)
            {
                this.Width = formStartSize.Width + mousePosition.X - mouseStartPoint.X;
                this.Height = formStartSize.Height + mousePosition.Y - mouseStartPoint.Y;
            }
            else if (moveVectorIndex == 5)
            {
                this.Width = formStartSize.Width - mousePosition.X + mouseStartPoint.X;
                this.Height = formStartSize.Height + mousePosition.Y - mouseStartPoint.Y;

                Point newFormLocation = formStartPosition;
                newFormLocation.Offset(mousePosition.X - mouseStartPoint.X, 0);
                this.Location = newFormLocation;
            }
            else if (moveVectorIndex == 6)
            {
                this.Width = formStartSize.Width - mousePosition.X + mouseStartPoint.X;
                this.Height = formStartSize.Height - mousePosition.Y + mouseStartPoint.Y;

                Point newFormLocation = formStartPosition;
                newFormLocation.Offset(mousePosition.X - mouseStartPoint.X, 0);
                newFormLocation.Offset(0, mousePosition.Y - mouseStartPoint.Y);
                this.Location = newFormLocation;
            }
            else if (moveVectorIndex == 7)
            {
                this.Width = formStartSize.Width + mousePosition.X - mouseStartPoint.X;
                this.Height = formStartSize.Height - mousePosition.Y + mouseStartPoint.Y;

                Point newFormLocation = formStartPosition;
                newFormLocation.Offset(0, mousePosition.Y - mouseStartPoint.Y);
                this.Location = newFormLocation;
            }

        }

        private void panel_MouseUp(object sender, MouseEventArgs e)
        { moveVectorIndex = -1; }
        private void panel_MouseLeave(object sender, EventArgs e)
        { moveVectorIndex = -1; }

        #endregion


        #region move form

        private bool movingForm = false;
        private void FormMain_MouseDown(object sender, MouseEventArgs e)
        {
            mouseStartPoint = MousePosition;
            formStartPosition = this.Location;
            movingForm = true;
        }
        private void FormMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (movingForm)
            {
                Point newPosition = formStartPosition;
                newPosition.Offset(MousePosition);
                newPosition.Offset(-mouseStartPoint.X, -mouseStartPoint.Y);
                this.Location = newPosition;
            }
        }
        private void FormMain_MouseUp(object sender, MouseEventArgs e)
        { movingForm = false; }
        private void FormMain_MouseLeave(object sender, EventArgs e)
        { movingForm = false; }

        #endregion


        #region change opacity

        private void ToolStripMenuItem_fadeMore_Click(object sender, EventArgs e)
        {
            if (this.Opacity - 0.1 > 0.01)
            {
                this.Opacity -= 0.1;
            }
        }
        private void ToolStripMenuItem_fade_Click(object sender, EventArgs e)
        {
            if (this.Opacity - 0.01 > 0.01)
            {
                this.Opacity -= 0.01;
            }
        }
        private void ToolStripMenuItem_thick_Click(object sender, EventArgs e)
        {
            this.Opacity += 0.01;
        }
        private void ToolStripMenuItem_thickMore_Click(object sender, EventArgs e)
        {
            this.Opacity += 0.1;
        }

        #endregion


        #region minimize, normalize, close

        private void ToolStripMenuItem_minimize_Click(object sender, EventArgs e)
        { this.WindowState = FormWindowState.Minimized; }
        private void button_minimize_Click(object sender, EventArgs e)
        { this.WindowState = FormWindowState.Minimized; }

        private FormWindowState wStatePre = FormWindowState.Normal;
        private void FormMain_ClientSizeChanged(object sender, EventArgs e)
        {
            if (wStatePre != this.WindowState)
            {
                wStatePre = this.WindowState;
            }
            else return;

            if (this.WindowState == FormWindowState.Normal)
            {
                this.Icon = iconOrigin;
                this.Text = _titleOrigin;
            }
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        #endregion

        private void FormCurtain_SizeChanged(object sender, EventArgs e)
        {
            ReSetFormText();
        }
        private void ReSetFormText()
        {
            if (WindowState == FormWindowState.Minimized)
                this.Text = "@ " + _titleOrigin;
            else
                this.Text = _titleOrigin;
        }

        private void toolStripMenuItem_backColor_Click(object sender, EventArgs e)
        {
            FormSetColor winClr = new FormSetColor() { SelectedColor = BackColor };
            if (winClr.ShowDialog(this) == DialogResult.OK)
            {
                BackColor = winClr.SelectedColor;
                button_minimize.BackColor = winClr.SelectedColor;
                button_close.BackColor = winClr.SelectedColor;
                if (winClr.SelectedColor == SystemColors.WindowText)
                {
                    button_minimize.ForeColor = SystemColors.Control;
                    button_close.ForeColor = SystemColors.Control;
                }
                else
                {
                    button_minimize.ForeColor = SystemColors.WindowText;
                    button_close.ForeColor = SystemColors.WindowText;
                }
            }
        }
    }
}
