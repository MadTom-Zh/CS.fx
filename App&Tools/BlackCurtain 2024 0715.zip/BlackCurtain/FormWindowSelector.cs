﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MadTomDev.Resources;

namespace MadTomDev.App
{
    public partial class FormWindowSelector : Form
    {
        public FormWindowSelector()
        {
            InitializeComponent();
        }

        ListViewColumnSorter lvColumnSorter;
        private void FormWindowSelector_Shown(object sender, EventArgs e)
        {
            lvColumnSorter = new ListViewColumnSorter();
            listView_windows.ListViewItemSorter = lvColumnSorter;
            button_refresh_Click(null, null);
        }

        private void button_refresh_Click(object sender, EventArgs e)
        {
            listView_windows.Items.Clear();
            imageList_listView.Images.Clear();
            IntPtr[] allHWndList = CSharpUser32.OuterWindow.GetAllTopWindowsHandles();
            string title, ipStr;
            Image icon;
            ListViewItem lvItem;
            foreach (IntPtr ip in allHWndList)
            {
                title = CSharpUser32.OuterWindow.GetWindowText(ip);
                if (checkBox_filterNoName.Checked && string.IsNullOrWhiteSpace(title))
                    continue;

                icon = CSharpUser32.OuterWindow.GetWindowIcon32(ip);
                if (checkBox_filterNoIcon.Checked && icon == null)
                    continue;

                ipStr = ip.ToString();
                lvItem = new ListViewItem(new string[] { title, ipStr })
                { Tag = ip, };
                if (icon != null)
                {
                    imageList_listView.Images.Add(ipStr, icon);
                    lvItem.ImageKey = ipStr;
                }
                listView_windows.Items.Add(lvItem);
            }
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        public IntPtr SelectedWindowHandle
        { private set; get; } = IntPtr.Zero;
        private void listView_windows_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView_windows.SelectedItems.Count == 1)
            {
                SelectedWindowHandle = (IntPtr)listView_windows.SelectedItems[0].Tag;
                button_ok.Enabled = true;
            }
            else
            {
                SelectedWindowHandle = IntPtr.Zero;
                button_ok.Enabled = false;
            }
        }


        private void listView_windows_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == lvColumnSorter.SortColumn)
            {
                if (lvColumnSorter.Order == SortOrder.Ascending)
                {
                    lvColumnSorter.Order = SortOrder.Descending;
                }
                else
                {
                    lvColumnSorter.Order = SortOrder.Ascending;
                }
            }
            else
            {
                lvColumnSorter.SortColumn = e.Column;
                lvColumnSorter.Order = SortOrder.Ascending;
            }
            listView_windows.Sort();
        }
        public class ListViewColumnSorter : IComparer
        {
            public int ColumnToSort;
            public SortOrder OrderOfSort;
            private CaseInsensitiveComparer ObjectCompare;

            public ListViewColumnSorter()
            {
                ColumnToSort = 0;
                OrderOfSort = SortOrder.None;
                ObjectCompare = new CaseInsensitiveComparer();
            }

            public int Compare(object x, object y)
            {
                int compareResult;
                ListViewItem listviewX, listviewY;

                listviewX = (ListViewItem)x;
                listviewY = (ListViewItem)y;

                compareResult = ObjectCompare.Compare(listviewX.SubItems[ColumnToSort].Text, listviewY.SubItems[ColumnToSort].Text);

                if (OrderOfSort == SortOrder.Ascending)
                    return compareResult;
                else if (OrderOfSort == SortOrder.Descending)
                    return (-compareResult);
                else
                    return 0;

            }

            public int SortColumn
            {
                set
                { ColumnToSort = value; }
                get
                { return ColumnToSort; }
            }

            public SortOrder Order
            {
                set
                { OrderOfSort = value; }
                get
                { return OrderOfSort; }
            }

        }
    }
}
