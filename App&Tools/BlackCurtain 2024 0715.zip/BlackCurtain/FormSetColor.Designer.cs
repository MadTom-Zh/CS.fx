﻿namespace MadTomDev.App
{
    partial class FormSetColor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_clr256 = new System.Windows.Forms.TextBox();
            this.textBox_clrFF = new System.Windows.Forms.TextBox();
            this.button_ok = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.trackBar_r = new System.Windows.Forms.TrackBar();
            this.trackBar_g = new System.Windows.Forms.TrackBar();
            this.trackBar_b = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_r = new System.Windows.Forms.TextBox();
            this.textBox_g = new System.Windows.Forms.TextBox();
            this.textBox_b = new System.Windows.Forms.TextBox();
            this.pictureBox_selectedClr = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_g)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_b)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_selectedClr)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(776, 353);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(410, 395);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "RGB 256";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(410, 421);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "ARGB FF";
            // 
            // textBox_clr256
            // 
            this.textBox_clr256.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_clr256.Location = new System.Drawing.Point(476, 392);
            this.textBox_clr256.Name = "textBox_clr256";
            this.textBox_clr256.ReadOnly = true;
            this.textBox_clr256.Size = new System.Drawing.Size(100, 20);
            this.textBox_clr256.TabIndex = 3;
            // 
            // textBox_clrFF
            // 
            this.textBox_clrFF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_clrFF.Location = new System.Drawing.Point(476, 418);
            this.textBox_clrFF.Name = "textBox_clrFF";
            this.textBox_clrFF.ReadOnly = true;
            this.textBox_clrFF.Size = new System.Drawing.Size(100, 20);
            this.textBox_clrFF.TabIndex = 4;
            // 
            // button_ok
            // 
            this.button_ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ok.Location = new System.Drawing.Point(600, 401);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(91, 37);
            this.button_ok.TabIndex = 5;
            this.button_ok.Text = "Ok";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_cancel.Location = new System.Drawing.Point(697, 401);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(91, 37);
            this.button_cancel.TabIndex = 6;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // trackBar_r
            // 
            this.trackBar_r.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.trackBar_r.LargeChange = 16;
            this.trackBar_r.Location = new System.Drawing.Point(12, 371);
            this.trackBar_r.Maximum = 255;
            this.trackBar_r.Name = "trackBar_r";
            this.trackBar_r.Size = new System.Drawing.Size(285, 45);
            this.trackBar_r.TabIndex = 7;
            this.trackBar_r.Scroll += new System.EventHandler(this.trackBar_r_Scroll);
            // 
            // trackBar_g
            // 
            this.trackBar_g.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.trackBar_g.LargeChange = 16;
            this.trackBar_g.Location = new System.Drawing.Point(12, 396);
            this.trackBar_g.Maximum = 255;
            this.trackBar_g.Name = "trackBar_g";
            this.trackBar_g.Size = new System.Drawing.Size(285, 45);
            this.trackBar_g.TabIndex = 8;
            this.trackBar_g.Scroll += new System.EventHandler(this.trackBar_g_Scroll);
            // 
            // trackBar_b
            // 
            this.trackBar_b.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.trackBar_b.LargeChange = 16;
            this.trackBar_b.Location = new System.Drawing.Point(12, 421);
            this.trackBar_b.Maximum = 255;
            this.trackBar_b.Name = "trackBar_b";
            this.trackBar_b.Size = new System.Drawing.Size(285, 45);
            this.trackBar_b.TabIndex = 9;
            this.trackBar_b.Scroll += new System.EventHandler(this.trackBar_b_Scroll);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(300, 376);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Red";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(300, 401);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Green";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(300, 426);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Blue";
            // 
            // textBox_r
            // 
            this.textBox_r.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox_r.Location = new System.Drawing.Point(341, 373);
            this.textBox_r.Name = "textBox_r";
            this.textBox_r.Size = new System.Drawing.Size(51, 20);
            this.textBox_r.TabIndex = 13;
            this.textBox_r.TextChanged += new System.EventHandler(this.textBox_r_TextChanged);
            // 
            // textBox_g
            // 
            this.textBox_g.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox_g.Location = new System.Drawing.Point(341, 398);
            this.textBox_g.Name = "textBox_g";
            this.textBox_g.Size = new System.Drawing.Size(51, 20);
            this.textBox_g.TabIndex = 14;
            this.textBox_g.TextChanged += new System.EventHandler(this.textBox_g_TextChanged);
            // 
            // textBox_b
            // 
            this.textBox_b.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox_b.Location = new System.Drawing.Point(341, 423);
            this.textBox_b.Name = "textBox_b";
            this.textBox_b.Size = new System.Drawing.Size(51, 20);
            this.textBox_b.TabIndex = 15;
            this.textBox_b.TextChanged += new System.EventHandler(this.textBox_b_TextChanged);
            // 
            // pictureBox_selectedClr
            // 
            this.pictureBox_selectedClr.Location = new System.Drawing.Point(12, 371);
            this.pictureBox_selectedClr.Name = "pictureBox_selectedClr";
            this.pictureBox_selectedClr.Size = new System.Drawing.Size(571, 75);
            this.pictureBox_selectedClr.TabIndex = 16;
            this.pictureBox_selectedClr.TabStop = false;
            // 
            // FormSetColor
            // 
            this.AcceptButton = this.button_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button_cancel;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox_b);
            this.Controls.Add(this.textBox_g);
            this.Controls.Add(this.textBox_r);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.trackBar_b);
            this.Controls.Add(this.trackBar_g);
            this.Controls.Add(this.trackBar_r);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.textBox_clrFF);
            this.Controls.Add(this.textBox_clr256);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.pictureBox_selectedClr);
            this.Name = "FormSetColor";
            this.Text = "FormSetColor";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_g)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_b)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_selectedClr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_clr256;
        private System.Windows.Forms.TextBox textBox_clrFF;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.TrackBar trackBar_r;
        private System.Windows.Forms.TrackBar trackBar_g;
        private System.Windows.Forms.TrackBar trackBar_b;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_r;
        private System.Windows.Forms.TextBox textBox_g;
        private System.Windows.Forms.TextBox textBox_b;
        private System.Windows.Forms.PictureBox pictureBox_selectedClr;
    }
}