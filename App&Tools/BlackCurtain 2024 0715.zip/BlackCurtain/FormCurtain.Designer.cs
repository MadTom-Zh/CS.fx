﻿namespace MadTomDev.App
{
    partial class FormCurtain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCurtain));
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_fadeMore = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_fade = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_thick = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_thickMore = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_minimize = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_top = new System.Windows.Forms.Panel();
            this.panel_btm = new System.Windows.Forms.Panel();
            this.panel_left = new System.Windows.Forms.Panel();
            this.panel_right = new System.Windows.Forms.Panel();
            this.panel_topLeft = new System.Windows.Forms.Panel();
            this.panel_topRight = new System.Windows.Forms.Panel();
            this.panel_btmRight = new System.Windows.Forms.Panel();
            this.panel_btmLeft = new System.Windows.Forms.Panel();
            this.button_minimize = new System.Windows.Forms.Button();
            this.button_close = new System.Windows.Forms.Button();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_backColor = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripSeparator1,
            this.ToolStripMenuItem_fadeMore,
            this.ToolStripMenuItem_fade,
            this.ToolStripMenuItem_thick,
            this.ToolStripMenuItem_thickMore,
            this.toolStripMenuItem1,
            this.toolStripSeparator2,
            this.toolStripMenuItem_backColor,
            this.toolStripSeparator3,
            this.ToolStripMenuItem_minimize,
            this.closeToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(247, 242);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.newToolStripMenuItem.Text = "&New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(243, 6);
            // 
            // ToolStripMenuItem_fadeMore
            // 
            this.ToolStripMenuItem_fadeMore.Name = "ToolStripMenuItem_fadeMore";
            this.ToolStripMenuItem_fadeMore.Size = new System.Drawing.Size(246, 22);
            this.ToolStripMenuItem_fadeMore.Text = "Fade more (&[, left bracket)";
            this.ToolStripMenuItem_fadeMore.Click += new System.EventHandler(this.ToolStripMenuItem_fadeMore_Click);
            // 
            // ToolStripMenuItem_fade
            // 
            this.ToolStripMenuItem_fade.Name = "ToolStripMenuItem_fade";
            this.ToolStripMenuItem_fade.Size = new System.Drawing.Size(246, 22);
            this.ToolStripMenuItem_fade.Text = "Fade (&-)";
            this.ToolStripMenuItem_fade.Click += new System.EventHandler(this.ToolStripMenuItem_fade_Click);
            // 
            // ToolStripMenuItem_thick
            // 
            this.ToolStripMenuItem_thick.Name = "ToolStripMenuItem_thick";
            this.ToolStripMenuItem_thick.Size = new System.Drawing.Size(246, 22);
            this.ToolStripMenuItem_thick.Text = "Thick (&+)";
            this.ToolStripMenuItem_thick.Click += new System.EventHandler(this.ToolStripMenuItem_thick_Click);
            // 
            // ToolStripMenuItem_thickMore
            // 
            this.ToolStripMenuItem_thickMore.Name = "ToolStripMenuItem_thickMore";
            this.ToolStripMenuItem_thickMore.Size = new System.Drawing.Size(246, 22);
            this.ToolStripMenuItem_thickMore.Text = "Thick more (&], right bracket)";
            this.ToolStripMenuItem_thickMore.Click += new System.EventHandler(this.ToolStripMenuItem_thickMore_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(246, 22);
            this.toolStripMenuItem1.Text = "* Press V to make it transparency";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(243, 6);
            // 
            // ToolStripMenuItem_minimize
            // 
            this.ToolStripMenuItem_minimize.Name = "ToolStripMenuItem_minimize";
            this.ToolStripMenuItem_minimize.Size = new System.Drawing.Size(246, 22);
            this.ToolStripMenuItem_minimize.Text = "&Minimize";
            this.ToolStripMenuItem_minimize.Click += new System.EventHandler(this.ToolStripMenuItem_minimize_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // panel_top
            // 
            this.panel_top.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_top.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_top.Location = new System.Drawing.Point(58, 12);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(684, 40);
            this.panel_top.TabIndex = 1;
            this.panel_top.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_top.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_top.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_top.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_btm
            // 
            this.panel_btm.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_btm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_btm.Location = new System.Drawing.Point(58, 398);
            this.panel_btm.Name = "panel_btm";
            this.panel_btm.Size = new System.Drawing.Size(684, 40);
            this.panel_btm.TabIndex = 2;
            this.panel_btm.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_btm.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_btm.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_btm.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_left
            // 
            this.panel_left.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel_left.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_left.Location = new System.Drawing.Point(12, 58);
            this.panel_left.Name = "panel_left";
            this.panel_left.Size = new System.Drawing.Size(40, 334);
            this.panel_left.TabIndex = 3;
            this.panel_left.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_left.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_left.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_left.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_right
            // 
            this.panel_right.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_right.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_right.Location = new System.Drawing.Point(748, 58);
            this.panel_right.Name = "panel_right";
            this.panel_right.Size = new System.Drawing.Size(40, 334);
            this.panel_right.TabIndex = 4;
            this.panel_right.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_right.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_right.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_right.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_topLeft
            // 
            this.panel_topLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_topLeft.Location = new System.Drawing.Point(12, 12);
            this.panel_topLeft.Name = "panel_topLeft";
            this.panel_topLeft.Size = new System.Drawing.Size(40, 40);
            this.panel_topLeft.TabIndex = 5;
            this.panel_topLeft.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_topLeft.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_topLeft.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_topLeft.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_topRight
            // 
            this.panel_topRight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_topRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_topRight.Location = new System.Drawing.Point(748, 12);
            this.panel_topRight.Name = "panel_topRight";
            this.panel_topRight.Size = new System.Drawing.Size(40, 40);
            this.panel_topRight.TabIndex = 6;
            this.panel_topRight.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_topRight.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_topRight.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_topRight.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_btmRight
            // 
            this.panel_btmRight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_btmRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_btmRight.Location = new System.Drawing.Point(748, 398);
            this.panel_btmRight.Name = "panel_btmRight";
            this.panel_btmRight.Size = new System.Drawing.Size(40, 40);
            this.panel_btmRight.TabIndex = 6;
            this.panel_btmRight.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_btmRight.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_btmRight.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_btmRight.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // panel_btmLeft
            // 
            this.panel_btmLeft.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel_btmLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_btmLeft.Location = new System.Drawing.Point(12, 398);
            this.panel_btmLeft.Name = "panel_btmLeft";
            this.panel_btmLeft.Size = new System.Drawing.Size(40, 40);
            this.panel_btmLeft.TabIndex = 6;
            this.panel_btmLeft.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel_btmLeft.MouseLeave += new System.EventHandler(this.panel_MouseLeave);
            this.panel_btmLeft.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel_btmLeft.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // button_minimize
            // 
            this.button_minimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_minimize.Location = new System.Drawing.Point(690, 58);
            this.button_minimize.Name = "button_minimize";
            this.button_minimize.Size = new System.Drawing.Size(23, 23);
            this.button_minimize.TabIndex = 7;
            this.button_minimize.Text = "_";
            this.button_minimize.UseVisualStyleBackColor = true;
            this.button_minimize.Click += new System.EventHandler(this.button_minimize_Click);
            // 
            // button_close
            // 
            this.button_close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_close.Location = new System.Drawing.Point(719, 58);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(23, 23);
            this.button_close.TabIndex = 8;
            this.button_close.Text = "X";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(243, 6);
            // 
            // toolStripMenuItem_backColor
            // 
            this.toolStripMenuItem_backColor.Image = global::MadTomDev.App.Properties.Resources.rainbow16;
            this.toolStripMenuItem_backColor.Name = "toolStripMenuItem_backColor";
            this.toolStripMenuItem_backColor.Size = new System.Drawing.Size(246, 22);
            this.toolStripMenuItem_backColor.Text = "&Back Color...";
            this.toolStripMenuItem_backColor.Click += new System.EventHandler(this.toolStripMenuItem_backColor_Click);
            // 
            // FormCurtain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ContextMenuStrip = this.contextMenuStrip;
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_minimize);
            this.Controls.Add(this.panel_btmLeft);
            this.Controls.Add(this.panel_btmRight);
            this.Controls.Add(this.panel_topRight);
            this.Controls.Add(this.panel_topLeft);
            this.Controls.Add(this.panel_right);
            this.Controls.Add(this.panel_left);
            this.Controls.Add(this.panel_btm);
            this.Controls.Add(this.panel_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(128, 128);
            this.Name = "FormCurtain";
            this.Text = "BC";
            this.TopMost = true;
            this.ClientSizeChanged += new System.EventHandler(this.FormMain_ClientSizeChanged);
            this.SizeChanged += new System.EventHandler(this.FormCurtain_SizeChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form_KeyUp);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseDown);
            this.MouseLeave += new System.EventHandler(this.FormMain_MouseLeave);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseUp);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.Panel panel_btm;
        private System.Windows.Forms.Panel panel_left;
        private System.Windows.Forms.Panel panel_right;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Panel panel_topLeft;
        private System.Windows.Forms.Panel panel_topRight;
        private System.Windows.Forms.Panel panel_btmRight;
        private System.Windows.Forms.Panel panel_btmLeft;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_fadeMore;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_fade;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_thick;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_thickMore;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_minimize;
        private System.Windows.Forms.Button button_minimize;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_backColor;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    }
}

