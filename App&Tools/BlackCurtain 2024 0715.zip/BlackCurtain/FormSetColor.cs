﻿using MadTomDev.App.Ctrls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using TextBox = System.Windows.Forms.TextBox;

namespace MadTomDev.App
{
    public partial class FormSetColor : Form
    {
        public FormSetColor()
        {
            InitializeComponent();

            // make common color buttons
            flowLayoutPanel1.Controls.Clear(); clrBtns.Clear();
            ColorButton newClrBtn = new ColorButton() { ColorName = "Control", Color = SystemColors.Control };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "ControlLight", Color = SystemColors.ControlLight };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "ControlDark", Color = SystemColors.ControlDark };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "Window", Color = SystemColors.Window };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "WindowText", Color = SystemColors.WindowText };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);

            newClrBtn = new ColorButton() { ColorName = "Red", Color = Color.Red };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "Green", Color = Color.Green };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "Blue", Color = Color.Blue };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "Gray", Color = Color.Gray };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);
            newClrBtn = new ColorButton() { ColorName = "LightGray", Color = Color.LightGray };
            newClrBtn.Clicked += NewClrBtn_Clicked;
            flowLayoutPanel1.Controls.Add(newClrBtn); clrBtns.Add(newClrBtn);

        }

        private void NewClrBtn_Clicked(ColorButton obj)
        {
            foreach (ColorButton cBtn in clrBtns)
            {
                if (cBtn == obj)
                {
                    SelectedColor = cBtn.Color;
                    cBtn.IsChecked = true;
                }
                else
                {
                    cBtn.IsChecked = false;
                }
            }
        }

        private List<ColorButton> clrBtns = new List<ColorButton>();

        private bool _SelectedColor_setting = false;
        private Color _SelectedColor;
        public Color SelectedColor
        {
            get => _SelectedColor;
            set
            {
                _SelectedColor_setting = true;
                _SelectedColor = value;
                pictureBox_selectedClr.BackColor = value;
                foreach (ColorButton cBtn in clrBtns)
                {
                    cBtn.IsChecked = cBtn.Color == value;
                }
                trackBar_r.Value = value.R; textBox_r.Text = value.R.ToString();
                trackBar_g.Value = value.G; textBox_g.Text = value.G.ToString();
                trackBar_b.Value = value.B; textBox_b.Text = value.B.ToString();
                textBox_clr256.Text = textBox_r.Text + ", " + textBox_g.Text + ", " + textBox_b.Text;
                textBox_clrFF.Text = ColorTranslator.ToHtml(value);
                _SelectedColor_setting = false;
            }
        }

        private void textBox_r_TextChanged(object sender, EventArgs e)
        { TryGetCustomColor(textBox_r, 0); }
        private void textBox_g_TextChanged(object sender, EventArgs e)
        { TryGetCustomColor(textBox_g, 1); }
        private void textBox_b_TextChanged(object sender, EventArgs e)
        { TryGetCustomColor(textBox_b, 2); }

        private DateTime TryGetCustomColor_actTime = DateTime.MinValue;
        private bool TryGetCustomColor_waiting = false;
        private async void TryGetCustomColor(TextBox tb, int clrIdx)
        {
            if (_SelectedColor_setting)
                return;
            TryGetCustomColor_actTime = DateTime.Now;
            if (TryGetCustomColor_waiting)
                return;
            TryGetCustomColor_waiting = true;
            while ((DateTime.Now - TryGetCustomColor_actTime).TotalMilliseconds < 100)
            {
                await Task.Delay(30);
            }
            TryGetCustomColor_waiting = false;

            // clrIdx, 0-r 1-g 2-b
            if (int.TryParse(tb.Text, out int v))
            {
                if (0 <= v && v <= 255)
                {
                    tb.BackColor = SystemColors.Window;
                    Color newClr;
                    if (clrIdx == 0) newClr = Color.FromArgb(v, _SelectedColor.G, _SelectedColor.B);
                    else if (clrIdx == 1) newClr = Color.FromArgb(_SelectedColor.R, v, _SelectedColor.B);
                    else newClr = Color.FromArgb(_SelectedColor.R, _SelectedColor.G, v);
                    SelectedColor = newClr;
                }
                else
                {
                    tb.BackColor = SystemColors.GradientActiveCaption;
                }
            }
        }

        private void trackBar_r_Scroll(object sender, EventArgs e)
        { textBox_r.Text = trackBar_r.Value.ToString(); }
        private void trackBar_g_Scroll(object sender, EventArgs e)
        { textBox_g.Text = trackBar_g.Value.ToString(); }
        private void trackBar_b_Scroll(object sender, EventArgs e)
        { textBox_b.Text = trackBar_b.Value.ToString(); }

        private void button_ok_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
