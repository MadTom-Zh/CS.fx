﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TableRebuilder
{
    public partial class FormText : Form
    {
        public FormText()
        {
            InitializeComponent();
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        public string InDataHeader
        {
            set
            {
                textBox_header.Text = value;
            }
            get
            {
                return textBox_header.Text;
            }
        }
        public string InData
        {
            set
            {
                textBox_data.Text = value;
            }
            get
            {
                return textBox_data.Text;
            }
        }
    }
}
