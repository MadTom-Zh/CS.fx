﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace TableRebuilder
{
    public class DataTable
    {
        //public DataTable()
        //{
        //}
        //public void Load(string tableName)
        //{
        //}

        private string _dirFullName;
        public string _tableName;
        public string TableName
        {
            get
            {
                return _tableName;
            }
        }
        public DataTable(string tableName)
        {
            CreateDir(tableName);
            _tableName = tableName;
        }
        public DataTable(string tableName, string inDataHeader, string inData)
        {
            CreateDir(tableName);
            _tableName = tableName;

            SetData(inDataHeader, inData);
        }
        private void CreateDir(string tableName)
        {
            _dirFullName = AppDomain.CurrentDomain.BaseDirectory + "\\DB\\" + tableName;
            if (Directory.Exists(_dirFullName))
            {
                //throw new Exception("文件夹已存在！ [" + _dirFullName + "]");
                return;
            }
            Directory.CreateDirectory(_dirFullName);
        }

        // "" -> flag_dd
        private string _inDataHeader;
        public string InDataHeader
        {
            set
            {
                _inDataHeader = value;
                _dataHeader = new List<string>();
                string[] tmp = value.Split(new char[] { '\t' });
                for (int i = 0; i < tmp.Length; i++)
                {
                    _dataHeader.Add(tmp[i]);
                }
                File.WriteAllText(_dirFullName + "\\header.txt", _inDataHeader);
            }
            get
            {
                return _inDataHeader;
            }
        }
        private List<string> _dataHeader = new List<string>();
        public List<string> DataHeader
        {
            get
            {
                return _dataHeader;
            }
        }

        private string _inData;
        public string InData
        {
            set
            {
                _inData = value;
                _data = new List<List<string>>();
                List<string> dataRow;
                string[] tmp;
                string[] lines = value.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                for (int i = 0; i < lines.Length; i++)
                {
                    dataRow = new List<string>();
                    tmp = lines[i].Split(new char[] { '\t' });
                    for (int j = 0; j < tmp.Length; j++)
                    {
                        dataRow.Add(tmp[j]);
                    }
                    _data.Add(dataRow);
                }
                File.WriteAllText(_dirFullName + "\\data.txt", _inData);
            }
            get
            {
                return _inData;
            }
        }
        private List<List<string>> _data = new List<List<string>>();
        public List<List<string>> Data
        {
            get
            {
                return _data;
            }
        }

        public void SetData(string inDataHeader, string inData)
        {
            InDataHeader = inDataHeader;
            InData = inData;
        }

        public void Rebuild(DataTable inDT)
        {
            bool? matchAll = null;
            bool? matchNone = null;

            List<int> myTFIdx = new List<int>();
            List<int> inTFIdx = new List<int>();
            for (int i = 0; i < _dataHeader.Count; i++)
            {
                for (int j = 0; j < inDT.DataHeader.Count; j++)
                {
                    if (_dataHeader[i] == inDT.DataHeader[j])
                    {
                        myTFIdx.Add(i);
                        inTFIdx.Add(j);
                    }
                }
            }
            bool? oneMatch;
            for (int i = 0; i < Data.Count; i++)
            {
                for (int j = 0; j < inDT.Data.Count; j++)
                {
                    matchAll = null;
                    matchNone = null;
                    oneMatch = null;
                    for (int k = 0; k < myTFIdx.Count; k++)
                    {
                        if (oneMatch == true)
                        {
                            if (Data[i][myTFIdx[k]] == inDT.Data[j][inTFIdx[k]])
                            {
                                continue;
                            }
                            else
                            {
                                matchNone = matchAll = false;
                                oneMatch = null;
                                break;
                            }
                        }
                        else
                        {
                            if (Data[i][myTFIdx[k]] == inDT.Data[j][inTFIdx[k]])
                            {
                                matchNone = matchAll = false;
                                oneMatch = null;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    if (oneMatch == true)
                    {
                        matchAll = true;
                        matchNone = false;
                    }
                    else
                    {
                        matchAll = false;
                        matchNone = true;
                    }

                    if (matchAll == false)
                    {
                        List<string> newRow = new List<string>(DataHeader.Count);
                        for (int k = 0; k < myTFIdx.Count; k++)
                        {
                            newRow[myTFIdx[k]] = inDT.Data[j][inTFIdx[k]];
                        }
                        Data.Add(newRow);
                    }
                }
            }
        }
    }
}
