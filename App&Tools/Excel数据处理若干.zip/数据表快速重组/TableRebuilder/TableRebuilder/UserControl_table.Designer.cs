﻿namespace TableRebuilder
{
    partial class UserControl_table
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_edit = new System.Windows.Forms.Button();
            this.button_rebuild = new System.Windows.Forms.Button();
            this.label_c = new System.Windows.Forms.Label();
            this.label_r = new System.Windows.Forms.Label();
            this.label_tableName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_edit
            // 
            this.button_edit.Location = new System.Drawing.Point(3, 3);
            this.button_edit.Name = "button_edit";
            this.button_edit.Size = new System.Drawing.Size(49, 23);
            this.button_edit.TabIndex = 0;
            this.button_edit.Text = "edit";
            this.button_edit.UseVisualStyleBackColor = true;
            this.button_edit.Click += new System.EventHandler(this.button_edit_Click);
            // 
            // button_rebuild
            // 
            this.button_rebuild.Location = new System.Drawing.Point(58, 3);
            this.button_rebuild.Name = "button_rebuild";
            this.button_rebuild.Size = new System.Drawing.Size(63, 23);
            this.button_rebuild.TabIndex = 1;
            this.button_rebuild.Text = "rebuild";
            this.button_rebuild.UseVisualStyleBackColor = true;
            this.button_rebuild.Click += new System.EventHandler(this.button_rebuild_Click);
            // 
            // label_c
            // 
            this.label_c.AutoSize = true;
            this.label_c.Location = new System.Drawing.Point(127, 8);
            this.label_c.Name = "label_c";
            this.label_c.Size = new System.Drawing.Size(47, 12);
            this.label_c.TabIndex = 2;
            this.label_c.Text = "c:[###]";
            // 
            // label_r
            // 
            this.label_r.AutoSize = true;
            this.label_r.Location = new System.Drawing.Point(180, 8);
            this.label_r.Name = "label_r";
            this.label_r.Size = new System.Drawing.Size(65, 12);
            this.label_r.TabIndex = 3;
            this.label_r.Text = "r:[##,###]";
            // 
            // label_tableName
            // 
            this.label_tableName.AutoSize = true;
            this.label_tableName.Location = new System.Drawing.Point(3, 29);
            this.label_tableName.Name = "label_tableName";
            this.label_tableName.Size = new System.Drawing.Size(71, 12);
            this.label_tableName.TabIndex = 4;
            this.label_tableName.Text = "[tableName]";
            // 
            // UserControl_table
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label_tableName);
            this.Controls.Add(this.label_r);
            this.Controls.Add(this.label_c);
            this.Controls.Add(this.button_rebuild);
            this.Controls.Add(this.button_edit);
            this.Name = "UserControl_table";
            this.Size = new System.Drawing.Size(249, 47);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_edit;
        private System.Windows.Forms.Button button_rebuild;
        private System.Windows.Forms.Label label_c;
        private System.Windows.Forms.Label label_r;
        private System.Windows.Forms.Label label_tableName;
    }
}
