﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TableRebuilder
{
    public partial class UserControl_table : UserControl
    {
        public UserControl_table()
        {
            InitializeComponent();
        }

        public void CreateDataTable(string tableName)
        {
            _dataTable = new DataTable(tableName);
            RefreshInfo();
        }

        FormText ft;
        private void button_edit_Click(object sender, EventArgs e)
        {
            ft = new FormText();
            ft.InDataHeader = _dataTable.InDataHeader;
            ft.InData = _dataTable.InData;
            ft.FormClosed += ft_FormClosed;
            ft.Show();
        }
        void ft_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (ft.DialogResult == DialogResult.OK)
            {
                _dataTable.InDataHeader = ft.InDataHeader;
                _dataTable.InData = ft.InData;
                RefreshInfo();
            }
        }

        public bool CanRebuild
        {
            set
            {
                button_rebuild.Enabled = value;
            }
            get
            {
                return button_rebuild.Enabled;
            }
        }
        private void button_rebuild_Click(object sender, EventArgs e)
        {
            //RefreshInfo();
            if (CallRebuild != null)
            {
                CallRebuild(sender, e);
            }
        }
        public event EventHandler CallRebuild;

        public void RefreshInfo()
        {
            if (_dataTable != null)
            {
                label_tableName.Text = _dataTable.TableName;
                label_c.Text = "c:[" + _dataTable.DataHeader.Count.ToString("###") + "]";
                label_r.Text = "r:[" + _dataTable.Data.Count.ToString("##,###") + "]";
            }
        }

        private DataTable _dataTable;
        public DataTable dataTable
        {
            set
            {
                _dataTable = value;
                RefreshInfo();
            }
            get
            {
                return _dataTable;
            }
        }
    }
}
