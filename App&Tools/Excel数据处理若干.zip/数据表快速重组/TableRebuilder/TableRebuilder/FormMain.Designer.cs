﻿namespace TableRebuilder
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_newSource = new System.Windows.Forms.Button();
            this.flowLayoutPanel_source = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel_target = new System.Windows.Forms.FlowLayoutPanel();
            this.button_newTarget = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 460);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(476, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer1.Size = new System.Drawing.Size(476, 460);
            this.splitContainer1.SplitterDistance = 230;
            this.splitContainer1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel_source);
            this.groupBox1.Controls.Add(this.button_newSource);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(476, 230);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据源";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_newTarget);
            this.groupBox2.Controls.Add(this.flowLayoutPanel_target);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(476, 226);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "填充表";
            // 
            // button_newSource
            // 
            this.button_newSource.Location = new System.Drawing.Point(9, 20);
            this.button_newSource.Name = "button_newSource";
            this.button_newSource.Size = new System.Drawing.Size(75, 23);
            this.button_newSource.TabIndex = 0;
            this.button_newSource.Text = "New";
            this.button_newSource.UseVisualStyleBackColor = true;
            this.button_newSource.Click += new System.EventHandler(this.button_newSource_Click);
            // 
            // flowLayoutPanel_source
            // 
            this.flowLayoutPanel_source.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel_source.Location = new System.Drawing.Point(12, 49);
            this.flowLayoutPanel_source.Name = "flowLayoutPanel_source";
            this.flowLayoutPanel_source.Size = new System.Drawing.Size(452, 175);
            this.flowLayoutPanel_source.TabIndex = 1;
            // 
            // flowLayoutPanel_target
            // 
            this.flowLayoutPanel_target.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel_target.Location = new System.Drawing.Point(12, 49);
            this.flowLayoutPanel_target.Name = "flowLayoutPanel_target";
            this.flowLayoutPanel_target.Size = new System.Drawing.Size(452, 171);
            this.flowLayoutPanel_target.TabIndex = 2;
            // 
            // button_newTarget
            // 
            this.button_newTarget.Location = new System.Drawing.Point(12, 20);
            this.button_newTarget.Name = "button_newTarget";
            this.button_newTarget.Size = new System.Drawing.Size(75, 23);
            this.button_newTarget.TabIndex = 3;
            this.button_newTarget.Text = "New";
            this.button_newTarget.UseVisualStyleBackColor = true;
            this.button_newTarget.Click += new System.EventHandler(this.button_newTarget_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 482);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "FormMain";
            this.Text = "表格重组";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_newSource;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_source;
        private System.Windows.Forms.Button button_newTarget;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_target;
    }
}

