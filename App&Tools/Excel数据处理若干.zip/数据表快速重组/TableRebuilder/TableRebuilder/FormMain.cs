﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TableRebuilder
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private FormInputName formInput;
        private void button_newSource_Click(object sender, EventArgs e)
        {
            formInput = new FormInputName();
            if (formInput.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                UserControl_table uct = new UserControl_table();
                uct.CreateDataTable(formInput.InputName);
                uct.CanRebuild = false;
                flowLayoutPanel_source.Controls.Add(uct);
                uct.Show();
            }
        }

        private void button_newTarget_Click(object sender, EventArgs e)
        {
            formInput = new FormInputName();
            if (formInput.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                UserControl_table uct = new UserControl_table();
                uct.CreateDataTable(formInput.InputName);
                uct.CanRebuild = true;
                uct.CallRebuild += uct_CallRebuild;
                flowLayoutPanel_target.Controls.Add(uct);
                uct.Show();
            }
        }

        void uct_CallRebuild(object sender, EventArgs e)
        {
            UserControl_table target = (UserControl_table)sender;
            DataTable tarDT = target.dataTable;
            foreach (UserControl_table ctrl in flowLayoutPanel_source.Controls)
            {
                tarDT.Rebuild(ctrl.dataTable);
            }
            //target.dataTable = tarDT;
        }
    }
}
