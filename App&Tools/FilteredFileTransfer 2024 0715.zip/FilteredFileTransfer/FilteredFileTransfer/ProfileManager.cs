﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace MadTomDev.App
{

    public class ProfileManager
    {
        // xml profile node construct:
        // propertys:
        //     [0]isCopyOrMove
        //     [1]isDelEmpyDirAfterMoving
        //     [2]isOverwriteExist
        //     [3]isOsFuncOrCSFunc
        // nodes:
        //     [0] node path
        //     [1] node name
        //     [2] aDirPath
        //     [3] bDirPath
        //     [4] description
        //     [5] white list
        //     [6] black list

        public ProfileManager()
        {
            Load();
        }

        public XmlDocument xmlDoc = new XmlDocument();
        public XmlNode xmlRoot;
        private const string xmlFileName = "FFT.xml";
        private string _xmlFileFullName = null;

        private string xmlFileFullName
        {
            get
            {
                string baseDir = Common.Variables.IOPath.SettingDir;
                if (!Directory.Exists(baseDir))
                    Directory.CreateDirectory(baseDir);
                if (_xmlFileFullName == null)
                    _xmlFileFullName
                        = Path.Combine(
                            baseDir, xmlFileName);
                return _xmlFileFullName;
            }
        }
        public void Load()
        {
            if (File.Exists(xmlFileFullName))
            {
                xmlDoc.Load(xmlFileFullName);
                xmlRoot = xmlDoc.ChildNodes[0];
            }
            else
            {
                //xmlDoc.AppendChild(xmlDoc.crea);
                xmlRoot = xmlDoc.CreateNode(XmlNodeType.Element, "root", null);
                xmlDoc.AppendChild(xmlRoot);
                Add("", "[Default]");
            }
        }
        internal bool IsEndingSounds
        {
            set
            {
                xmlRoot.ChildNodes[0].Attributes["EndingSounds"].Value = value.ToString();
            }
            get
            {
                if (xmlRoot.ChildNodes[0].Attributes["EndingSounds"] == null)
                    xmlRoot.ChildNodes[0].Attributes.Append(xmlDoc.CreateAttribute("EndingSounds"));
                return xmlRoot.ChildNodes[0].Attributes["EndingSounds"].Value == true.ToString();
            }
        }
        internal Profile DefaultProfile
        {
            get => new Profile(this, xmlRoot.ChildNodes[0]);
        }
        public void Save()
        {
            xmlDoc.Save(xmlFileFullName);
        }
        public Profile Add(string dirPath, string profName)
        {
            //if (HaveProfile(dirPath + "\\" + profName))
            //    return null;

            XmlNode newNode = xmlDoc.CreateNode(XmlNodeType.Element, "Prof", null);
            TryRepairNode(newNode);
            newNode.Attributes[0].Value = "1";
            newNode.Attributes[1].Value = "1";
            newNode.Attributes[2].Value = "0";
            newNode.Attributes[3].Value = "1";
            newNode.ChildNodes[0].InnerText = dirPath;
            newNode.ChildNodes[1].InnerText = profName;
            newNode.ChildNodes[2].InnerText = "[A path]";
            newNode.ChildNodes[3].InnerText = "[B path]";
            newNode.ChildNodes[4].InnerText = "[Add a description]";
            newNode.ChildNodes[5].InnerText = "";
            newNode.ChildNodes[6].InnerText = "";
            xmlRoot.AppendChild(newNode);
            return new Profile(this, newNode);
        }
        public void TryRepairNode(XmlNode xNode)
        {
            for (int i = xNode.Attributes.Count, iV = 3; i <= iV; i++)
            {
                if (i == 0)
                    xNode.Attributes.Append(
                        xNode.OwnerDocument.CreateAttribute("isCorM"));
                if (i == 1)
                    xNode.Attributes.Append(
                        xNode.OwnerDocument.CreateAttribute("isDelEmptDirAfterM"));
                if (i == 2)
                    xNode.Attributes.Append(
                        xNode.OwnerDocument.CreateAttribute("isOverwriteExist"));
                if (i == 3)
                    xNode.Attributes.Append(
                        xNode.OwnerDocument.CreateAttribute("isOsFuncOrCSFunc"));
            }
            for (int i = xNode.ChildNodes.Count, iV = 6; i <= iV; i++)
            {
                if (i == 0) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
                if (i == 1) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
                if (i == 2) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
                if (i == 3) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
                if (i == 4) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
                if (i == 5) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
                if (i == 6) xNode.AppendChild(xmlDoc.CreateCDataSection(""));
            }
        }
        public Profile Get(string fullPath)
        {
            string path, name;
            GetPathNName(fullPath, out path, out name);
            path = path.ToLower(); name = name.ToLower();
            Profile prof;
            foreach (XmlNode xe in xmlRoot.ChildNodes)
            {
                prof = new Profile(this, xe);
                if (prof.DirPath.ToLower() == path
                    && prof.Name.ToLower() == name)
                {
                    TryRepairNode(xe);
                    return prof;
                }
            }
            return null;
        }
        private void GetPathNName(string fullPath,
            out string path, out string name)
        {
            if (fullPath.Contains("\\"))
            {
                int lastBSIdx = fullPath.LastIndexOf("\\");
                path = fullPath.Substring(0, lastBSIdx);
                name = fullPath.Substring(lastBSIdx + 1);
            }
            else
            {
                path = "";
                name = fullPath;
            }
        }
        public ItemShell[] GetList(string dirPath)
        {
            HashSet<ItemShell> dirShells = new HashSet<ItemShell>();
            HashSet<ItemShell> fileShells = new HashSet<ItemShell>();

            dirPath = dirPath.ToLower();
            string dirPath_withBS = dirPath + "\\";
            int dirPosi = dirPath_withBS.Length;
            string xnDirPathLower, dirName;
            Profile prof;
            foreach (XmlNode xn in xmlRoot.ChildNodes)
            {
                prof = new Profile(this, xn);
                xnDirPathLower = prof.DirPath.ToLower();
                if (xnDirPathLower == dirPath
                    || dirPosi == 1)
                    fileShells.Add(new ItemShell()
                    {
                        dirPath = prof.DirPath,
                        name = prof.Name,
                        isDirOrProf = false,
                    });
                else if (xnDirPathLower.StartsWith(dirPath_withBS))
                {
                    dirName = prof.DirPath.Substring(dirPosi);
                    if (dirName.Contains("\\"))
                        dirName = dirName.Substring(0, dirName.IndexOf("\\"));
                    dirShells.Add(new ItemShell()
                    {
                        dirPath = prof.DirPath.Substring(0, dirPosi - 1),
                        name = dirName,
                        isDirOrProf = true,
                    });
                }
            }

            List<ItemShell> result = new List<ItemShell>();
            result.AddRange(dirShells);
            result.AddRange(fileShells);
            return result.ToArray();
        }
        public struct ItemShell
        {
            public string dirPath;
            public string name;
            public bool isDirOrProf;
            public string FullName
            {
                get => string.IsNullOrWhiteSpace(dirPath)
                      ? name : dirPath + "\\" + name;
            }
        }

        // get profile, if null, its not exist
        //public bool HaveProfile(string fullPath)
        //{
        //}
        public bool HaveDir(string dirpath)
        {
            if (string.IsNullOrWhiteSpace(dirpath))
                return true;

            Profile prof;
            string pathLower;
            int dirpathLength = dirpath.Length;
            dirpath = dirpath.ToLower();
            string dirpath_withBS = dirpath + "\\";
            foreach (XmlElement xe in xmlRoot.ChildNodes)
            {
                prof = new Profile(this, xe);
                pathLower = prof.DirPath.ToLower();
                if (pathLower.Length > dirpathLength
                    && pathLower.StartsWith(dirpath_withBS))
                    return true;
                else if (pathLower == dirpath)
                    return true;
            }
            return false;
        }
        public int Del(string fullPath)
        {
            int result = 0;
            string path, name;
            GetPathNName(fullPath, out path, out name);
            path = path.ToLower(); name = name.ToLower();
            XmlNode xmlNode;
            Profile prof;
            for (int i = xmlRoot.ChildNodes.Count - 1; i >= 0; i--)
            {
                xmlNode = xmlRoot.ChildNodes[i];
                prof = new Profile(this, xmlNode);
                if (prof.DirPath.ToLower() == path
                    && prof.Name.ToLower() == name)
                {
                    prof.Del();
                    result++;
                }
            }
            return result;
        }
        public int DelDir(string dirPath)
        {
            int result = 0;
            dirPath = dirPath.ToLower();
            XmlNode xmlNode;
            Profile prof;
            for (int i = xmlRoot.ChildNodes.Count - 1; i >= 0; i--)
            {
                xmlNode = xmlRoot.ChildNodes[i];
                prof = new Profile(this, xmlNode);
                if (prof.DirPath.ToLower() == dirPath)
                {
                    prof.Del();
                    result++;
                }
            }
            return result;
        }

        public class Profile
        {
            public ProfileManager mgr;
            private XmlNode profNode;
            public Profile(ProfileManager mgr, XmlNode profNode)
            {
                this.mgr = mgr;
                this.profNode = profNode;
            }
            public bool IsCopyOrMove
            {
                set => profNode.Attributes[0].Value = value ? "1" : "0";
                get => profNode.Attributes[0].Value == "1";
            }
            public bool IsDelEmpyDirAfterMoving
            {
                set => profNode.Attributes[1].Value = value ? "1" : "0";
                get => profNode.Attributes[1].Value == "1";
            }
            public bool OverwriteExist
            {
                set => profNode.Attributes[2].Value = value ? "1" : "0";
                get => profNode.Attributes[2].Value == "1";
            }
            public bool OSFuncOrCSFunc
            {
                set => profNode.Attributes[3].Value = value ? "1" : "0";
                get => profNode.Attributes[3].Value == "1";
            }
            public string DirPath
            {
                set => profNode.ChildNodes[0].InnerText = value;
                get => profNode.ChildNodes[0].InnerText;
            }
            public string Name
            {
                set => profNode.ChildNodes[1].InnerText = value;
                get => profNode.ChildNodes[1].InnerText;
            }
            public string ADirPath
            {
                set => profNode.ChildNodes[2].InnerText = value;
                get => profNode.ChildNodes[2].InnerText;
            }
            public string BDirPath
            {
                set => profNode.ChildNodes[3].InnerText = value;
                get => profNode.ChildNodes[3].InnerText;
            }
            public string Description
            {
                set => profNode.ChildNodes[4].InnerText = value;
                get => profNode.ChildNodes[4].InnerText;
            }
            public string WhiteList
            {
                set => profNode.ChildNodes[5].InnerText = value;
                get => profNode.ChildNodes[5].InnerText;
            }
            public string BlackList
            {
                set => profNode.ChildNodes[6].InnerText = value;
                get => profNode.ChildNodes[6].InnerText;
            }

            public bool IsDeleted
            { private set; get; } = false;

            public void Del()
            {
                mgr.xmlRoot.RemoveChild(profNode);
                profNode = null;
                IsDeleted = true;
            }

            internal Profile Clone()
            {
                return new Profile(null, profNode.Clone());
            }
        }

        public static string GetDirName(string basePath, string fullPath)
        {
            string b = basePath.ToLower(),
                f = fullPath.ToLower();
            if (b.Length > 0 && !b.EndsWith("\\"))
                b += "\\";
            if (f.StartsWith(b))
            {
                string result = fullPath.Substring(b.Length);
                if (result.Contains("\\"))
                    return result.Substring(0, result.IndexOf("\\"));
                else
                    return result;
            }

            return null;
        }
    }
}
