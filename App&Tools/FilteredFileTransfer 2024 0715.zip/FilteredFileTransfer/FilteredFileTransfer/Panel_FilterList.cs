﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class Panel_FilterList : UserControl
    {
        public Panel_FilterList()
        {
            InitializeComponent();
        }

        public string ListStringBlock
        {
            set
            {
                dataGridView.Rows.Clear();
                string line;
                foreach (string iline in value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    line = iline.Trim();
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        //tags:  0-file  1-dir  2-fileNDir
                        if (line.EndsWith("2"))
                            dataGridView.Rows.Add(line.Substring(0, line.Length - 1), true, true);
                        else if (line.EndsWith("1"))
                            dataGridView.Rows.Add(line.Substring(0, line.Length - 1), false, true);
                        else
                            dataGridView.Rows.Add(line.Substring(0, line.Length - 1), true, false);
                    }
                }
            }
            get
            {
                StringBuilder strBdr = new StringBuilder();
                DataGridViewRow dgvRow;
                string p;
                object onFileObj, onDirObj;
                bool onFile, onDir;
                for (int i = 0, iV = dataGridView.Rows.Count; i < iV; i++)
                {
                    //tags:  0-file  1-dir  2-fileNDir
                    dgvRow = dataGridView.Rows[i];
                    if (dgvRow.Cells[0].Value == null)
                        continue;
                    p = ((string)dgvRow.Cells[0].Value).Trim();
                    if (!string.IsNullOrWhiteSpace(p))
                        strBdr.Append(p);
                    onFileObj = dgvRow.Cells[1].Value;
                    onDirObj = dgvRow.Cells[2].Value;
                    onFile = (onFileObj == null) ? false : (bool)onFileObj;
                    onDir = (onDirObj == null) ? false : (bool)onDirObj;
                    if (onFile && onDir) strBdr.Append(2);
                    else if (onDir) strBdr.Append(1);
                    else strBdr.Append(0);
                    strBdr.Append(Environment.NewLine);
                }

                return strBdr.ToString();
            }
        }



        public event EventHandler ContentUpdated;
        private void dataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        { ContentUpdated?.Invoke(this, null); }
        private void dataGridView_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        { ContentUpdated?.Invoke(this, null); }
        private void dataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        { ContentUpdated?.Invoke(this, null); }
    }
}
