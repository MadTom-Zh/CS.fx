﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using MadTomDev.Common;
using MadTomDev.Data;

namespace MadTomDev.App
{
    public class TransferHelper
    {
        public bool useOsOrCsFunc;
        public bool isOverwriteExist;

        private FileInfo _CurTransferingFileInfo;
        public FileInfo CurTransferingFileInfo
        {
            private set => _CurTransferingFileInfo = value;
            get => _CurTransferingFileInfo;
        }
        public bool IsTransfering { private set; get; }


        private int _AllFilesCount = 0;
        private int _transferedFilesCount = 0;
        public int AllFilesCount
        { get => _AllFilesCount; }

        private long _AllFilesSize = 0;
        private long _transferedFilesSize = 0;
        public long AllFilesSize
        { get => _AllFilesSize; }


        /// <summary>
        /// A file is just transfered;
        /// a0-sender, a1-filesTransfered, a2-bytesTransfered;
        /// </summary>
        public event Action<TransferHelper, int, long> Progressing;

        /// <summary>
        /// Error transfering file;
        /// a0-sender, a1-source, a2-target, a3-error
        /// </summary>
        public event Action<TransferHelper, string, string, Exception> TransErrorOccur;

        /// <summary>
        /// Transfer completed, or canceled;
        /// arg0-sender, arg1-isCompletedOrCanceled
        /// </summary>
        public event Action<TransferHelper, bool> Stoped;

        public TransferPack Scan(ProfileManager.Profile profile)
        {
            TransferPack rootPack = new TransferPack();
            ProfileManager.Profile profClone = profile.Clone();
            rootPack.baseDir = profClone.ADirPath;

            whiteListChecker = new SimpleStringHelper.Checker_starNQues();
            _InitListChecker(whiteListChecker, profClone.WhiteList);
            blackListChecker = new SimpleStringHelper.Checker_starNQues();
            _InitListChecker(blackListChecker, profClone.BlackList);

            _LoopADir(ref rootPack);
            return rootPack;
        }
        public async void StartTransfering(ProfileManager.Profile profile)
        {
            if (IsTransfering)
                return;

            _cancelFlag = false;
            IsTransfering = true;
            ProfileManager.Profile profClone = profile.Clone();
            await Task.Factory.StartNew(() =>
            {
                // list source
                TransferPack rootPack = new TransferPack();
                rootPack.baseDir = profClone.ADirPath;

                try
                {
                    if (!Directory.Exists(profClone.BDirPath))
                        Directory.CreateDirectory(profClone.BDirPath);

                    whiteListChecker = new SimpleStringHelper.Checker_starNQues();
                    _InitListChecker(whiteListChecker, profClone.WhiteList);
                    blackListChecker = new SimpleStringHelper.Checker_starNQues();
                    _InitListChecker(blackListChecker, profClone.BlackList);

                    _LoopADir(ref rootPack);
                    if (_cancelFlag)
                    {
                        Stoped?.Invoke(this, false);
                    }
                    else
                    {
                        _AllFilesCount = rootPack.GetFilesCount();
                        _AllFilesSize = rootPack.GetFilesTotalSize();

                        _transferedFilesCount = 0;
                        _transferedFilesSize = 0;
                        Progressing?.Invoke(this, _transferedFilesCount, _transferedFilesSize);

                        // transfer and report
                        _TransferLoop(rootPack, profClone.BDirPath, profClone);

                        // complete?? cancel??
                        if (_cancelFlag)
                            Stoped?.Invoke(this, false);
                        else
                            Stoped?.Invoke(this, true);
                    }
                }
                catch (Exception e)
                {
                    TransErrorOccur?.Invoke(this, rootPack.baseDir, profClone.BDirPath, e);
                    Stoped?.Invoke(this, false);
                }
            });
            IsTransfering = false;
        }

        private void _InitListChecker(SimpleStringHelper.Checker_starNQues whiteListChecker, string whiteList)
        {
            string line;
            foreach (string iline in whiteList.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries))
            {
                // 0-file  1-dir  2-fileNDir
                line = iline.Trim();
                if (!string.IsNullOrWhiteSpace(line))
                {
                    if (line.EndsWith("2"))
                        whiteListChecker.AddPattern(line.Substring(0, line.Length - 1), false, 2);
                    else if (line.EndsWith("1"))
                        whiteListChecker.AddPattern(line.Substring(0, line.Length - 1), false, 1);
                    else
                        whiteListChecker.AddPattern(line.Substring(0, line.Length - 1), false, 0);
                }
            }
        }

        #region load aList
        private SimpleStringHelper.Checker_starNQues whiteListChecker, blackListChecker;
        private void _LoopADir(ref TransferPack basePack)
        {
            if (_cancelFlag)
                return;

            DirectoryInfo baseDi = new DirectoryInfo(basePack.baseDir);
            string name;
            FileInfo[] subFiles;
            try
            { subFiles = baseDi.GetFiles(); }
            catch (Exception)
            { return; }

            foreach (FileInfo fi in subFiles)
            {
                if (whiteListChecker.HavePattern)
                {
                    name = fi.Name;
                    // 0-file  1-dir  2-fileNDir
                    if (whiteListChecker.Check(name, new object[] { 0, 2 }))
                        basePack.files.Add(fi);
                }
                else basePack.files.Add(fi);
            }
            if (blackListChecker.HavePattern)
            {
                for (int i = basePack.files.Count - 1; i >= 0; i--)
                {
                    name = basePack.files[i].Name;
                    if (blackListChecker.Check(name, new object[] { 0, 2 }))
                        basePack.files.RemoveAt(i);
                }
            }

            DirectoryInfo[] subDirs;
            try
            { subDirs = baseDi.GetDirectories(); }
            catch (Exception)
            { return; }
            TransferPack subDirPack;
            List<DirectoryInfo> filteredDirs = new List<DirectoryInfo>();
            foreach (DirectoryInfo di in subDirs)
            {
                if (whiteListChecker.HavePattern)
                {
                    name = di.Name;
                    // 0-file  1-dir  2-fileNDir
                    if (whiteListChecker.Check(name, new object[] { 1, 2 }))
                        filteredDirs.Add(di);
                }
                else filteredDirs.Add(di);
            }
            if (blackListChecker.HavePattern)
            {
                for (int i = filteredDirs.Count - 1; i >= 0; i--)
                {
                    name = filteredDirs[i].Name;
                    if (blackListChecker.Check(name, new object[] { 1, 2 }))
                        filteredDirs.RemoveAt(i);
                }
            }

            foreach (DirectoryInfo di in filteredDirs)
            {
                subDirPack = new TransferPack()
                { baseDir = di.FullName, };
                _LoopADir(ref subDirPack);
                basePack.dirs.Add(subDirPack);
            }
        }
        private bool _CheckNamePattern(ref Regex[] list, ref string name)
        {
            foreach (Regex wi in list)
            {
                if (wi.Match(name).Success)
                    return true;
            }
            return false;
        }
        #endregion

        #region transfer
        private void _TransferLoop(TransferPack basePack, string targetBaseDir,
            ProfileManager.Profile profile)
        {
            if (_cancelFlag)
                return;

            string targetSubDir;
            foreach (TransferPack subPack in basePack.dirs)
            {
                targetSubDir = Path.Combine(targetBaseDir, _GetName(subPack.baseDir));
                if (!Directory.Exists(targetSubDir))
                    Directory.CreateDirectory(targetSubDir);
                _TransferLoop(subPack, targetSubDir, profile);
            }

            // file transfer
            List<string> files = new List<string>();
            long curFilesSize = 0;
            foreach (FileInfo fi in basePack.files)
            {
                files.Add(fi.FullName);
                curFilesSize += fi.Length;
            }
            string targetFileFullName;
            Exception err;
            if (profile.IsCopyOrMove)
            {
                if (useOsOrCsFunc)
                {
                    if (isOverwriteExist)
                        Utilities.MSVBFileOperation.Copy(
                            files.ToArray(), targetBaseDir, out err,
                            Utilities.MSVBFileOperation.ExistingDirOperations.Combine,
                            Utilities.MSVBFileOperation.ExistingFileOperations.Overwrite);
                    else
                        Utilities.MSVBFileOperation.Copy(
                            files.ToArray(), targetBaseDir, out err,
                            Utilities.MSVBFileOperation.ExistingDirOperations.Combine,
                            Utilities.MSVBFileOperation.ExistingFileOperations.Skip);
                    if (err != null)
                        TransErrorOccur?.Invoke(this, "[files from] " + basePack.baseDir, targetBaseDir, err);
                    _transferedFilesCount += files.Count;
                    _transferedFilesSize += curFilesSize;
                    Progressing?.Invoke(this, _transferedFilesCount, _transferedFilesSize);
                }
                else
                {
                    try
                    {
                        bool isTransed = false;
                        foreach (FileInfo fi in basePack.files)
                        {
                            if (_cancelFlag)
                                return;

                            _CurTransferingFileInfo = fi;
                            targetFileFullName = Path.Combine(targetBaseDir, fi.Name);
                            if (File.Exists(targetFileFullName))
                            {
                                if (isOverwriteExist)
                                {
                                    File.Delete(targetFileFullName);
                                    fi.CopyTo(targetFileFullName);
                                    isTransed = true;
                                }
                            }
                            else
                            {
                                fi.CopyTo(targetFileFullName);
                                isTransed = true;
                            }
                            if (isTransed)
                            {
                                _transferedFilesCount += 1;
                                _transferedFilesSize += fi.Length;
                                Progressing?.Invoke(this, _transferedFilesCount, _transferedFilesSize);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        err = e;
                    }
                }
            }
            else
            {
                if (useOsOrCsFunc)
                {
                    if (isOverwriteExist)
                        Utilities.MSVBFileOperation.Move(
                            files.ToArray(), targetBaseDir, out err,
                            Utilities.MSVBFileOperation.ExistingDirOperations.Combine,
                            Utilities.MSVBFileOperation.ExistingFileOperations.Overwrite);
                    else
                        Utilities.MSVBFileOperation.Move(
                            files.ToArray(), targetBaseDir, out err,
                            Utilities.MSVBFileOperation.ExistingDirOperations.Combine,
                            Utilities.MSVBFileOperation.ExistingFileOperations.Skip);
                    if (err != null)
                        TransErrorOccur?.Invoke(this, "[files from] " + basePack.baseDir, targetBaseDir, err);
                    _transferedFilesCount += files.Count;
                    _transferedFilesSize += curFilesSize;
                    Progressing?.Invoke(this, _transferedFilesCount, _transferedFilesSize);
                }
                else
                {
                    try
                    {
                        bool isTransed = false;
                        foreach (FileInfo fi in basePack.files)
                        {
                            if (_cancelFlag)
                                return;

                            _CurTransferingFileInfo = fi;
                            targetFileFullName = Path.Combine(targetBaseDir, fi.Name);
                            if (File.Exists(targetFileFullName))
                            {
                                if (isOverwriteExist)
                                {
                                    File.Delete(targetFileFullName);
                                    fi.MoveTo(targetFileFullName);
                                    isTransed = true;
                                }
                            }
                            else
                            {
                                fi.MoveTo(targetFileFullName);
                                isTransed = true;
                            }
                            if (isTransed)
                            {
                                _transferedFilesCount += 1;
                                _transferedFilesSize += fi.Length;
                                Progressing?.Invoke(this, _transferedFilesCount, _transferedFilesSize);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        err = e;
                    }
                }
            }


            // delete empty folder??
            if (profile.IsDelEmpyDirAfterMoving
                && profile.IsCopyOrMove == false
                && profile.ADirPath != basePack.baseDir)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(basePack.baseDir);
                try
                {
                    if (dirInfo.GetFileSystemInfos().Length == 0)
                        dirInfo.Delete();
                }
                catch (Exception) { }
            }
        }
        private string _GetName(string fullPath)
        {
            if (fullPath.Contains("\\"))
                return fullPath.Substring(fullPath.LastIndexOf("\\") + 1);
            else
                return fullPath;
        }

        #endregion


        private bool _cancelFlag = false;
        public void Cancel()
        { _cancelFlag = true; }


        public class TransferPack
        {
            public string baseDir;
            public List<TransferPack> dirs = new List<TransferPack>();
            public List<FileInfo> files = new List<FileInfo>();

            public int GetFilesCount()
            {
                int result = 0;
                result += files.Count;
                foreach (TransferPack d in dirs)
                    result += d.GetFilesCount();
                return result;
            }

            public long GetFilesTotalSize()
            {
                return FilesTotalSize_loop(this);
            }
            private long FilesTotalSize_loop(TransferPack transferPack)
            {
                long result = 0;
                foreach (FileInfo f in transferPack.files)
                    result += f.Length;
                foreach (TransferPack d in transferPack.dirs)
                    result += FilesTotalSize_loop(d);
                return result;
            }
        }
    }
}
