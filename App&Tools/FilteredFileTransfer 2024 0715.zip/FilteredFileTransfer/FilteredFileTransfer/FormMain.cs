﻿using MadTomDev.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();

            // "AllowDrop" can't be shown, but it exists
            pictureBox_aDropZone.AllowDrop = true;
            pictureBox_bDropZone.AllowDrop = true;
        }

        private Logger logger;
        private ProfileManager.Profile selectedProfile = null;
        private bool isIniting = true;

        #region init and load

        private ProfileManager profileMgr = new ProfileManager();
        private TransferHelper tranferHelper = new TransferHelper();
        private void FormMain_Load(object sender, EventArgs e)
        {
            string logDir = Common.Variables.IOPath.LogDir;
            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);
            logger = new Logger()
            {
                BaseDir = logDir,
                BaseFileNamePre = "FFT",
            };
            logger.Log("Filtered File Transfer app-startup.");
            InitNLoadTree();
            //treeView_profiles.SelectedNode = treeView_profiles.Nodes[0];

            tranferHelper.Progressing += TranferHelper_Progressing;
            tranferHelper.TransErrorOccur += TranferHelper_TransErrorOccur;
            tranferHelper.Stoped += TranferHelper_Stoped;

            checkBox_sounds.Checked = profileMgr.IsEndingSounds;

            isIniting = false;
        }


        private void InitNLoadTree()
        {
            treeView_profiles.Nodes.Clear();
            FillTreeNole(null, profileMgr.GetList(""));
        }
        private void FillTreeNole(TreeNode targetTN, ProfileManager.ItemShell[] shells)
        {
            if (targetTN == null)
            {
                foreach (ProfileManager.ItemShell iShell in shells)
                    treeView_profiles.Nodes.Add(MakeTreeNode(iShell.isDirOrProf, iShell.name));
            }
            else
            {
                foreach (ProfileManager.ItemShell iShell in shells)
                    targetTN.Nodes.Add(MakeTreeNode(iShell.isDirOrProf, iShell.name));
            }
        }
        private TreeNode MakeTreeNode(bool isDir, string nameText)
        {
            string imageKey = isDir ? "F" : "P";
            TreeNode result = new TreeNode(nameText)
            { ImageKey = imageKey, SelectedImageKey = imageKey, };
            if (isDir)
                result.Nodes.Add("Loading...");
            return result;
        }

        #endregion


        #region drag drop dir to set A and B

        private void TextBox_bPath_DragEnter(object sender, DragEventArgs e)
        { e.Effect = DragDropEffects.Link; }
        private void TextBox_aPath_DragEnter(object sender, DragEventArgs e)
        { e.Effect = DragDropEffects.Link; }
        private void PictureBox_bDropZone_DragEnter(object sender, DragEventArgs e)
        { e.Effect = DragDropEffects.Link; }
        private void PictureBox_aDropZone_DragEnter(object sender, DragEventArgs e)
        { e.Effect = DragDropEffects.Link; }

        private void pictureBox_aDropZone_DragDrop(object sender, DragEventArgs e)
        { TrySetAPath(e); }
        private void textBox_aPath_DragDrop(object sender, DragEventArgs e)
        { TrySetAPath(e); }
        private void TrySetAPath(DragEventArgs e)
        {
            string dirPath = GetSingleDirPath(e);
            if (dirPath != null)
                textBox_aPath.Text = dirPath;
        }
        private string GetSingleDirPath(DragEventArgs e)
        {
            string[] dirPathes = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (dirPathes.Length == 1)
            {
                if (Directory.Exists(dirPathes[0]))
                    return dirPathes[0];
                else
                    return null;
            }
            return null;
        }

        private void pictureBox_bDropZone_DragDrop(object sender, DragEventArgs e)
        { TrySetBPath(e); }
        private void textBox_bPath_DragDrop(object sender, DragEventArgs e)
        { TrySetBPath(e); }
        private void TrySetBPath(DragEventArgs e)
        {
            string dirPath = GetSingleDirPath(e);
            if (dirPath != null)
                textBox_bPath.Text = dirPath;
        }

        #endregion


        #region profile new, del
        private void button_newProfile_Click(object sender, EventArgs e)
        {
            FormNewProfile newProfDia = new FormNewProfile();
            TreeNode tarDirTN = null;
            if (treeView_profiles.SelectedNode == null)
                newProfDia.DirPath = "";
            else if (treeView_profiles.SelectedNode.ImageKey == "P")
            {
                tarDirTN = treeView_profiles.SelectedNode.Parent;
                if (tarDirTN == null)
                    newProfDia.DirPath = "";
                else
                    newProfDia.DirPath = tarDirTN.FullPath;
            }
            else
            {
                tarDirTN = treeView_profiles.SelectedNode;
                newProfDia.DirPath = tarDirTN.FullPath;
            }

            if (newProfDia.ShowDialog(this) == DialogResult.OK)
            {
                string pn = newProfDia.ProfName.Trim(),
                    dn = newProfDia.DirName.Trim();
                if (dn.Contains("\\") || pn.Contains("\\"))
                {
                    MessageBox.Show(
                        this, "Do NOT use '\\' in your profile or dir name.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                string dir = newProfDia.DirPath;
                if (dir.Length > 0)
                {
                    if (!string.IsNullOrWhiteSpace(dn))
                        dir += "\\" + dn;
                }
                else
                {
                    dir = dn;
                }
                ProfileManager.ItemShell[] subItems = profileMgr.GetList(dir);
                foreach (ProfileManager.ItemShell iShell in subItems)
                {
                    if (iShell.name.ToLower() == pn)
                    {
                        MessageBox.Show(
                            this, "Already had a item named [" + iShell.name + "].", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }


                ProfileManager.Profile newProf
                    = profileMgr.Add(dir, pn);
                if (tarDirTN == null)
                    treeView_profiles.Nodes.Add(MakeTreeNode(tarDirTN, newProf));
                else
                    tarDirTN.Nodes.Add(MakeTreeNode(tarDirTN, newProf));

            }
        }
        private TreeNode MakeTreeNode(TreeNode targetTN, ProfileManager.Profile newProf)
        {
            if (targetTN == null)
            {
                if (string.IsNullOrWhiteSpace(newProf.DirPath))
                    return new TreeNode(newProf.Name)
                    { ImageKey = "P", SelectedImageKey = "P", };
                else
                {
                    TreeNode result = new TreeNode(ProfileManager.GetDirName("", newProf.DirPath))
                    { ImageKey = "F", SelectedImageKey = "F", };
                    result.Nodes.Add("Loading...");
                    return result;
                }
            }
            else
            {
                if (targetTN.FullPath.ToLower() == newProf.DirPath.ToLower())
                    return new TreeNode(newProf.Name)
                    { ImageKey = "P", SelectedImageKey = "P", };
                else
                {
                    TreeNode result = new TreeNode(ProfileManager.GetDirName(targetTN.FullPath, newProf.DirPath))
                    { ImageKey = "F", SelectedImageKey = "F", };
                    result.Nodes.Add("Loading...");
                    return result;
                }
            }
        }


        private void button_delProfile_Click(object sender, EventArgs e)
        {
            if (treeView_profiles.SelectedNode.Level == 0
                && treeView_profiles.SelectedNode.Text == "[Default]")
            {
                MessageBox.Show(this, "[Default] can NOT be deleted.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (treeView_profiles.SelectedNode != null)
            {
                int delResult = 0;
                if (treeView_profiles.SelectedNode.ImageKey == "P")
                    delResult = profileMgr.Del(treeView_profiles.SelectedNode.FullPath);
                else
                    delResult = profileMgr.DelDir(treeView_profiles.SelectedNode.FullPath);
                if (delResult > 0)
                {
                    treeView_profiles.Nodes.Remove(treeView_profiles.SelectedNode);
                }
            }
        }


        #endregion

        #region profile tree, expand, collapse, select, save profile
        private void treeView_profiles_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            e.Node.Nodes.Clear();
            e.Node.Nodes.Add("Loading...");
        }
        private void treeView_profiles_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (isIniting)
                return;

            if (e.Node.ImageKey == "P")
                selectedProfile = profileMgr.Get(e.Node.FullPath);
            else
                selectedProfile = null;
            ProfToUI(selectedProfile);
        }

        private void treeView_profiles_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            e.Node.Nodes.Clear();
            FillTreeNole(e.Node, profileMgr.GetList(e.Node.FullPath));
        }
        #endregion

        private void ProfToUI(ProfileManager.Profile prof)
        {
            textBox_aPath.Text = prof.ADirPath;
            textBox_bPath.Text = prof.BDirPath;
            if (prof.IsCopyOrMove)
                radioButton_toCopy.Checked = true;
            else
                radioButton_toMove.Checked = true;
            if (prof.OSFuncOrCSFunc)
                radioButton_osFunc.Checked = true;
            else
                radioButton_csFunc.Checked = true;
            checkBox_delFolderAfterMoveEmpty.Checked = prof.IsDelEmpyDirAfterMoving;
            checkBox_overwriteExist.Checked = prof.OverwriteExist;
            panel_FilterList_w.ListStringBlock = prof.WhiteList;
            panel_FilterList_b.ListStringBlock = prof.BlackList;
            textBox_profileDescription.Text = prof.Description;

        }
        private void button_saveProfile_Click(object sender, EventArgs e)
        {
            if (selectedProfile != null)
                ProfFromUI(selectedProfile);
            else
            {
                ProfFromUI(profileMgr.DefaultProfile);
                treeView_profiles.SelectedNode
                    = treeView_profiles.Nodes["[Default]"];
            }
            profileMgr.Save();
        }
        private void ProfFromUI(ProfileManager.Profile prof)
        {
            prof.ADirPath = textBox_aPath.Text;
            prof.BDirPath = textBox_bPath.Text;
            prof.IsCopyOrMove = radioButton_toCopy.Checked;
            prof.OSFuncOrCSFunc = radioButton_osFunc.Checked;
            prof.IsDelEmpyDirAfterMoving = checkBox_delFolderAfterMoveEmpty.Checked;
            prof.OverwriteExist = checkBox_overwriteExist.Checked;
            prof.WhiteList = panel_FilterList_w.ListStringBlock;
            prof.BlackList = panel_FilterList_b.ListStringBlock;
            prof.Description = textBox_profileDescription.Text;
        }

        private void button_startStop_Click(object sender, EventArgs e)
        {
            if (tranferHelper.IsTransfering)
            {
                tranferHelper.Cancel();
                button_startStop.Text = "Stoping\r\n...";
                button_startStop.Enabled = false;
                label_TransferingFileInfo.Text = "";
                logger.Log("User stop transfering.");
                return;
            }

            if (selectedProfile == null)
                return;

            transStartTime = DateTime.Now;
            transLastCalTime = transStartTime;
            logger.Log("Transfer start.");
            button_saveProfile_Click(null, null);
            button_scan.Enabled = false;
            button_startStop.Text = "Stop\r\nListing...";
            tranferHelper.useOsOrCsFunc = radioButton_osFunc.Checked;
            tranferHelper.isOverwriteExist = checkBox_overwriteExist.Checked;
            tranferHelper.StartTransfering(selectedProfile);
        }

        private DateTime transStartTime;
        private DateTime transLastCalTime = DateTime.MinValue;

        private delegate void TranferHelper_ProgressingDelegate(TransferHelper sender, int transferedFilesCound, long transferedFilesSize);
        private void TranferHelper_Progressing(TransferHelper sender, int transferedFilesCount, long transferedFilesSize)
        {
            if (this.InvokeRequired)
            {
                TranferHelper_ProgressingDelegate callback
                    = new TranferHelper_ProgressingDelegate(TranferHelper_Progressing);
                this.Invoke(callback, sender, transferedFilesCount, transferedFilesSize);
            }
            else
            {

                if (radioButton_csFunc.Checked)
                {
                    DateTime now = DateTime.Now;
                    TimeSpan tsLast = now - transLastCalTime;
                    if (transferedFilesCount == 0)
                    {
                        button_startStop.Text = "Stop\r\n"
                            + "0 / " + tranferHelper.AllFilesCount;
                    }
                    else if (tsLast.TotalMilliseconds >= 500)
                    {
                        TimeSpan tsAll = now - transStartTime;
                        TimeSpan etc = TimeSpan.FromTicks(
                            (long)(tsAll.Ticks * ((double)sender.AllFilesSize / transferedFilesSize))
                            - tsAll.Ticks);
                        transLastCalTime = now;

                        button_startStop.Text = "Stop\r\n"
                            + transferedFilesCount.ToString()
                            + " / " + tranferHelper.AllFilesCount + "\r\n"
                            + "Spd " + SimpleStringHelper.UnitsOfMeasure.GetShortString(
                                (decimal)((double)transferedFilesSize / tsAll.TotalSeconds), "B", 1024) + "/s\r\n"
                            + "ETC " + etc.ToString(@"d\.\ hh\:mm\:ss");
                    }
                }
                else // radioButton_osFunc.Checked 
                {
                    button_startStop.Text = "Stop\r\n"
                        + transferedFilesCount.ToString()
                        + " / " + tranferHelper.AllFilesCount;
                }
            }
        }

        private delegate void TranferHelper_TransErrorOccurDelegate(TransferHelper sender, string source, string target, Exception err);
        private void TranferHelper_TransErrorOccur(TransferHelper sender, string source, string target, Exception err)
        {
            if (this.InvokeRequired)
            {
                TranferHelper_TransErrorOccurDelegate callback
                    = new TranferHelper_TransErrorOccurDelegate(TranferHelper_TransErrorOccur);
                this.Invoke(callback, sender, source, target, err);
            }
            else
            {
                if (err is DirectoryNotFoundException)
                {
                    logger.Log("Directory Not Found: " + source);
                }
                else if (err is FileNotFoundException)
                {
                    logger.Log("File Not Found: " + source);
                }
                else
                {
                    logger.Log(err);
                    string errorFullText = err.ToString();
                    //MessageBox.Show(this,
                    //    errorFullText, "Error",
                    //    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    label_TransferingFileInfo.Text = "Error: " + errorFullText;
                }
            }
        }


        private delegate void TranferHelper_StopedDelegate(TransferHelper sender, bool isCompleteOrCanceled);
        private void TranferHelper_Stoped(TransferHelper sender, bool isCompleteOrCanceled)
        {
            if (this.InvokeRequired)
            {
                TranferHelper_StopedDelegate callback
                    = new TranferHelper_StopedDelegate(TranferHelper_Stoped);
                this.Invoke(callback, sender, isCompleteOrCanceled);
            }
            else
            {
                if (isCompleteOrCanceled)
                {
                    logger.Log("Transfer complete.");
                    //MessageBox.Show(this,
                    //    "Task complete.", "Info",
                    //    MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    label_TransferingFileInfo.Text = "Task complete.";
                    if (checkBox_sounds.Checked)
                        SystemSounds.Asterisk.Play();
                }
                else
                {
                    logger.Log("Transfer canceled.");
                    //MessageBox.Show(this,
                    //    "Task canceled.", "Warning",
                    //    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    label_TransferingFileInfo.Text = "Task canceled.";
                    if (checkBox_sounds.Checked)
                        SystemSounds.Beep.Play();
                }
                button_scan.Enabled = true;
                button_startStop.Text = "Start";
                button_startStop.Enabled = true;

                if (checkBox_sounds.Checked)
                    SystemSounds.Hand.Play();
            }
        }

        private void FormMain_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
        }

        private StringBuilder label_TransferingFileInfo_strBdr = new StringBuilder();
        private void timer_tingFileInfo_Tick(object sender, EventArgs e)
        {
            if (tranferHelper.IsTransfering)
            {
                FileInfo curFI = tranferHelper.CurTransferingFileInfo;
                if (curFI == null)
                    return;
                label_TransferingFileInfo_strBdr.Clear();
                label_TransferingFileInfo_strBdr.Append("CurFile: ");
                label_TransferingFileInfo_strBdr.Append(curFI.FullName);
                label_TransferingFileInfo_strBdr.Append(Environment.NewLine);
                label_TransferingFileInfo_strBdr.Append("Size: ");
                label_TransferingFileInfo_strBdr.Append(
                    SimpleStringHelper.UnitsOfMeasure.GetShortString(curFI.Length, "B", 1024));
                label_TransferingFileInfo.Text = label_TransferingFileInfo_strBdr.ToString();
            }
        }

        private void button_scan_Click(object sender, EventArgs e)
        {
            if (selectedProfile == null)
            {
                MessageBox.Show(this,
                    "Select a profile first.", "Cancel",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            button_saveProfile_Click(null, null);
            label_TransferingFileInfo.Text = "Scaning...";
            button_scan.Enabled = false;
            Update();
            TransferHelper.TransferPack pack = tranferHelper.Scan(selectedProfile);
            label_TransferingFileInfo.Text = $"Report: Total [{pack.GetFilesCount()}] files, [{SimpleStringHelper.UnitsOfMeasure.GetShortString(button_scan_SumAllFileLength(pack), "B", 1024)}] in size.";
            button_scan.Enabled = true;
        }
        private long button_scan_SumAllFileLength(TransferHelper.TransferPack basePack)
        {
            long result = 0;
            foreach (FileInfo fi in basePack.files)
                result += fi.Length;
            foreach (TransferHelper.TransferPack subPack in basePack.dirs)
                result += button_scan_SumAllFileLength(subPack);
            return result;
        }

        private void pictureBox_aDropZone_DoubleClick(object sender, EventArgs e)
        {
            folderBrowserDialogA.SelectedPath = textBox_aPath.Text;
            if (folderBrowserDialogA.ShowDialog() == DialogResult.OK)
            {
                textBox_aPath.Text = folderBrowserDialogA.SelectedPath;
            }
        }

        private void pictureBox_bDropZone_DoubleClick(object sender, EventArgs e)
        {
            folderBrowserDialogB.SelectedPath = textBox_bPath.Text;
            if (folderBrowserDialogB.ShowDialog() == DialogResult.OK)
            {
                textBox_bPath.Text = folderBrowserDialogB.SelectedPath;
            }
        }

        private void checkBox_sounds_CheckedChanged(object sender, EventArgs e)
        {
            if (isIniting)
                return;
            profileMgr.IsEndingSounds = checkBox_sounds.Checked;
            profileMgr.Save();
        }
        private void button_viewLog_Click(object sender, EventArgs e)
        {
            Process.Start(logger.BaseDir);
        }
    }
}
