﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class FormNewProfile : Form
    {
        public FormNewProfile()
        {
            InitializeComponent();
        }
        private void FormNewProfile_Load(object sender, EventArgs e)
        {
            //this.DialogResult = DialogResult.Cancel;
        }

        public string DirPath
        {
            set => textBox_baseDir.Text = value;
            get => textBox_baseDir.Text;
        }
        public string DirName
        { get => textBox_dir.Text; }
        public string ProfName
        { get => textBox_name.Text; }


        private void button_ok_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FormNewProfile_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
