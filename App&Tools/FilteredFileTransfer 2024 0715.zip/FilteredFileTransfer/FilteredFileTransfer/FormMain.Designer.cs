﻿namespace MadTomDev.App
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.imageList_treeView = new System.Windows.Forms.ImageList(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button_delProfile = new System.Windows.Forms.Button();
            this.button_saveProfile = new System.Windows.Forms.Button();
            this.button_newProfile = new System.Windows.Forms.Button();
            this.textBox_profileDescription = new System.Windows.Forms.TextBox();
            this.treeView_profiles = new System.Windows.Forms.TreeView();
            this.checkBox_sounds = new System.Windows.Forms.CheckBox();
            this.label_TransferingFileInfo = new System.Windows.Forms.Label();
            this.button_viewLog = new System.Windows.Forms.Button();
            this.button_scan = new System.Windows.Forms.Button();
            this.button_startStop = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButton_osFunc = new System.Windows.Forms.RadioButton();
            this.radioButton_csFunc = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton_toCopy = new System.Windows.Forms.RadioButton();
            this.radioButton_toMove = new System.Windows.Forms.RadioButton();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox_overwriteExist = new System.Windows.Forms.CheckBox();
            this.checkBox_delFolderAfterMoveEmpty = new System.Windows.Forms.CheckBox();
            this.textBox_bPath = new System.Windows.Forms.TextBox();
            this.textBox_aPath = new System.Windows.Forms.TextBox();
            this.pictureBox_bDropZone = new System.Windows.Forms.PictureBox();
            this.pictureBox_aDropZone = new System.Windows.Forms.PictureBox();
            this.timer_tingFileInfo = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialogA = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialogB = new System.Windows.Forms.FolderBrowserDialog();
            this.panel_FilterList_w = new MadTomDev.App.Panel_FilterList();
            this.panel_FilterList_b = new MadTomDev.App.Panel_FilterList();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_bDropZone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_aDropZone)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList_treeView
            // 
            this.imageList_treeView.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList_treeView.ImageStream")));
            this.imageList_treeView.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList_treeView.Images.SetKeyName(0, "F");
            this.imageList_treeView.Images.SetKeyName(1, "P");
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 12);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button_delProfile);
            this.splitContainer1.Panel1.Controls.Add(this.button_saveProfile);
            this.splitContainer1.Panel1.Controls.Add(this.button_newProfile);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_profileDescription);
            this.splitContainer1.Panel1.Controls.Add(this.treeView_profiles);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.checkBox_sounds);
            this.splitContainer1.Panel2.Controls.Add(this.label_TransferingFileInfo);
            this.splitContainer1.Panel2.Controls.Add(this.button_viewLog);
            this.splitContainer1.Panel2.Controls.Add(this.button_scan);
            this.splitContainer1.Panel2.Controls.Add(this.button_startStop);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.radioButton_osFunc);
            this.splitContainer1.Panel2.Controls.Add(this.radioButton_csFunc);
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel2.Controls.Add(this.textBox_bPath);
            this.splitContainer1.Panel2.Controls.Add(this.textBox_aPath);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox_bDropZone);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox_aDropZone);
            this.splitContainer1.Size = new System.Drawing.Size(864, 561);
            this.splitContainer1.SplitterDistance = 168;
            this.splitContainer1.SplitterWidth = 8;
            this.splitContainer1.TabIndex = 12;
            // 
            // button_delProfile
            // 
            this.button_delProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_delProfile.Location = new System.Drawing.Point(101, 430);
            this.button_delProfile.Name = "button_delProfile";
            this.button_delProfile.Size = new System.Drawing.Size(64, 21);
            this.button_delProfile.TabIndex = 14;
            this.button_delProfile.Text = "Del...";
            this.button_delProfile.UseVisualStyleBackColor = true;
            this.button_delProfile.Click += new System.EventHandler(this.button_delProfile_Click);
            // 
            // button_saveProfile
            // 
            this.button_saveProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_saveProfile.Location = new System.Drawing.Point(88, 537);
            this.button_saveProfile.Name = "button_saveProfile";
            this.button_saveProfile.Size = new System.Drawing.Size(77, 20);
            this.button_saveProfile.TabIndex = 22;
            this.button_saveProfile.Text = "Save profile";
            this.button_saveProfile.UseVisualStyleBackColor = true;
            this.button_saveProfile.Click += new System.EventHandler(this.button_saveProfile_Click);
            // 
            // button_newProfile
            // 
            this.button_newProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_newProfile.Location = new System.Drawing.Point(2, 430);
            this.button_newProfile.Name = "button_newProfile";
            this.button_newProfile.Size = new System.Drawing.Size(64, 21);
            this.button_newProfile.TabIndex = 15;
            this.button_newProfile.Text = "New...";
            this.button_newProfile.UseVisualStyleBackColor = true;
            this.button_newProfile.Click += new System.EventHandler(this.button_newProfile_Click);
            // 
            // textBox_profileDescription
            // 
            this.textBox_profileDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_profileDescription.Location = new System.Drawing.Point(3, 451);
            this.textBox_profileDescription.Multiline = true;
            this.textBox_profileDescription.Name = "textBox_profileDescription";
            this.textBox_profileDescription.Size = new System.Drawing.Size(161, 86);
            this.textBox_profileDescription.TabIndex = 13;
            // 
            // treeView_profiles
            // 
            this.treeView_profiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView_profiles.ImageIndex = 0;
            this.treeView_profiles.ImageList = this.imageList_treeView;
            this.treeView_profiles.Location = new System.Drawing.Point(3, 3);
            this.treeView_profiles.Name = "treeView_profiles";
            this.treeView_profiles.SelectedImageIndex = 0;
            this.treeView_profiles.Size = new System.Drawing.Size(161, 427);
            this.treeView_profiles.TabIndex = 12;
            this.treeView_profiles.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeView_profiles_AfterCollapse);
            this.treeView_profiles.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_profiles_BeforeExpand);
            this.treeView_profiles.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_profiles_AfterSelect);
            // 
            // checkBox_sounds
            // 
            this.checkBox_sounds.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_sounds.AutoSize = true;
            this.checkBox_sounds.Location = new System.Drawing.Point(408, 469);
            this.checkBox_sounds.Name = "checkBox_sounds";
            this.checkBox_sounds.Size = new System.Drawing.Size(95, 17);
            this.checkBox_sounds.TabIndex = 23;
            this.checkBox_sounds.Text = "EndingSounds";
            this.checkBox_sounds.UseVisualStyleBackColor = true;
            this.checkBox_sounds.CheckedChanged += new System.EventHandler(this.checkBox_sounds_CheckedChanged);
            // 
            // label_TransferingFileInfo
            // 
            this.label_TransferingFileInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_TransferingFileInfo.Location = new System.Drawing.Point(122, 489);
            this.label_TransferingFileInfo.Name = "label_TransferingFileInfo";
            this.label_TransferingFileInfo.Size = new System.Drawing.Size(432, 68);
            this.label_TransferingFileInfo.TabIndex = 20;
            // 
            // button_viewLog
            // 
            this.button_viewLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_viewLog.Location = new System.Drawing.Point(509, 459);
            this.button_viewLog.Name = "button_viewLog";
            this.button_viewLog.Size = new System.Drawing.Size(52, 30);
            this.button_viewLog.TabIndex = 22;
            this.button_viewLog.Text = "Log...";
            this.button_viewLog.UseVisualStyleBackColor = true;
            this.button_viewLog.Click += new System.EventHandler(this.button_viewLog_Click);
            // 
            // button_scan
            // 
            this.button_scan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_scan.Location = new System.Drawing.Point(560, 459);
            this.button_scan.Name = "button_scan";
            this.button_scan.Size = new System.Drawing.Size(121, 30);
            this.button_scan.TabIndex = 22;
            this.button_scan.Text = "Scan";
            this.button_scan.UseVisualStyleBackColor = true;
            this.button_scan.Click += new System.EventHandler(this.button_scan_Click);
            // 
            // button_startStop
            // 
            this.button_startStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_startStop.Location = new System.Drawing.Point(560, 488);
            this.button_startStop.Name = "button_startStop";
            this.button_startStop.Size = new System.Drawing.Size(121, 69);
            this.button_startStop.TabIndex = 21;
            this.button_startStop.Text = "Start";
            this.button_startStop.UseVisualStyleBackColor = true;
            this.button_startStop.Click += new System.EventHandler(this.button_startStop_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Location = new System.Drawing.Point(122, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(381, 30);
            this.label4.TabIndex = 20;
            this.label4.Text = "OS Func: have UI, frequent window open/close;\r\nC# Func: no UI, little faster, can" +
    "t cancel operating file;";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(466, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "\'*\' as any chars, \'?\' as one char;";
            // 
            // radioButton_osFunc
            // 
            this.radioButton_osFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.radioButton_osFunc.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton_osFunc.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.radioButton_osFunc.Location = new System.Drawing.Point(3, 459);
            this.radioButton_osFunc.Name = "radioButton_osFunc";
            this.radioButton_osFunc.Size = new System.Drawing.Size(113, 49);
            this.radioButton_osFunc.TabIndex = 15;
            this.radioButton_osFunc.Text = "OS Func";
            this.radioButton_osFunc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton_osFunc.UseVisualStyleBackColor = true;
            // 
            // radioButton_csFunc
            // 
            this.radioButton_csFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.radioButton_csFunc.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton_csFunc.Checked = true;
            this.radioButton_csFunc.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.radioButton_csFunc.Location = new System.Drawing.Point(3, 509);
            this.radioButton_csFunc.Name = "radioButton_csFunc";
            this.radioButton_csFunc.Size = new System.Drawing.Size(113, 49);
            this.radioButton_csFunc.TabIndex = 16;
            this.radioButton_csFunc.TabStop = true;
            this.radioButton_csFunc.Text = "C# Func";
            this.radioButton_csFunc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton_csFunc.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.radioButton_toCopy);
            this.panel1.Controls.Add(this.radioButton_toMove);
            this.panel1.Location = new System.Drawing.Point(598, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(87, 178);
            this.panel1.TabIndex = 19;
            // 
            // radioButton_toCopy
            // 
            this.radioButton_toCopy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_toCopy.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton_toCopy.Checked = true;
            this.radioButton_toCopy.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.radioButton_toCopy.Location = new System.Drawing.Point(2, 3);
            this.radioButton_toCopy.Name = "radioButton_toCopy";
            this.radioButton_toCopy.Size = new System.Drawing.Size(86, 84);
            this.radioButton_toCopy.TabIndex = 4;
            this.radioButton_toCopy.TabStop = true;
            this.radioButton_toCopy.Text = "Copy";
            this.radioButton_toCopy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton_toCopy.UseVisualStyleBackColor = true;
            // 
            // radioButton_toMove
            // 
            this.radioButton_toMove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_toMove.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButton_toMove.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.radioButton_toMove.Location = new System.Drawing.Point(2, 91);
            this.radioButton_toMove.Name = "radioButton_toMove";
            this.radioButton_toMove.Size = new System.Drawing.Size(86, 84);
            this.radioButton_toMove.TabIndex = 4;
            this.radioButton_toMove.TabStop = true;
            this.radioButton_toMove.Text = "Move";
            this.radioButton_toMove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton_toMove.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(3, 226);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panel_FilterList_w);
            this.splitContainer2.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.panel_FilterList_b);
            this.splitContainer2.Panel2.Controls.Add(this.label2);
            this.splitContainer2.Size = new System.Drawing.Size(682, 227);
            this.splitContainer2.SplitterDistance = 340;
            this.splitContainer2.SplitterWidth = 7;
            this.splitContainer2.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 19);
            this.label1.TabIndex = 6;
            this.label1.Text = "White List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Black List";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.checkBox_overwriteExist);
            this.groupBox1.Controls.Add(this.checkBox_delFolderAfterMoveEmpty);
            this.groupBox1.Location = new System.Drawing.Point(3, 181);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(682, 39);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options";
            // 
            // checkBox_overwriteExist
            // 
            this.checkBox_overwriteExist.AutoSize = true;
            this.checkBox_overwriteExist.Location = new System.Drawing.Point(204, 16);
            this.checkBox_overwriteExist.Name = "checkBox_overwriteExist";
            this.checkBox_overwriteExist.Size = new System.Drawing.Size(101, 17);
            this.checkBox_overwriteExist.TabIndex = 0;
            this.checkBox_overwriteExist.Text = "Overwrite exist?";
            this.checkBox_overwriteExist.UseVisualStyleBackColor = true;
            // 
            // checkBox_delFolderAfterMoveEmpty
            // 
            this.checkBox_delFolderAfterMoveEmpty.AutoSize = true;
            this.checkBox_delFolderAfterMoveEmpty.Location = new System.Drawing.Point(9, 16);
            this.checkBox_delFolderAfterMoveEmpty.Name = "checkBox_delFolderAfterMoveEmpty";
            this.checkBox_delFolderAfterMoveEmpty.Size = new System.Drawing.Size(196, 17);
            this.checkBox_delFolderAfterMoveEmpty.TabIndex = 0;
            this.checkBox_delFolderAfterMoveEmpty.Text = "Move whole folder (when no file left)";
            this.checkBox_delFolderAfterMoveEmpty.UseVisualStyleBackColor = true;
            // 
            // textBox_bPath
            // 
            this.textBox_bPath.AllowDrop = true;
            this.textBox_bPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_bPath.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F);
            this.textBox_bPath.Location = new System.Drawing.Point(109, 91);
            this.textBox_bPath.Multiline = true;
            this.textBox_bPath.Name = "textBox_bPath";
            this.textBox_bPath.ReadOnly = true;
            this.textBox_bPath.Size = new System.Drawing.Size(485, 82);
            this.textBox_bPath.TabIndex = 13;
            this.textBox_bPath.Text = "[Drag B folder here or double-click,\r\ntarget of files to copy/move to]";
            this.textBox_bPath.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_bPath_DragDrop);
            this.textBox_bPath.DragEnter += new System.Windows.Forms.DragEventHandler(this.TextBox_bPath_DragEnter);
            // 
            // textBox_aPath
            // 
            this.textBox_aPath.AllowDrop = true;
            this.textBox_aPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_aPath.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F);
            this.textBox_aPath.Location = new System.Drawing.Point(109, 3);
            this.textBox_aPath.Multiline = true;
            this.textBox_aPath.Name = "textBox_aPath";
            this.textBox_aPath.ReadOnly = true;
            this.textBox_aPath.Size = new System.Drawing.Size(485, 82);
            this.textBox_aPath.TabIndex = 14;
            this.textBox_aPath.Text = "[Drag A folder here or double-click,\r\nsource files to copy/move from]";
            this.textBox_aPath.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_aPath_DragDrop);
            this.textBox_aPath.DragEnter += new System.Windows.Forms.DragEventHandler(this.TextBox_aPath_DragEnter);
            // 
            // pictureBox_bDropZone
            // 
            this.pictureBox_bDropZone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_bDropZone.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_bDropZone.Image")));
            this.pictureBox_bDropZone.Location = new System.Drawing.Point(3, 91);
            this.pictureBox_bDropZone.Name = "pictureBox_bDropZone";
            this.pictureBox_bDropZone.Size = new System.Drawing.Size(100, 82);
            this.pictureBox_bDropZone.TabIndex = 11;
            this.pictureBox_bDropZone.TabStop = false;
            this.pictureBox_bDropZone.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureBox_bDropZone_DragDrop);
            this.pictureBox_bDropZone.DragEnter += new System.Windows.Forms.DragEventHandler(this.PictureBox_bDropZone_DragEnter);
            this.pictureBox_bDropZone.DoubleClick += new System.EventHandler(this.pictureBox_bDropZone_DoubleClick);
            // 
            // pictureBox_aDropZone
            // 
            this.pictureBox_aDropZone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_aDropZone.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_aDropZone.Image")));
            this.pictureBox_aDropZone.Location = new System.Drawing.Point(3, 3);
            this.pictureBox_aDropZone.Name = "pictureBox_aDropZone";
            this.pictureBox_aDropZone.Size = new System.Drawing.Size(100, 82);
            this.pictureBox_aDropZone.TabIndex = 12;
            this.pictureBox_aDropZone.TabStop = false;
            this.pictureBox_aDropZone.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureBox_aDropZone_DragDrop);
            this.pictureBox_aDropZone.DragEnter += new System.Windows.Forms.DragEventHandler(this.PictureBox_aDropZone_DragEnter);
            this.pictureBox_aDropZone.DoubleClick += new System.EventHandler(this.pictureBox_aDropZone_DoubleClick);
            // 
            // timer_tingFileInfo
            // 
            this.timer_tingFileInfo.Enabled = true;
            this.timer_tingFileInfo.Interval = 500;
            this.timer_tingFileInfo.Tick += new System.EventHandler(this.timer_tingFileInfo_Tick);
            // 
            // panel_FilterList_w
            // 
            this.panel_FilterList_w.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_FilterList_w.ListStringBlock = "";
            this.panel_FilterList_w.Location = new System.Drawing.Point(9, 22);
            this.panel_FilterList_w.Name = "panel_FilterList_w";
            this.panel_FilterList_w.Size = new System.Drawing.Size(328, 202);
            this.panel_FilterList_w.TabIndex = 7;
            // 
            // panel_FilterList_b
            // 
            this.panel_FilterList_b.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_FilterList_b.ListStringBlock = "";
            this.panel_FilterList_b.Location = new System.Drawing.Point(7, 22);
            this.panel_FilterList_b.Name = "panel_FilterList_b";
            this.panel_FilterList_b.Size = new System.Drawing.Size(324, 202);
            this.panel_FilterList_b.TabIndex = 7;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 581);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "Filtered File Transfer by longtombbj 2023 0908";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_bDropZone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_aDropZone)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion
        private System.Windows.Forms.ImageList imageList_treeView;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button button_delProfile;
        private System.Windows.Forms.Button button_newProfile;
        private System.Windows.Forms.TextBox textBox_profileDescription;
        private System.Windows.Forms.TreeView treeView_profiles;
        private System.Windows.Forms.Button button_startStop;
        private System.Windows.Forms.Button button_saveProfile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton_osFunc;
        private System.Windows.Forms.RadioButton radioButton_csFunc;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton_toCopy;
        private System.Windows.Forms.RadioButton radioButton_toMove;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox_overwriteExist;
        private System.Windows.Forms.CheckBox checkBox_delFolderAfterMoveEmpty;
        private System.Windows.Forms.TextBox textBox_bPath;
        private System.Windows.Forms.TextBox textBox_aPath;
        private System.Windows.Forms.PictureBox pictureBox_bDropZone;
        private System.Windows.Forms.PictureBox pictureBox_aDropZone;
        private Panel_FilterList panel_FilterList_w;
        private Panel_FilterList panel_FilterList_b;
        private System.Windows.Forms.Label label_TransferingFileInfo;
        private System.Windows.Forms.Timer timer_tingFileInfo;
        private System.Windows.Forms.Button button_scan;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogA;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox_sounds;
        private System.Windows.Forms.Button button_viewLog;
    }
}

